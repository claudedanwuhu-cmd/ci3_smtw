<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        $data['title'] = 'Profil Sekolah';
        $data['profil'] = $this->db->get('profil')->row();

        $this->load->view('admin/profil/index', $data);
    }

    public function update()
    {
        $profil = $this->db->get('profil')->row();
        if (!$profil) {
            $this->session->set_flashdata('error', 'Data profil belum tersedia.');
            redirect('admin/profil');
        }

        $email = trim((string) $this->input->post('email', TRUE));
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->session->set_flashdata('error', 'Format email tidak valid.');
            redirect('admin/profil');
        }

        $data = array(
            'nama_sekolah'    => trim((string) $this->input->post('nama_sekolah', TRUE)),
            'npsn'            => $this->input->post('npsn', TRUE),
            'nss'             => $this->input->post('nss', TRUE),
            'alamat'          => $this->input->post('alamat', TRUE),
            'desa'            => $this->input->post('desa', TRUE),
            'kecamatan'       => $this->input->post('kecamatan', TRUE),
            'kabupaten'       => $this->input->post('kabupaten', TRUE),
            'provinsi'        => $this->input->post('provinsi', TRUE),
            'kode_pos'        => $this->input->post('kode_pos', TRUE),
            'telepon'         => $this->input->post('telepon', TRUE),
            'email'           => $email,
            'website'         => $this->input->post('website', TRUE),
            'sejarah'         => $this->input->post('sejarah', TRUE),
            'visi'            => $this->input->post('visi', TRUE),
            'misi'            => $this->input->post('misi', TRUE),
            'sambutan_kepala' => $this->input->post('sambutan_kepala', TRUE),
            'nama_kepala'     => $this->input->post('nama_kepala', TRUE),
            'updated_at'      => date('Y-m-d H:i:s')
        );

        $this->db->where('id', (int) $profil->id)->update('profil', $data);

        $this->session->set_flashdata('success', 'Profil sekolah berhasil diperbarui.');
        redirect('admin/profil');
    }
}
