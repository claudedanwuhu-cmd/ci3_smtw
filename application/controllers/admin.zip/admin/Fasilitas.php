<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fasilitas extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        $data['title'] = 'Fasilitas';
        $data['fasilitas'] = $this->db->order_by('id', 'DESC')->get('fasilitas')->result();

        $this->load->view('admin/fasilitas/index', $data);
    }

    public function tambah()
    {
        $data['title'] = 'Tambah Fasilitas';
        $this->load->view('admin/fasilitas/tambah', $data);
    }

    public function simpan()
    {
        $data = $this->input->post(NULL, TRUE);
        $data['created_at'] = date('Y-m-d H:i:s');

        $this->db->insert('fasilitas', $data);

        $this->session->set_flashdata('success', 'Fasilitas berhasil ditambahkan.');
        redirect('admin/fasilitas');
    }

    public function edit($id)
    {
        $data['title'] = 'Edit Fasilitas';
        $data['fasilitas'] = $this->db->where('id', $id)->get('fasilitas')->row();

        if (!$data['fasilitas']) {
            show_404();
        }

        $this->load->view('admin/fasilitas/edit', $data);
    }

    public function update($id)
    {
        $data = $this->input->post(NULL, TRUE);

        $this->db->where('id', $id)->update('fasilitas', $data);

        $this->session->set_flashdata('success', 'Fasilitas berhasil diperbarui.');
        redirect('admin/fasilitas');
    }

    public function hapus($id)
    {
        $this->db->where('id', $id)->delete('fasilitas');

        $this->session->set_flashdata('success', 'Fasilitas berhasil dihapus.');
        redirect('admin/fasilitas');
    }
}
