<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ekstrakurikuler extends Admin_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->helper(array('url', 'form'));
    }

    public function index()
    {
        $data['title'] = 'Ekstrakurikuler';
        $data['ekstrakurikuler'] = $this->db->order_by('id', 'DESC')->get('ekstrakurikuler')->result();

        $this->load->view('admin/ekstrakurikuler/index', $data);
    }

    public function tambah()
    {
        $data['title'] = 'Tambah Ekstrakurikuler';
        $this->load->view('admin/ekstrakurikuler/tambah', $data);
    }

    public function simpan()
    {
        $data = $this->input->post(NULL, TRUE);
        $data['created_at'] = date('Y-m-d H:i:s');

        $this->db->insert('ekstrakurikuler', $data);

        $this->session->set_flashdata('success', 'Ekstrakurikuler berhasil ditambahkan.');
        redirect('admin/ekstrakurikuler');
    }

    public function edit($id)
    {
        $data['title'] = 'Edit Ekstrakurikuler';
        $data['ekstrakurikuler'] = $this->db->where('id', $id)->get('ekstrakurikuler')->row();

        if (!$data['ekstrakurikuler']) {
            show_404();
        }

        $this->load->view('admin/ekstrakurikuler/edit', $data);
    }

    public function update($id)
    {
        $data = $this->input->post(NULL, TRUE);

        $this->db->where('id', $id)->update('ekstrakurikuler', $data);

        $this->session->set_flashdata('success', 'Ekstrakurikuler berhasil diperbarui.');
        redirect('admin/ekstrakurikuler');
    }

    public function hapus($id)
    {
        $this->db->where('id', $id)->delete('ekstrakurikuler');

        $this->session->set_flashdata('success', 'Ekstrakurikuler berhasil dihapus.');
        redirect('admin/ekstrakurikuler');
    }
}
