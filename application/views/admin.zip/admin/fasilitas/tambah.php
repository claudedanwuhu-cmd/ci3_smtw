```php
<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">


        <!-- PAGE HEADER -->
        <div class="page-header-custom mb-4">

            <div class="d-flex align-items-center gap-3">

                <div class="page-header-icon">
                    <i class="fa-solid fa-building-circle-plus"></i>
                </div>

                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-plus me-1"></i>
                        Form Input
                    </span>

                    <h2 class="page-title">Tambah Fasilitas</h2>

                    <p class="page-subtitle">
                        Tambahkan data sarana atau prasarana baru ke dalam sistem.
                    </p>
                </div>

            </div>

            <a href="<?= site_url('admin/fasilitas'); ?>" class="btn-back">
                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali
            </a>

        </div>

        <!-- FORM -->
        <form
            action="<?= site_url('admin/fasilitas/simpan'); ?>"
            method="post"
        >

            <div class="custom-card">

                <!-- CARD HEADER -->
                <div class="card-title-custom">

                    <div class="title-icon">
                        <i class="fa-solid fa-building"></i>
                    </div>

                    <div>
                        <h5>Informasi Fasilitas</h5>
                        <small>
                            Lengkapi informasi fasilitas sekolah dengan benar.
                        </small>
                    </div>

                </div>

                <!-- FORM BODY -->
                <div class="card-body-custom">

                    <div class="row g-4">

                        <!-- NAMA -->
                        <div class="col-md-8">

                            <label class="form-label required">
                                Nama Fasilitas
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-building input-icon"></i>

                                <input
                                    type="text"
                                    name="nama_fasilitas"
                                    class="form-control with-icon"
                                    placeholder="Contoh: Laboratorium Komputer"
                                    required
                                >

                            </div>

                        </div>

                        <!-- STATUS -->
                        <div class="col-md-4">

                            <label class="form-label">
                                Status
                            </label>

                            <select
                                name="status"
                                class="form-select custom-select"
                            >
                                <option value="aktif">
                                    🟢 Aktif
                                </option>

                                <option value="nonaktif">
                                    🔴 Nonaktif
                                </option>
                            </select>

                        </div>

                        <!-- FOTO -->
                        <div class="col-12">

                            <label class="form-label">
                                Nama File Foto
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-image input-icon"></i>

                                <input
                                    type="text"
                                    name="foto"
                                    class="form-control with-icon"
                                    placeholder="Contoh: laboratorium.jpg"
                                >

                            </div>

                            <small class="form-hint">
                                <i class="fa-solid fa-circle-info me-1"></i>
                                Masukkan nama file foto yang tersedia di folder fasilitas.
                            </small>

                        </div>

                        <!-- DESKRIPSI -->
                        <div class="col-12">

                            <label class="form-label">
                                Deskripsi Fasilitas
                            </label>

                            <textarea
                                name="deskripsi"
                                class="form-control custom-textarea"
                                rows="5"
                                placeholder="Tuliskan informasi singkat mengenai fasilitas ini..."
                            ></textarea>

                        </div>

                    </div>

                </div>

                <!-- FOOTER -->
                <div class="form-footer">

                    <a
                        href="<?= site_url('admin/fasilitas'); ?>"
                        class="btn-cancel"
                    >
                        <i class="fa-solid fa-xmark me-2"></i>
                        Batal
                    </a>

                    <button
                        type="submit"
                        class="btn-save"
                    >
                        <i class="fa-solid fa-floppy-disk me-2"></i>
                        Simpan Fasilitas
                    </button>

                </div>

            </div>

        </form>

    </div>
</div>

<style>
:root {
    --facility-card-bg: #ffffff;
    --facility-subtle: #f8fafc;
    --facility-input-bg: #f8fafc;
    --facility-input-border: #cbd5e1;
    --facility-input-color: #0f172a;
    --facility-input-focus: #ffffff;
    --facility-border: rgba(226, 232, 240, 0.8);
    --facility-title: #0f172a;
    --facility-subtitle: #64748b;
    --facility-hover: #f1f5f9;
    --facility-accent: #0ea5e9;
    --facility-glow: rgba(14, 165, 233, 0.25);
    --facility-icon-muted: #94a3b8;
    --facility-shadow:
        0 10px 25px -5px rgba(15, 23, 42, 0.05),
        0 8px 10px -6px rgba(15, 23, 42, 0.01);
}

[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --facility-card-bg: #0f172a;
    --facility-subtle: #1e293b;
    --facility-input-bg: #1e293b;
    --facility-input-border: rgba(255, 255, 255, 0.12);
    --facility-input-color: #f1f5f9;
    --facility-input-focus: #111827;
    --facility-border: rgba(255, 255, 255, 0.08);
    --facility-title: #f8fafc;
    --facility-subtitle: #94a3b8;
    --facility-hover: #1e293b;
    --facility-accent: #38bdf8;
    --facility-glow: rgba(56, 189, 248, 0.25);
    --facility-icon-muted: #64748b;
    --facility-shadow:
        0 12px 30px -5px rgba(0, 0, 0, 0.4);
}

.page-header-custom {
    background: var(--facility-card-bg);
    border: 1px solid var(--facility-border);
    border-radius: 20px;
    padding: 22px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: var(--facility-shadow);
}

.page-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 16px;
    background: var(--facility-subtle);
    border: 1px solid var(--facility-border);
    color: var(--facility-accent);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    flex-shrink: 0;
}

.badge-header-tag {
    display: inline-flex;
    align-items: center;
    background: rgba(56, 189, 248, 0.12);
    color: var(--facility-accent);
    border: 1px solid rgba(56, 189, 248, 0.25);
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
}

.page-title {
    color: var(--facility-title);
    font-size: 22px;
    font-weight: 800;
    margin: 0 0 2px;
}

.page-subtitle {
    color: var(--facility-subtitle);
    font-size: 13px;
    margin: 0;
}

.btn-back {
    display: inline-flex;
    align-items: center;
    background: var(--facility-subtle);
    color: var(--facility-title);
    border: 1px solid var(--facility-border);
    text-decoration: none;
    padding: 10px 20px;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 600;
    transition: all .25s ease;
}

.btn-back:hover {
    background: var(--facility-hover);
    color: var(--facility-accent);
    transform: translateX(-3px);
}

.custom-card {
    background: var(--facility-card-bg);
    border: 1px solid var(--facility-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: var(--facility-shadow);
}

.card-title-custom {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 24px;
    background: var(--facility-subtle);
    border-bottom: 1px solid var(--facility-border);
}

.title-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    background: rgba(56, 189, 248, .12);
    border: 1px solid rgba(56, 189, 248, .25);
    color: var(--facility-accent);
    display: flex;
    align-items: center;
    justify-content: center;
}

.card-title-custom h5 {
    margin: 0 0 2px;
    color: var(--facility-title);
    font-size: 15px;
    font-weight: 700;
}

.card-title-custom small {
    color: var(--facility-subtitle);
    font-size: 12px;
}

.card-body-custom {
    padding: 24px;
}

.form-label {
    color: var(--facility-title);
    font-size: 12.5px;
    font-weight: 700;
    margin-bottom: 8px;
}

.form-label.required::after {
    content: " *";
    color: #ef4444;
}

.input-icon-group {
    position: relative;
}

.input-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--facility-icon-muted);
    font-size: 14px;
    pointer-events: none;
}

.form-control,
.form-select {
    background-color: var(--facility-input-bg);
    border: 1px solid var(--facility-input-border);
    border-radius: 12px;
    font-size: 13.5px;
    color: var(--facility-input-color);
    padding: 10px 16px;
    transition: all .25s ease;
}

.form-control.with-icon {
    padding-left: 42px;
}

.form-control:focus,
.form-select:focus {
    background-color: var(--facility-input-focus);
    border-color: var(--facility-accent);
    color: var(--facility-input-color);
    box-shadow: 0 0 0 4px var(--facility-glow);
    outline: none;
}

.form-control::placeholder {
    color: var(--facility-subtitle);
    opacity: .6;
}

.form-hint {
    display: block;
    color: var(--facility-subtitle);
    font-size: 11.5px;
    margin-top: 7px;
}

.custom-textarea {
    resize: vertical;
    min-height: 120px;
    line-height: 1.6;
}

.custom-select {
    cursor: pointer;
}

.form-footer {
    padding: 18px 24px;
    background: var(--facility-subtle);
    border-top: 1px solid var(--facility-border);
    display: flex;
    justify-content: flex-end;
    gap: 12px;
}

.btn-cancel {
    background: var(--facility-card-bg);
    border: 1px solid var(--facility-border);
    color: var(--facility-title);
    text-decoration: none;
    border-radius: 12px;
    padding: 11px 22px;
    font-size: 13px;
    font-weight: 600;
    transition: all .2s ease;
}

.btn-cancel:hover {
    background: var(--facility-hover);
    color: #ef4444;
}

.btn-save {
    border: none;
    background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
    color: #ffffff;
    border-radius: 12px;
    padding: 11px 26px;
    font-size: 13px;
    font-weight: 700;
    transition: all .3s ease;
    box-shadow: 0 4px 15px rgba(2, 132, 199, .3);
    cursor: pointer;
}

.btn-save:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 22px rgba(2, 132, 199, .45);
}

@media (max-width: 768px) {

    .page-header-custom {
        flex-direction: column;
        align-items: stretch;
    }

    .btn-back {
        justify-content: center;
    }

    .card-body-custom {
        padding: 20px 18px;
    }

    .card-title-custom {
        padding: 18px;
    }

    .form-footer {
        padding: 18px;
        flex-direction: column-reverse;
    }

    .btn-cancel,
    .btn-save {
        width: 100%;
        text-align: center;
    }
}
</style>

<?php $this->load->view('admin/template/footer'); ?>
```
