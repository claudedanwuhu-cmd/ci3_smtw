```php
<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">


        <!-- FLASH MESSAGE -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-custom-success alert-dismissible fade show mb-4" role="alert">
                <div class="d-flex align-items-center gap-2">
                    <i class="fa-solid fa-circle-check fs-5"></i>
                    <span><?= html_escape($this->session->flashdata('success')); ?></span>
                </div>

                <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- PAGE HEADER -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-building"></i>
                </div>

                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-school me-1"></i>
                        Sarana & Prasarana
                    </span>

                    <h2 class="page-title">Fasilitas Sekolah</h2>

                    <p class="page-subtitle">
                        Kelola data sarana dan prasarana yang tersedia di SMA Negeri Tawangmangu.
                    </p>
                </div>
            </div>

            <a href="<?= site_url('admin/fasilitas/tambah'); ?>" class="btn-add">
                <i class="fa-solid fa-plus me-2"></i>
                Tambah Fasilitas
            </a>
        </div>

        <!-- MAIN CARD -->
        <div class="custom-card">

            <div class="card-title-custom justify-content-between align-items-center">

                <div class="d-flex align-items-center gap-3">
                    <div class="title-icon">
                        <i class="fa-solid fa-building"></i>
                    </div>

                    <div>
                        <h5>Data Fasilitas Sekolah</h5>
                        <small>
                            Daftar sarana dan prasarana sekolah yang terdaftar
                        </small>
                    </div>
                </div>

                <div class="total-badge">
                    <i class="fa-solid fa-building me-1"></i>
                    <?= !empty($fasilitas) ? count($fasilitas) : 0; ?> Fasilitas
                </div>

            </div>

            <div class="content-card-body">

                <div class="row g-4">

                    <?php if (!empty($fasilitas)): ?>

                        <?php foreach ($fasilitas as $item): ?>

                            <div class="col-xl-4 col-md-6">

                                <div class="facility-card">

                                    <!-- IMAGE -->
                                    <div class="facility-image-wrapper">

                                        <?php if (!empty($item->foto)): ?>

                                            <img
                                                src="<?= base_url('assets/img/fasilitas/' . $item->foto); ?>"
                                                class="facility-image"
                                                alt="<?= html_escape($item->nama_fasilitas); ?>"
                                            >

                                        <?php else: ?>

                                            <div class="facility-placeholder">
                                                <i class="fa-solid fa-building"></i>
                                            </div>

                                        <?php endif; ?>

                                        <!-- STATUS -->
                                        <div class="facility-status">
                                            <?php if ($item->status === 'aktif'): ?>

                                                <span class="status-badge active">
                                                    <i class="fa-solid fa-circle-check me-1"></i>
                                                    Aktif
                                                </span>

                                            <?php else: ?>

                                                <span class="status-badge inactive">
                                                    <i class="fa-solid fa-circle-xmark me-1"></i>
                                                    Nonaktif
                                                </span>

                                            <?php endif; ?>
                                        </div>

                                    </div>

                                    <!-- CONTENT -->
                                    <div class="facility-body">

                                        <h5 class="facility-title">
                                            <?= html_escape($item->nama_fasilitas); ?>
                                        </h5>

                                        <p class="facility-description">
                                            <?=
                                                !empty($item->deskripsi)
                                                    ? html_escape($item->deskripsi)
                                                    : 'Belum ada deskripsi fasilitas.';
                                            ?>
                                        </p>

                                        <div class="facility-footer">

                                            <span class="facility-label">
                                                <i class="fa-solid fa-building-columns me-1"></i>
                                                Fasilitas Sekolah
                                            </span>

                                            <div class="action-buttons">

                                                <a
                                                    href="<?= site_url('admin/fasilitas/edit/' . $item->id); ?>"
                                                    class="btn-action edit"
                                                    title="Edit Data"
                                                >
                                                    <i class="fa-solid fa-pen-to-square"></i>
                                                </a>

                                                <a
                                                    href="<?= site_url('admin/fasilitas/hapus/' . $item->id); ?>"
                                                    class="btn-action delete"
                                                    title="Hapus Data"
                                                    onclick="return confirm('Yakin ingin menghapus fasilitas ini?');"
                                                >
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <div class="col-12">

                            <div class="empty-data">

                                <div class="empty-icon">
                                    <i class="fa-solid fa-building"></i>
                                </div>

                                <div class="fw-bold fs-6 mb-1 text-title">
                                    Belum ada data fasilitas
                                </div>

                                <p class="text-subtle fs-7 mb-3">
                                    Sistem belum mencatat fasilitas sekolah.
                                </p>

                                <a
                                    href="<?= site_url('admin/fasilitas/tambah'); ?>"
                                    class="btn-add"
                                >
                                    <i class="fa-solid fa-plus me-2"></i>
                                    Tambahkan Fasilitas
                                </a>

                            </div>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>
</div>

<style>
:root {
    --facility-card-bg: #ffffff;
    --facility-subtle: #f8fafc;
    --facility-border: #e2e8f0;
    --facility-title: #0f172a;
    --facility-subtitle: #64748b;
    --facility-hover: #f1f5f9;
    --facility-accent: #0ea5e9;
    --facility-shadow:
        0 10px 25px -5px rgba(15, 23, 42, 0.05),
        0 8px 10px -6px rgba(15, 23, 42, 0.02);
}

[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --facility-card-bg: #0f172a;
    --facility-subtle: #1e293b;
    --facility-border: rgba(255, 255, 255, 0.08);
    --facility-title: #f8fafc;
    --facility-subtitle: #94a3b8;
    --facility-hover: #1e293b;
    --facility-accent: #38bdf8;
    --facility-shadow:
        0 12px 30px -5px rgba(0, 0, 0, 0.4);
}

.text-title {
    color: var(--facility-title) !important;
}

.text-subtle {
    color: var(--facility-subtitle) !important;
}

.fs-7 {
    font-size: 12px;
}

/* ALERT */
.alert-custom-success {
    background: rgba(16, 185, 129, 0.12) !important;
    border: 1px solid rgba(16, 185, 129, 0.25) !important;
    color: #10b981 !important;
    border-radius: 16px;
    padding: 16px 20px;
}

/* PAGE HEADER */
.page-header-custom {
    background: var(--facility-card-bg);
    border: 1px solid var(--facility-border);
    border-radius: 20px;
    padding: 24px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: var(--facility-shadow);
}

.page-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 16px;
    background: var(--facility-subtle);
    border: 1px solid var(--facility-border);
    color: var(--facility-accent);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    flex-shrink: 0;
}

.badge-header-tag {
    display: inline-flex;
    align-items: center;
    background: rgba(56, 189, 248, 0.12);
    color: var(--facility-accent);
    border: 1px solid rgba(56, 189, 248, 0.25);
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.page-title {
    color: var(--facility-title);
    font-size: 22px;
    font-weight: 800;
    margin: 0 0 2px;
    letter-spacing: -0.3px;
}

.page-subtitle {
    color: var(--facility-subtitle);
    font-size: 13px;
    margin: 0;
}

/* ADD BUTTON */
.btn-add {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
    color: #ffffff !important;
    text-decoration: none;
    padding: 12px 22px;
    border-radius: 12px;
    font-size: 13px;
    font-weight: 700;
    transition: all 0.3s ease;
    box-shadow: 0 6px 18px rgba(2, 132, 199, 0.3);
    white-space: nowrap;
}

.btn-add:hover {
    transform: translateY(-2px);
    box-shadow: 0 10px 24px rgba(2, 132, 199, 0.45);
}

/* MAIN CARD */
.custom-card {
    background: var(--facility-card-bg);
    border: 1px solid var(--facility-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: var(--facility-shadow);
}

.card-title-custom {
    display: flex;
    padding: 20px 24px;
    background: var(--facility-subtle);
    border-bottom: 1px solid var(--facility-border);
}

.title-icon {
    width: 42px;
    height: 42px;
    background: rgba(56, 189, 248, 0.12);
    border: 1px solid rgba(56, 189, 248, 0.25);
    color: var(--facility-accent);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    flex-shrink: 0;
}

.card-title-custom h5 {
    margin: 0 0 2px;
    color: var(--facility-title);
    font-size: 15px;
    font-weight: 700;
}

.card-title-custom small {
    color: var(--facility-subtitle);
    font-size: 12px;
}

.total-badge {
    color: var(--facility-accent);
    font-size: 12px;
    background: rgba(56, 189, 248, 0.12);
    border: 1px solid rgba(56, 189, 248, 0.25);
    padding: 6px 14px;
    border-radius: 20px;
    font-weight: 700;
}

.content-card-body {
    padding: 24px;
}

/* FACILITY CARD */
.facility-card {
    height: 100%;
    background: var(--facility-card-bg);
    border: 1px solid var(--facility-border);
    border-radius: 16px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.facility-card:hover {
    transform: translateY(-4px);
    border-color: rgba(56, 189, 248, 0.35);
    box-shadow: 0 14px 30px rgba(15, 23, 42, 0.08);
}

.facility-image-wrapper {
    height: 190px;
    position: relative;
    overflow: hidden;
    background: var(--facility-subtle);
}

.facility-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.4s ease;
}

.facility-card:hover .facility-image {
    transform: scale(1.04);
}

.facility-placeholder {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--facility-subtitle);
    font-size: 42px;
    background: var(--facility-subtle);
}

.facility-status {
    position: absolute;
    top: 14px;
    right: 14px;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 11.5px;
    font-weight: 700;
    backdrop-filter: blur(8px);
}

.status-badge.active {
    background: rgba(16, 185, 129, 0.9);
    color: #ffffff;
    border: 1px solid rgba(255,255,255,0.2);
}

.status-badge.inactive {
    background: rgba(239, 68, 68, 0.9);
    color: #ffffff;
    border: 1px solid rgba(255,255,255,0.2);
}

/* FACILITY CONTENT */
.facility-body {
    padding: 18px;
}

.facility-title {
    color: var(--facility-title);
    font-size: 15px;
    font-weight: 700;
    margin: 0 0 8px;
}

.facility-description {
    color: var(--facility-subtitle);
    font-size: 12.5px;
    line-height: 1.6;
    margin: 0 0 18px;

    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;

    min-height: 60px;
}

.facility-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding-top: 14px;
    border-top: 1px solid var(--facility-border);
}

.facility-label {
    color: var(--facility-subtitle);
    font-size: 11px;
    font-weight: 600;
}

.action-buttons {
    display: flex;
    gap: 8px;
}

.btn-action {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    font-size: 13px;
    transition: all 0.25s ease;
}

.btn-action.edit {
    background: var(--facility-subtle);
    color: var(--facility-title);
    border: 1px solid var(--facility-border);
}

.btn-action.edit:hover {
    background: var(--facility-accent);
    color: #ffffff;
    border-color: var(--facility-accent);
    transform: translateY(-2px);
}

.btn-action.delete {
    background: rgba(239, 68, 68, 0.12);
    color: #f87171;
    border: 1px solid rgba(239, 68, 68, 0.2);
}

.btn-action.delete:hover {
    background: #ef4444;
    color: #ffffff;
    border-color: #ef4444;
    transform: translateY(-2px);
}

/* EMPTY */
.empty-data {
    text-align: center;
    padding: 60px 20px;
}

.empty-icon {
    width: 64px;
    height: 64px;
    margin: 0 auto 16px;
    border-radius: 50%;
    background: var(--facility-subtle);
    border: 1px solid var(--facility-border);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--facility-subtitle);
    font-size: 26px;
}

/* RESPONSIVE */
@media (max-width: 768px) {

    .page-header-custom {
        flex-direction: column;
        align-items: stretch;
    }

    .btn-add {
        width: 100%;
    }

    .card-title-custom {
        flex-direction: column;
        align-items: flex-start !important;
        gap: 12px;
    }

    .content-card-body {
        padding: 18px;
    }

    .facility-image-wrapper {
        height: 210px;
    }
}
</style>

<?php $this->load->view('admin/template/footer'); ?>
```
