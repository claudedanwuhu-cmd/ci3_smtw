<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('admin/template/header');
$this->load->view('admin/template/sidebar');
?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-trophy"></i>
                </div>
                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-plus-circle me-1"></i> Form Input Prestasi
                    </span>
                    <h2 class="page-title">Tambah Prestasi</h2>
                    <p class="page-subtitle">Tambahkan data prestasi siswa atau pencapaian sekolah baru ke dalam sistem.</p>
                </div>
            </div>
            <!-- Tombol Batal Header (Sama seperti Tambah Guru) -->
            <a href="<?= site_url('admin/prestasi'); ?>" class="btn btn-secondary btn-cancel-custom">
                <i class="fa-solid fa-arrow-left me-2"></i> Kembali
            </a>
        </div>

        <!-- FORM CARD -->
        <div class="custom-card">
            <form action="<?= site_url('admin/prestasi/simpan'); ?>" method="post" enctype="multipart/form-data" class="p-4 p-md-5">

                <!-- CSRF Token -->
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                <!-- 1. INFORMASI PRESTASI -->
                <div class="form-section">
                    <div class="section-title">
                        <div class="section-icon">
                            <i class="fa-solid fa-award"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Informasi Utama Prestasi</h6>
                            <small class="text-muted-custom">Detail kejuaraan atau kompetisi yang diikuti</small>
                        </div>
                    </div>

                    <div class="row g-4">
                        <!-- Nama Prestasi -->
                        <div class="col-md-8">
                            <label class="form-label-custom">
                                Nama Prestasi / Kejuaraan <span class="text-danger">*</span>
                            </label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-heading"></i></span>
                                <input type="text" name="nama_prestasi" class="form-control custom-input" placeholder="Contoh: Juara 1 Lomba Pidato Bahasa Indonesia" required>
                            </div>
                        </div>

                        <!-- Juara -->
                        <div class="col-md-4">
                            <label class="form-label-custom">Capaian / Juara</label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-medal"></i></span>
                                <input type="text" name="juara" class="form-control custom-input" placeholder="Contoh: Juara 1 / Harapan 2">
                            </div>
                        </div>

                        <!-- Tingkat -->
                        <div class="col-md-4">
                            <label class="form-label-custom">Tingkat Kejuaraan</label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-layer-group"></i></span>
                                <select name="tingkat" class="form-select custom-input custom-select">
                                    <option value="">-- Pilih Tingkat --</option>
                                    <option value="Sekolah">Sekolah</option>
                                    <option value="Kecamatan">Kecamatan</option>
                                    <option value="Kabupaten">Kabupaten</option>
                                    <option value="Provinsi">Provinsi</option>
                                    <option value="Nasional">Nasional</option>
                                    <option value="Internasional">Internasional</option>
                                </select>
                            </div>
                        </div>

                        <!-- Penyelenggara -->
                        <div class="col-md-4">
                            <label class="form-label-custom">Penyelenggara</label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-building-columns"></i></span>
                                <input type="text" name="penyelenggara" class="form-control custom-input" placeholder="Contoh: Dinas Pendidikan">
                            </div>
                        </div>

                        <!-- Tanggal -->
                        <div class="col-md-4">
                            <label class="form-label-custom">Tanggal Pelaksanaan</label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-calendar-day"></i></span>
                                <input type="date" name="tanggal" class="form-control custom-input">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 2. DATA SISWA -->
                <div class="form-section">
                    <div class="section-title">
                        <div class="section-icon">
                            <i class="fa-solid fa-user-graduate"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Data Peserta / Peraih Prestasi</h6>
                            <small class="text-muted-custom">Identitas siswa atau nama tim peraih penghargaan</small>
                        </div>
                    </div>

                    <div class="row g-4">
                        <!-- Nama Siswa -->
                        <div class="col-md-8">
                            <label class="form-label-custom">Nama Siswa / Nama Tim</label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-user"></i></span>
                                <input type="text" name="nama_siswa" class="form-control custom-input" placeholder="Nama siswa atau nama kelompok yang meraih prestasi">
                            </div>
                        </div>

                        <!-- Kelas -->
                        <div class="col-md-4">
                            <label class="form-label-custom">Kelas</label>
                            <div class="input-group-custom">
                                <span class="input-icon"><i class="fa-solid fa-school"></i></span>
                                <input type="text" name="kelas" class="form-control custom-input" placeholder="Contoh: IX A / XII IPA 1">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3. FOTO PRESTASI -->
                <div class="form-section">
                    <div class="section-title">
                        <div class="section-icon">
                            <i class="fa-solid fa-image"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Dokumentasi / Foto Kegiatan</h6>
                            <small class="text-muted-custom">Upload bukti foto piala, piagam, atau foto penyerahan hadiah</small>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label-custom">Upload File Foto</label>

                            <!-- DROPZONE AREA -->
                            <div class="upload-dropzone" id="dropzone-area">
                                <input type="file" name="foto" id="file-input" class="file-input-hidden" accept="image/*">

                                <div class="dropzone-content" id="dropzone-prompt">
                                    <div class="upload-icon-box">
                                        <i class="fa-solid fa-cloud-arrow-up"></i>
                                    </div>
                                    <div class="upload-text">
                                        <span class="fw-bold text-accent-custom">Klik untuk unggah</span> atau seret foto ke sini
                                    </div>
                                    <p class="upload-hint">Format yang didukung: JPG, JPEG, PNG (Maksimal 2MB)</p>
                                </div>

                                <!-- PREVIEW AREA -->
                                <div class="dropzone-preview d-none" id="dropzone-preview">
                                    <img src="" id="image-preview" alt="Preview Foto">
                                    <div class="preview-info">
                                        <span id="file-name" class="fw-bold">nama_file.jpg</span>
                                        <span id="file-size" class="fs-7 text-muted-custom">0 KB</span>
                                        <button type="button" class="btn-remove-image mt-2" id="btn-remove-file">
                                            <i class="fa-solid fa-trash-can me-1"></i> Ganti Foto
                                        </button>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- 4. DESKRIPSI -->
                <div class="form-section border-0 pb-0 mb-0">
                    <div class="section-title">
                        <div class="section-icon">
                            <i class="fa-solid fa-align-left"></i>
                        </div>
                        <div>
                            <h6 class="mb-0 fw-bold">Deskripsi Tambahan</h6>
                            <small class="text-muted-custom">Catatan ringkas mengenai jalannya perlombaan</small>
                        </div>
                    </div>

                    <div>
                        <label class="form-label-custom">Keterangan / Deskripsi Ringkas</label>
                        <textarea name="deskripsi" class="form-control custom-input custom-textarea" rows="4" placeholder="Tuliskan keterangan singkat mengenai kegiatan, tingkat persaingan, atau catatan khusus..."></textarea>
                    </div>
                </div>

                <!-- TOMBOL AKSI (FOOTER - SESUAI MODUL GURU) -->
                <div class="form-footer mt-5 pt-4 border-top">
                    <a href="<?= site_url('admin/prestasi'); ?>" class="btn btn-secondary btn-cancel-custom">
                        <i class="fa-solid fa-xmark me-2"></i> Batal
                    </a>
                    <button type="submit" class="btn-primary-custom">
                        <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Prestasi
                    </button>
                </div>

            </form>
        </div>

    </div>
</div>

<!-- STYLES KUSTOM DINAMIS (DARK/LIGHT MODE ADAPTIVE) -->
<style>
    :root {
        --pres-bg: #ffffff;
        --pres-subtle: #f8fafc;
        --pres-border: rgba(226, 232, 240, 0.8);
        --pres-input-bg: #ffffff;
        --pres-title: #0f172a;
        --pres-subtitle: #64748b;
        --pres-hover: #f1f5f9;
        --pres-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.05);
        --pres-accent: #0ea5e9;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(14, 165, 233, 0.15);
    }

    [data-theme="dark"], body.dark-mode {
        --pres-bg: #0f172a;
        --pres-subtle: #1e293b;
        --pres-border: rgba(255, 255, 255, 0.08);
        --pres-input-bg: #1e293b;
        --pres-title: #f8fafc;
        --pres-subtitle: #94a3b8;
        --pres-hover: rgba(255, 255, 255, 0.03);
        --pres-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.4);
        --pres-accent: #38bdf8;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(56, 189, 248, 0.2);
    }

    .fs-7 { font-size: 12.5px; }
    .text-muted-custom { color: var(--pres-subtitle); }
    .text-accent-custom { color: var(--pres-accent); }

    /* Page Header */
    .page-header-custom {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        padding: 22px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--pres-shadow);
        gap: 20px;
    }

    .badge-header-tag {
        display: inline-flex;
        align-items: center;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .page-title {
        color: var(--pres-title);
        font-size: 22px;
        font-weight: 800;
        margin-bottom: 2px;
    }

    .page-subtitle {
        color: var(--pres-subtitle);
        font-size: 13px;
        margin-bottom: 0;
    }

    .page-header-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        background: var(--pres-subtle);
        border: 1px solid var(--pres-border);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
    }

    /* Card Wrapper */
    .custom-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--pres-shadow);
    }

    /* Section Styling */
    .form-section {
        padding-bottom: 30px;
        margin-bottom: 30px;
        border-bottom: 1px dashed var(--pres-border);
    }

    .section-title {
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 22px;
    }

    .section-icon {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    .section-title h6 {
        color: var(--pres-title);
        font-size: 15px;
    }

    /* Form Inputs Modern */
    .form-label-custom {
        color: var(--pres-title);
        font-size: 13px;
        font-weight: 600;
        margin-bottom: 8px;
        display: block;
    }

    .input-group-custom {
        position: relative;
        display: flex;
        align-items: center;
    }

    .input-icon {
        position: absolute;
        left: 14px;
        color: var(--pres-subtitle);
        font-size: 14px;
        z-index: 5;
        pointer-events: none;
        transition: color 0.2s ease;
    }

    .custom-input {
        width: 100%;
        background-color: var(--pres-input-bg);
        border: 1px solid var(--pres-border);
        color: var(--pres-title);
        border-radius: 12px;
        padding: 11px 16px 11px 42px;
        font-size: 13.5px;
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .custom-input:focus {
        background-color: var(--pres-input-bg);
        color: var(--pres-title);
        border-color: var(--pres-accent);
        box-shadow: 0 0 0 4px var(--pres-accent-glow);
        outline: none;
    }

    .custom-input:focus + .input-icon,
    .input-group-custom:focus-within .input-icon {
        color: var(--pres-accent);
    }

    .custom-input::placeholder {
        color: var(--pres-subtitle);
        opacity: 0.6;
    }

    .custom-textarea {
        padding: 14px 16px;
        resize: vertical;
        min-height: 110px;
    }

    /* Select Dropdown */
    .custom-select {
        appearance: none;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%2364748b' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 14px center;
        background-size: 12px 12px;
        padding-right: 36px;
    }

    /* File Dropzone Area */
    .upload-dropzone {
        position: relative;
        border: 2px dashed var(--pres-border);
        border-radius: 16px;
        background: var(--pres-subtle);
        padding: 32px 20px;
        text-align: center;
        cursor: pointer;
        transition: all 0.25s ease;
    }

    .upload-dropzone:hover,
    .upload-dropzone.dragover {
        border-color: var(--pres-accent);
        background: rgba(14, 165, 233, 0.04);
    }

    .file-input-hidden {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        cursor: pointer;
        z-index: 10;
    }

    .upload-icon-box {
        width: 52px;
        height: 52px;
        border-radius: 14px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        margin-bottom: 12px;
    }

    .upload-text {
        color: var(--pres-title);
        font-size: 14px;
        margin-bottom: 4px;
    }

    .upload-hint {
        color: var(--pres-subtitle);
        font-size: 12px;
        margin-bottom: 0;
    }

    /* Dropzone Preview */
    .dropzone-preview {
        display: flex;
        align-items: center;
        gap: 16px;
        text-align: left;
        position: relative;
        z-index: 11;
    }

    .dropzone-preview img {
        width: 70px;
        height: 70px;
        border-radius: 12px;
        object-fit: cover;
        border: 2px solid var(--pres-border);
    }

    .preview-info {
        display: flex;
        flex-direction: column;
    }

    .preview-info #file-name {
        color: var(--pres-title);
        font-size: 13.5px;
    }

    .btn-remove-image {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
        padding: 4px 12px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        width: fit-content;
        transition: all 0.2s ease;
    }

    .btn-remove-image:hover {
        background: #ef4444;
        color: #ffffff;
    }

    /* Buttons */
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, var(--pres-accent) 0%, var(--pres-accent-dark) 100%);
        color: #ffffff !important;
        border-radius: 12px;
        padding: 12px 26px;
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        border: none;
        cursor: pointer;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(14, 165, 233, 0.45);
    }

    /* Custom Style untuk Tombol Batal / Kembali */
    /* Custom Style untuk Tombol Batal / Kembali (Hover Merah) */
    .btn-cancel-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: var(--pres-subtle);
        color: var(--pres-title) !important;
        border-radius: 12px;
        padding: 12px 22px;
        font-size: 13.5px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.25s ease;
        border: 1px solid var(--pres-border);
    }

    /* Saat kursor menyentuh / hover tombol Batal -> Berubah Merah */
    .btn-cancel-custom:hover {
        background: rgba(239, 68, 68, 0.1) !important; /* Latar belakang merah soft */
        color: #ef4444 !important;                    /* Teks & Icon jadi merah */
        border-color: rgba(239, 68, 68, 0.4) !important; /* Border merah */
        box-shadow: 0 4px 12px rgba(239, 68, 68, 0.15);  /* Bayangan merah soft */
    }

    .form-footer {
        display: flex;
        justify-content: flex-end;
        gap: 12px;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .page-header-custom {
            flex-direction: column;
            align-items: stretch;
        }

        .btn-cancel-custom {
            justify-content: center;
        }

        .form-footer {
            flex-direction: column-reverse;
        }

        .btn-primary-custom,
        .btn-cancel-custom {
            width: 100%;
        }
    }
</style>

<!-- JAVASCRIPT UNTUK FILE PREVIEW -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const fileInput = document.getElementById('file-input');
        const dropzonePrompt = document.getElementById('dropzone-prompt');
        const dropzonePreview = document.getElementById('dropzone-preview');
        const imagePreview = document.getElementById('image-preview');
        const fileName = document.getElementById('file-name');
        const fileSize = document.getElementById('file-size');
        const btnRemove = document.getElementById('btn-remove-file');
        const dropzoneArea = document.getElementById('dropzone-area');

        fileInput.addEventListener('change', function () {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    imagePreview.setAttribute('src', e.target.result);
                    fileName.textContent = file.name;
                    fileSize.textContent = (file.size / 1024).toFixed(1) + ' KB';

                    dropzonePrompt.classList.add('d-none');
                    dropzonePreview.classList.remove('d-none');
                }
                reader.readAsDataURL(file);
            }
        });

        btnRemove.addEventListener('click', function (e) {
            e.preventDefault();
            fileInput.value = '';
            imagePreview.setAttribute('src', '');
            dropzonePreview.classList.add('d-none');
            dropzonePrompt.classList.remove('d-none');
        });

        // Drag & Drop visual state
        ['dragenter', 'dragover'].forEach(eventName => {
            dropzoneArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                dropzoneArea.classList.add('dragover');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzoneArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                dropzoneArea.classList.remove('dragover');
            }, false);
        });
    });
</script>

<?php $this->load->view('admin/template/footer'); ?>