<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('admin/template/header');
$this->load->view('admin/template/sidebar');
?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- HEADER -->
        <div class="page-header-custom mb-4">
            <div>
                <h2 class="page-title">
                    <i class="fa-solid fa-pen-to-square text-accent me-2"></i>
                    Edit Prestasi
                </h2>
                <p class="page-subtitle">Perbarui informasi data prestasi siswa atau pencapaian sekolah.</p>
            </div>
            <a href="<?= site_url('admin/prestasi'); ?>" class="btn-secondary-custom">
                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali
            </a>
        </div>

        <!-- FORM CARD -->
        <div class="custom-card">
            <form action="<?= site_url('admin/prestasi/update/' . $prestasi->id); ?>" method="post" enctype="multipart/form-data" class="p-4">
                
                <!-- CSRF Token -->
                <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">

                <!-- 1. INFORMASI PRESTASI -->
                <div class="form-section">
                    <div class="section-title">
                        <i class="fa-solid fa-award me-2 text-accent"></i>
                        Informasi Prestasi
                    </div>

                    <div class="row g-3">
                        <!-- Nama Prestasi -->
                        <div class="col-md-8">
                            <label class="form-label fw-semibold">
                                Nama Prestasi <span class="text-danger">*</span>
                            </label>
                            <input type="text" 
                                   name="nama_prestasi" 
                                   class="form-control custom-input" 
                                   value="<?= html_escape($prestasi->nama_prestasi); ?>" 
                                   required>
                        </div>

                        <!-- Juara -->
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Juara</label>
                            <input type="text" 
                                   name="juara" 
                                   class="form-control custom-input" 
                                   value="<?= html_escape($prestasi->juara); ?>" 
                                   placeholder="Contoh: Juara 1">
                        </div>

                        <!-- Tingkat -->
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Tingkat</label>
                            <select name="tingkat" class="form-select custom-input">
                                <option value="">-- Pilih Tingkat --</option>
                                <?php 
                                $tingkat_options = ['Sekolah', 'Kecamatan', 'Kabupaten', 'Provinsi', 'Nasional', 'Internasional'];
                                foreach ($tingkat_options as $opt): 
                                ?>
                                    <option value="<?= $opt; ?>" <?= ($prestasi->tingkat == $opt) ? 'selected' : ''; ?>>
                                        <?= $opt; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Penyelenggara -->
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Penyelenggara</label>
                            <input type="text" 
                                   name="penyelenggara" 
                                   class="form-control custom-input" 
                                   value="<?= html_escape($prestasi->penyelenggara); ?>" 
                                   placeholder="Nama penyelenggara">
                        </div>

                        <!-- Tanggal -->
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Tanggal Pelaksanaan</label>
                            <input type="date" 
                                   name="tanggal" 
                                   class="form-control custom-input" 
                                   value="<?= html_escape($prestasi->tanggal); ?>">
                        </div>
                    </div>
                </div>

                <!-- 2. DATA SISWA -->
                <div class="form-section">
                    <div class="section-title">
                        <i class="fa-solid fa-user-graduate me-2 text-accent"></i>
                        Data Siswa / Peserta
                    </div>

                    <div class="row g-3">
                        <!-- Nama Siswa -->
                        <div class="col-md-8">
                            <label class="form-label fw-semibold">Nama Siswa / Tim</label>
                            <input type="text" 
                                   name="nama_siswa" 
                                   class="form-control custom-input" 
                                   value="<?= html_escape($prestasi->nama_siswa); ?>" 
                                   placeholder="Nama siswa atau tim">
                        </div>

                        <!-- Kelas -->
                        <div class="col-md-4">
                            <label class="form-label fw-semibold">Kelas</label>
                            <input type="text" 
                                   name="kelas" 
                                   class="form-control custom-input" 
                                   value="<?= html_escape($prestasi->kelas); ?>" 
                                   placeholder="Contoh: XII IPA 1">
                        </div>
                    </div>
                </div>

                <!-- 3. FOTO PRESTASI -->
                <div class="form-section">
                    <div class="section-title">
                        <i class="fa-solid fa-image me-2 text-accent"></i>
                        Foto / Dokumentasi
                    </div>

                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label fw-semibold">Ganti Foto Prestasi <small class="text-muted fw-normal">(Biarkan kosong jika tidak ingin mengubah)</small></label>
                            <div class="upload-dropzone" id="prestasi-dropzone" role="button" tabindex="0">
                                <input type="file" name="foto" id="prestasi-file-input" class="file-input-hidden" accept="image/png,image/jpeg,image/jpg,image/webp">

                                <div class="dropzone-content <?= empty($prestasi->foto) ? '' : 'd-none'; ?>" id="prestasi-upload-prompt">
                                    <div class="upload-icon-box">
                                        <i class="fa-solid fa-cloud-arrow-up"></i>
                                    </div>
                                    <div class="upload-text">
                                        <span class="fw-bold text-accent-custom">Klik untuk unggah</span> atau seret foto ke sini
                                    </div>
                                    <p class="upload-hint">JPG, JPEG, PNG, atau WEBP (Maksimal 2MB)</p>
                                </div>

                                <div class="dropzone-preview <?= empty($prestasi->foto) ? 'd-none' : ''; ?>" id="prestasi-preview">
                                    <img src="<?= !empty($prestasi->foto) ? base_url('uploads/prestasi/' . rawurlencode($prestasi->foto)) : ''; ?>" id="prestasi-image-preview" alt="Preview Foto Prestasi">
                                    <div class="preview-info">
                                        <span id="prestasi-file-name" class="fw-bold text-truncate"> <?= !empty($prestasi->foto) ? html_escape(basename($prestasi->foto)) : 'nama_file.jpg'; ?></span>
                                        <span id="prestasi-file-size" class="fs-7 text-muted-custom">Foto saat ini</span>
                                        <span class="badge bg-primary fs-8">Ganti Foto</span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-text text-muted fs-7 mt-1">
                                <i class="fa-solid fa-circle-info me-1"></i> Foto baru akan menggantikan foto lama setelah disimpan.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 4. DESKRIPSI -->
                <div class="form-section border-0 pb-0">
                    <div class="section-title">
                        <i class="fa-solid fa-align-left me-2 text-accent"></i>
                        Deskripsi Tambahan
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Deskripsi Prestasi</label>
                        <textarea name="deskripsi" 
                                  class="form-control custom-input" 
                                  rows="4" 
                                  placeholder="Tuliskan keterangan ringkas mengenai kegiatan..."><?= html_escape($prestasi->deskripsi); ?></textarea>
                    </div>
                </div>

                <!-- TOMBOL AKSI -->
                <div class="form-footer mt-4 pt-3 border-top">
                    <a href="<?= site_url('admin/prestasi'); ?>" class="btn-secondary-custom me-2">
                        <i class="fa-solid fa-xmark me-2"></i> Batal
                    </a>
                    <button type="submit" class="btn-primary-custom">
                        <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Perubahan
                    </button>
                </div>

            </form>
        </div>

    </div>
</div>

<script>
    (function () {
        const dropzone = document.getElementById('prestasi-dropzone');
        const input = document.getElementById('prestasi-file-input');
        const prompt = document.getElementById('prestasi-upload-prompt');
        const preview = document.getElementById('prestasi-preview');
        const image = document.getElementById('prestasi-image-preview');
        const filename = document.getElementById('prestasi-file-name');
        const filesize = document.getElementById('prestasi-file-size');

        if (!dropzone || !input) return;

        const showPreview = (file) => {
            if (!file || !file.type.startsWith('image/')) return;

            const reader = new FileReader();
            reader.onload = (event) => {
                image.src = event.target.result;
                filename.textContent = file.name;
                filesize.textContent = `${(file.size / 1024).toFixed(1)} KB`;
                prompt.classList.add('d-none');
                preview.classList.remove('d-none');
            };
            reader.readAsDataURL(file);
        };

        dropzone.addEventListener('click', () => input.click());
        dropzone.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') input.click();
        });
        input.addEventListener('click', (event) => event.stopPropagation());
        input.addEventListener('change', () => showPreview(input.files[0]));
        dropzone.addEventListener('dragover', (event) => {
            event.preventDefault();
            dropzone.classList.add('is-dragging');
        });
        dropzone.addEventListener('dragleave', () => dropzone.classList.remove('is-dragging'));
        dropzone.addEventListener('drop', (event) => {
            event.preventDefault();
            dropzone.classList.remove('is-dragging');
            if (event.dataTransfer.files[0]) {
                input.files = event.dataTransfer.files;
                showPreview(event.dataTransfer.files[0]);
            }
        });
    })();
</script>

<!-- STYLES KUSTOM DINAMIS -->
<style>
    .page-header-custom {
        background: var(--card-bg, #ffffff);
        border: 1px solid var(--border-color, #e2e8f0);
        border-radius: 20px;
        padding: 24px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        box-shadow: var(--shadow-sm, 0 2px 8px rgba(0,0,0,0.04));
    }

    .page-title {
        color: var(--text-title, #17324d);
        font-size: 20px;
        font-weight: 700;
        margin: 0 0 4px;
        display: flex;
        align-items: center;
    }

    .page-subtitle {
        color: var(--text-subtitle, #64748b);
        font-size: 13px;
        margin: 0;
    }

    .text-accent {
        color: #00b4d8;
    }

    /* Buttons */
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #00b4d8 0%, #0077b6 100%);
        color: #ffffff !important;
        border-radius: 12px;
        padding: 11px 22px;
        font-size: 13px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(0, 180, 216, 0.3);
        border: none;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(0, 180, 216, 0.4);
    }

    .btn-secondary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: var(--hover-bg, #f1f5f9);
        color: var(--text-subtitle, #475569) !important;
        border-radius: 12px;
        padding: 11px 20px;
        font-size: 13px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
        border: 1px solid var(--border-color, #e2e8f0);
    }

    .btn-secondary-custom:hover {
        background: var(--border-color, #e2e8f0);
        color: var(--text-title, #17324d) !important;
    }

    /* Form Components */
    .custom-card {
        background: var(--card-bg, #ffffff);
        border: 1px solid var(--border-color, #e2e8f0);
        border-radius: 20px;
        box-shadow: var(--shadow-sm, 0 2px 8px rgba(0,0,0,0.04));
    }

    .form-section {
        padding-bottom: 24px;
        margin-bottom: 24px;
        border-bottom: 1px dashed var(--border-color, #e2e8f0);
    }

    .section-title {
        color: var(--text-title, #17324d);
        font-size: 15px;
        font-weight: 700;
        margin-bottom: 18px;
        display: flex;
        align-items: center;
    }

    .custom-input {
        border: 1px solid var(--border-color, #cbd5e1);
        border-radius: 10px;
        padding: 10px 14px;
        font-size: 13.5px;
        color: var(--text-title, #17324d);
        background-color: var(--card-bg, #ffffff);
        transition: all 0.2s ease;
    }

    .custom-input:focus {
        border-color: #00b4d8;
        box-shadow: 0 0 0 0.25rem rgba(0, 180, 216, 0.15);
    }

    .upload-dropzone {
        min-height: 170px;
        border: 2px dashed var(--border-color, #cbd5e1);
        border-radius: 14px;
        background: var(--hover-bg, #f8fafc);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 24px;
        cursor: pointer;
        transition: border-color .2s ease, background .2s ease;
    }

    .upload-dropzone:hover,
    .upload-dropzone.is-dragging {
        border-color: #00b4d8;
        background: rgba(0, 180, 216, .06);
    }

    .file-input-hidden { display: none; }
    .dropzone-content, .dropzone-preview { width: 100%; text-align: center; }
    .upload-icon-box {
        width: 44px;
        height: 44px;
        margin: 0 auto 10px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #00b4d8;
        background: rgba(0, 180, 216, .12);
        font-size: 20px;
    }
    .upload-text { color: var(--text-title, #17324d); font-size: 13px; }
    .upload-hint { color: var(--text-subtitle, #64748b); font-size: 12px; margin: 6px 0 0; }
    .dropzone-preview { display: flex; align-items: center; justify-content: center; gap: 18px; }
    .dropzone-preview img { width: 100px; height: 100px; object-fit: cover; border-radius: 12px; border: 2px solid rgba(0, 180, 216, .35); }
    .preview-info { min-width: 0; display: flex; flex-direction: column; align-items: flex-start; gap: 5px; }
    .preview-info > span:first-child { max-width: 260px; }

    .form-footer {
        display: flex;
        justify-content: flex-end;
    }

    @media (max-width: 768px) {
        .page-header-custom {
            flex-direction: column;
            align-items: flex-start;
        }

        .form-footer {
            flex-direction: column-reverse;
            gap: 10px;
        }

        .btn-primary-custom, .btn-secondary-custom {
            width: 100%;
        }
    }
</style>

<?php $this->load->view('admin/template/footer'); ?>