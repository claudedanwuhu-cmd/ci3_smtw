<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('admin/template/header');
$this->load->view('admin/template/sidebar');
?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-trophy"></i>
                </div>
                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-star me-1"></i> Rekam Jejak Juara
                    </span>
                    <h2 class="page-title">Data Prestasi</h2>
                    <p class="page-subtitle">Kelola daftar pencapaian, penghargaan, dan kejuaraan sekolah.</p>
                </div>
            </div>
            <a href="<?= site_url('admin/prestasi/tambah'); ?>" class="btn-primary-custom">
                <i class="fa-solid fa-plus me-2"></i> Tambah Prestasi
            </a>
        </div>

        <!-- LIST TABLE CARD -->
        <div class="custom-card">
            <div class="card-header-custom d-flex justify-content-between align-items-center p-4 border-bottom">
                <div class="d-flex align-items-center gap-3">
                    <div class="header-subicon">
                        <i class="fa-solid fa-list-check"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold title-text">Daftar Prestasi</h5>
                        <small class="text-muted-custom">Rekapitulasi capaian dan kejuaraan siswa/sekolah</small>
                    </div>
                </div>
                <span class="badge-total">
                    <i class="fa-solid fa-ribbon me-1"></i> <?= count($prestasi); ?> Data Prestasi
                </span>
            </div>

            <div class="table-responsive p-3">
                <table class="table table-custom align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="text-center" style="width: 5%;">NO</th>
                            <th style="width: 10%;">GAMBAR</th>
                            <th style="width: 25%;">JUDUL PRESTASI</th>
                            <th style="width: 20%;">KATEGORI / TINGKAT</th>
                            <th style="width: 20%;">PEMENANG</th>
                            <th class="text-center" style="width: 10%;">TAHUN</th>
                            <th class="text-center" style="width: 10%;">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($prestasi)): ?>
                            <?php $no = 1; foreach ($prestasi as $p): ?>
                                <tr>
                                    <td class="text-center fw-bold text-muted-custom"><?= $no++; ?></td>
                                    <td>
                                        <?php if (!empty($p->foto)): ?>
                                            <img src="<?= base_url('uploads/prestasi/' . $p->foto); ?>" class="img-thumbnail-custom" alt="Foto Prestasi">
                                        <?php else: ?>
                                            <div class="img-placeholder">
                                                <i class="fa-solid fa-image text-muted-custom"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="fw-bold title-text"><?= $p->nama_prestasi; ?></div>
                                        <?php if (!empty($p->juara)): ?>
                                            <small class="text-accent-custom"><i class="fa-solid fa-medal me-1"></i><?= $p->juara; ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge-tingkat">
                                            <i class="fa-solid fa-layer-group me-1"></i><?= !empty($p->tingkat) ? $p->tingkat : '-'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center gap-2 text-muted-custom">
                                            <i class="fa-solid fa-user-graduate"></i>
                                            <span><?= !empty($p->nama_siswa) ? $p->nama_siswa : '-'; ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge-tahun">
                                            <?= !empty($p->tanggal) ? date('Y', strtotime($p->tanggal)) : '-'; ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <div class="d-flex justify-content-center gap-2">
                                            <a href="<?= site_url('admin/prestasi/edit/' . $p->id); ?>" class="btn-action btn-edit" title="Edit Data">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>
                                            <a href="<?= site_url('admin/prestasi/hapus/' . $p->id); ?>" class="btn-action btn-delete" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');" title="Hapus Data">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted-custom">
                                    <i class="fa-solid fa-inbox fa-3x mb-3 d-block opacity-50"></i>
                                    Belum ada data prestasi yang ditambahkan.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<style>
    :root {
        --pres-bg: #ffffff;
        --pres-subtle: #f8fafc;
        --pres-border: rgba(226, 232, 240, 0.8);
        --pres-title: #0f172a;
        --pres-subtitle: #64748b;
        --pres-hover: #f1f5f9;
        --pres-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.05);
        --pres-accent: #0ea5e9;
        --pres-accent-dark: #0284c7;
        --pres-th-bg: #f8fafc;
    }

    [data-theme="dark"], body.dark-mode {
        --pres-bg: #0f172a;
        --pres-subtle: #1e293b;
        --pres-border: rgba(255, 255, 255, 0.08);
        --pres-title: #f8fafc;
        --pres-subtitle: #94a3b8;
        --pres-hover: rgba(255, 255, 255, 0.04);
        --pres-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.4);
        --pres-accent: #38bdf8;
        --pres-accent-dark: #0284c7;
        --pres-th-bg: #162032;
    }

    .title-text { color: var(--pres-title); }
    .text-muted-custom { color: var(--pres-subtitle); }
    .text-accent-custom { color: var(--pres-accent); }

    .page-header-custom {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        padding: 22px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--pres-shadow);
    }

    .page-title { color: var(--pres-title); font-size: 22px; font-weight: 800; margin-bottom: 2px; }
    .page-subtitle { color: var(--pres-subtitle); font-size: 13px; margin-bottom: 0; }

    .page-header-icon, .header-subicon {
        width: 48px; height: 48px; border-radius: 14px;
        background: rgba(14, 165, 233, 0.1); border: 1px solid rgba(14, 165, 233, 0.2);
        color: var(--pres-accent); display: flex; align-items: center; justify-content: center; font-size: 20px;
    }
    .header-subicon { width: 38px; height: 38px; font-size: 16px; }

    .badge-header-tag {
        display: inline-flex; align-items: center; background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent); border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700;
    }

    .custom-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        box-shadow: var(--pres-shadow);
        overflow: hidden;
    }

    /* Modern Table Styling */
    .table-custom { color: var(--pres-title); border-collapse: separate; border-spacing: 0; }
    .table-custom th {
        background: var(--pres-th-bg); color: var(--pres-subtitle);
        font-size: 11px; font-weight: 700; letter-spacing: 0.5px;
        padding: 14px 16px; border-bottom: 1px solid var(--pres-border);
    }
    .table-custom td {
        background: var(--pres-bg);
        padding: 16px;
        border-bottom: 1px solid var(--pres-border);
        transition: background 0.2s ease;
    }
    .table-custom tbody tr:hover td { background: var(--pres-hover); }

    /* Custom Badges */
    .badge-total {
        background: rgba(14, 165, 233, 0.1); color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2); padding: 6px 14px;
        border-radius: 20px; font-size: 12px; font-weight: 600;
    }

    .badge-tingkat {
        background: var(--pres-subtle); color: var(--pres-accent);
        border: 1px solid var(--pres-border); padding: 5px 12px;
        border-radius: 8px; font-size: 12px; font-weight: 600;
    }

    .badge-tahun {
        background: var(--pres-subtle); color: var(--pres-title);
        border: 1px solid var(--pres-border); padding: 4px 10px;
        border-radius: 6px; font-size: 12px; font-weight: 700;
    }

    /* Images */
    .img-thumbnail-custom {
        width: 48px; height: 48px; border-radius: 10px;
        object-fit: cover; border: 1px solid var(--pres-border);
    }

    .img-placeholder {
        width: 48px; height: 48px; border-radius: 10px;
        background: var(--pres-subtle); border: 1px dashed var(--pres-border);
        display: flex; align-items: center; justify-content: center;
    }

    /* Buttons & Actions */
    .btn-primary-custom {
        display: inline-flex; align-items: center; justify-content: center;
        background: linear-gradient(135deg, var(--pres-accent) 0%, var(--pres-accent-dark) 100%);
        color: #ffffff !important; border-radius: 12px; padding: 10px 20px;
        font-size: 13.5px; font-weight: 700; text-decoration: none;
        transition: all 0.25s ease; box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3); border: none;
    }
    .btn-primary-custom:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(14, 165, 233, 0.45); }

    .btn-action {
        width: 34px; height: 34px; border-radius: 8px;
        display: inline-flex; align-items: center; justify-content: center;
        font-size: 13px; text-decoration: none; transition: all 0.2s ease;
    }
    .btn-edit { background: var(--pres-subtle); color: var(--pres-title); border: 1px solid var(--pres-border); }
    .btn-edit:hover { background: var(--pres-accent); color: #ffffff; border-color: var(--pres-accent); }
    .btn-delete { background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); }
    .btn-delete:hover { background: #ef4444; color: #ffffff; }
</style>

<?php $this->load->view('admin/template/footer'); ?>