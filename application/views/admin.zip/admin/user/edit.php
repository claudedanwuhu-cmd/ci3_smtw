<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- NOTIFIKASI ERROR -->
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger-custom mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-user-pen"></i>
                </div>
                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-users-gear me-1"></i> Manajemen User
                    </span>
                    <h2 class="page-title">Edit Pengguna</h2>
                    <p class="page-subtitle">Perbarui informasi akun, hak akses, dan status pengguna sistem.</p>
                </div>
            </div>
            <a href="<?= site_url('admin/user'); ?>" class="btn-secondary-custom">
                <i class="fa-solid fa-arrow-left me-2"></i> Kembali
            </a>
        </div>

        <!-- CARD KONTEN UTAMA -->
        <div class="custom-card">
            <div class="card-title-custom d-flex justify-content-between align-items-center p-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="section-icon">
                        <i class="fa-solid fa-user-gear"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold" style="color: var(--pres-title);">Formulir Perbarui Pengguna</h5>
                        <small class="text-muted-custom">Sesuaikan data kredensial atau peran akun di bawah ini</small>
                    </div>
                </div>
                <span class="total-badge">ID: <?= html_escape($user->id); ?></span>
            </div>

            <!-- FORM -->
            <form action="<?= site_url('admin/user/update/'.$user->id); ?>" method="post">
                <div class="p-4">
                    <div class="form-section">
                        <div class="row g-4">

                            <!-- NAMA LENGKAP -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Nama Lengkap <span class="text-danger">*</span>
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-user"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="nama" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($user->nama); ?>" 
                                        placeholder="Masukkan nama lengkap"
                                        required
                                    >
                                </div>
                            </div>

                            <!-- USERNAME -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Username <span class="text-danger">*</span>
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-at"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="username" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($user->username); ?>" 
                                        placeholder="Masukkan username"
                                        required
                                    >
                                </div>
                            </div>

                            <!-- PASSWORD BARU -->
                            <div class="col-md-6">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Password Baru
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-lock"></i>
                                    </span>
                                    <input 
                                        type="password" 
                                        name="password" 
                                        class="form-control-custom" 
                                        placeholder="Kosongkan jika tidak ingin mengubah password"
                                    >
                                </div>
                                <small class="text-muted-custom mt-1 d-block">
                                    <i class="fa-solid fa-circle-info text-accent-custom me-1"></i> Biarkan kosong apabila sandi tidak perlu diganti.
                                </small>
                            </div>

                            <!-- ROLE -->
                            <div class="col-md-3">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Role Akses <span class="text-danger">*</span>
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-shield-halved"></i>
                                    </span>
                                    <select name="role" class="form-control-custom form-select-custom">
                                        <option value="admin" <?= $user->role === 'admin' ? 'selected' : ''; ?>>Admin</option>
                                        <option value="petugas" <?= $user->role === 'petugas' ? 'selected' : ''; ?>>Petugas</option>
                                    </select>
                                </div>
                            </div>

                            <!-- STATUS -->
                            <div class="col-md-3">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Status Akun <span class="text-danger">*</span>
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-toggle-on"></i>
                                    </span>
                                    <select name="status" class="form-control-custom form-select-custom">
                                        <option value="aktif" <?= $user->status === 'aktif' ? 'selected' : ''; ?>>Aktif</option>
                                        <option value="nonaktif" <?= $user->status === 'nonaktif' ? 'selected' : ''; ?>>Nonaktif</option>
                                    </select>
                                </div>
                            </div>

                            <!-- FOTO -->
                            <div class="col-12">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Berkas Foto / Nama File Foto
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-image"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="foto" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($user->foto); ?>" 
                                        placeholder="Nama file foto atau direktori avatar"
                                    >
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <!-- FORM FOOTER ACTIONS -->
                <div class="card-footer-custom d-flex justify-content-between align-items-center p-4">
                    <a href="<?= site_url('admin/user'); ?>" class="btn-secondary-custom">
                        <i class="fa-solid fa-xmark me-2"></i> Batal
                    </a>
                    <button type="submit" class="btn-primary-custom">
                        <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>

<!-- STYLES KUSTOM DINAMIS (DARK/LIGHT MODE ADAPTIVE SESUAI TAMPILAN GURU) -->
<style>
    :root {
        --pres-bg: #ffffff;
        --pres-subtle: #f8fafc;
        --pres-border: rgba(226, 232, 240, 0.8);
        --pres-input-bg: #ffffff;
        --pres-title: #0f172a;
        --pres-subtitle: #64748b;
        --pres-hover: #f1f5f9;
        --pres-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.05);
        --pres-accent: #0ea5e9;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(14, 165, 233, 0.15);
    }

    [data-theme="dark"], [data-bs-theme="dark"], body.dark-mode, .dark-mode {
        --pres-bg: #0f172a;
        --pres-subtle: #1e293b;
        --pres-border: rgba(255, 255, 255, 0.08);
        --pres-input-bg: #1e293b;
        --pres-title: #f8fafc;
        --pres-subtitle: #94a3b8;
        --pres-hover: rgba(255, 255, 255, 0.03);
        --pres-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.4);
        --pres-accent: #38bdf8;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(56, 189, 248, 0.2);
    }

    .text-muted-custom { color: var(--pres-subtitle); }
    .text-accent-custom { color: var(--pres-accent); }

    /* Alert Error */
    .alert-danger-custom {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
        padding: 14px 20px;
        border-radius: 14px;
        font-weight: 600;
        font-size: 14px;
    }

    /* Header */
    .page-header-custom {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        padding: 22px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--pres-shadow);
        gap: 20px;
    }

    .badge-header-tag {
        display: inline-flex;
        align-items: center;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .page-title {
        color: var(--pres-title);
        font-size: 22px;
        font-weight: 800;
        margin-bottom: 2px;
    }

    .page-subtitle {
        color: var(--pres-subtitle);
        font-size: 13px;
        margin-bottom: 0;
    }

    .page-header-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        background: var(--pres-subtle);
        border: 1px solid var(--pres-border);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }

    /* Card Wrapper */
    .custom-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--pres-shadow);
    }

    .card-title-custom {
        border-bottom: 1px solid var(--pres-border);
        background: var(--pres-bg);
    }

    .card-footer-custom {
        border-top: 1px solid var(--pres-border);
        background: var(--pres-subtle);
    }

    .total-badge {
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
    }

    .section-icon {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    /* Form Controls & Inputs Styling */
    .input-group-custom {
        position: relative;
        display: flex;
        align-items: center;
    }

    .input-group-icon {
        position: absolute;
        left: 16px;
        color: var(--pres-subtitle);
        font-size: 14px;
        z-index: 5;
        pointer-events: none;
    }

    .form-control-custom {
        width: 100%;
        background: var(--pres-input-bg);
        border: 1px solid var(--pres-border);
        color: var(--pres-title);
        border-radius: 12px;
        padding: 12px 16px 12px 46px;
        font-size: 13.5px;
        transition: all 0.25s ease;
    }

    .form-select-custom {
        appearance: none;
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='%2364748b' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='m2 5 6 6 6-6'/%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 1rem center;
        background-size: 16px 12px;
        padding-right: 40px;
    }

    .form-control-custom:focus {
        background: var(--pres-input-bg);
        border-color: var(--pres-accent);
        box-shadow: 0 0 0 4px var(--pres-accent-glow);
        color: var(--pres-title);
        outline: none;
    }

    .form-control-custom::placeholder {
        color: var(--pres-subtitle);
        opacity: 0.6;
    }

    /* Buttons */
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, var(--pres-accent) 0%, var(--pres-accent-dark) 100%);
        color: #ffffff !important;
        border-radius: 12px;
        padding: 11px 22px;
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        border: none;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(14, 165, 233, 0.45);
    }

    .btn-secondary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: var(--pres-subtle);
        color: var(--pres-title) !important;
        border: 1px solid var(--pres-border);
        border-radius: 12px;
        padding: 11px 22px;
        font-size: 13.5px;
        font-weight: 600;
        text-decoration: none;
        transition: all 0.2s ease;
    }

    .btn-secondary-custom:hover {
        background: var(--pres-hover);
        border-color: var(--pres-accent);
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .page-header-custom, .card-footer-custom {
            flex-direction: column;
            align-items: stretch;
            gap: 12px;
        }
        .btn-primary-custom, .btn-secondary-custom {
            width: 100%;
            justify-content: center;
        }
    }
</style>

<?php $this->load->view('admin/template/footer'); ?>