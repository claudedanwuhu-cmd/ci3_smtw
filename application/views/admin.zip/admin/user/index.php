<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- NOTIFIKASI SUKSES -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success-custom mb-4">
                <i class="fa-solid fa-circle-check me-2"></i>
                <?= html_escape($this->session->flashdata('success')); ?>
            </div>
        <?php endif; ?>

        <!-- NOTIFIKASI ERROR -->
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger-custom mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-users-gear"></i>
                </div>
                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-shield-halved me-1"></i> Kontrol Akses
                    </span>
                    <h2 class="page-title">Manajemen User</h2>
                    <p class="page-subtitle">Kelola akun administrator dan petugas CMS dengan mudah dan aman.</p>
                </div>
            </div>
            <a href="<?= site_url('admin/user/tambah'); ?>" class="btn-primary-custom">
                <i class="fa-solid fa-user-plus me-2"></i> Tambah User Baru
            </a>
        </div>

        <!-- CARD KONTEN UTAMA -->
        <div class="custom-card">
            <div class="card-title-custom d-flex justify-content-between align-items-center p-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="section-icon">
                        <i class="fa-solid fa-users"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold" style="color: var(--pres-title);">Daftar Pengguna Sistem</h5>
                        <small class="text-muted-custom">Daftar akun yang memiliki hak akses ke dalam panel CMS</small>
                    </div>
                </div>
                <span class="total-badge"><?= !empty($users) ? count($users) : 0; ?> Data User</span>
            </div>

            <!-- TABEL RESPONSIF -->
            <div class="table-responsive">
                <table class="table custom-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-4" style="width: 5%;">No</th>
                            <th style="width: 25%;">Nama Lengkap</th>
                            <th style="width: 20%;">Username</th>
                            <th style="width: 15%;">Role</th>
                            <th style="width: 12%;">Status</th>
                            <th style="width: 13%;">Dibuat</th>
                            <th class="text-end pe-4" style="width: 10%;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($users)): $no = 1; foreach ($users as $item): ?>
                            <tr>
                                <td class="ps-4 fw-bold text-muted-custom"><?= $no++; ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="user-avatar-initial">
                                            <?= strtoupper(substr($item->nama, 0, 1)); ?>
                                        </div>
                                        <div class="item-title fw-bold" style="color: var(--pres-title);">
                                            <?= html_escape($item->nama); ?>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <code class="username-tag"><?= html_escape($item->username); ?></code>
                                </td>
                                <td>
                                    <span class="badge-role">
                                        <i class="fa-solid fa-user-shield me-1"></i><?= ucfirst($item->role); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($item->status === 'aktif'): ?>
                                        <span class="status-badge active">Aktif</span>
                                    <?php else: ?>
                                        <span class="status-badge inactive">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-muted-custom small">
                                    <?= !empty($item->created_at) ? date('d M Y', strtotime($item->created_at)) : '-'; ?>
                                </td>
                                <td class="text-end pe-4">
                                    <div class="action-buttons justify-content-end">
                                        <a href="<?= site_url('admin/user/edit/'.$item->id); ?>" class="btn-action edit" title="Edit User">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                        <?php if ((int) $item->id !== (int) $this->session->userdata('user_id')): ?>
                                            <a href="<?= site_url('admin/user/hapus/'.$item->id); ?>" class="btn-action delete" title="Hapus User" onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?');">
                                                <i class="fa-solid fa-trash"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <div class="empty-data-container">
                                        <div class="empty-icon mb-3">
                                            <i class="fa-solid fa-users-slash fa-2x"></i>
                                        </div>
                                        <h6 class="fw-bold text-muted-custom mb-1">Belum Ada Data Pengguna</h6>
                                        <p class="small text-muted-custom mb-0">Silakan tambahkan user baru melalui tombol di atas.</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<!-- STYLES KUSTOM DINAMIS (DARK/LIGHT MODE ADAPTIVE SESUAI TAMPILAN GURU) -->
<style>
    :root {
        --pres-bg: #ffffff;
        --pres-subtle: #f8fafc;
        --pres-border: rgba(226, 232, 240, 0.8);
        --pres-input-bg: #ffffff;
        --pres-title: #0f172a;
        --pres-subtitle: #64748b;
        --pres-hover: #f1f5f9;
        --pres-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.05);
        --pres-accent: #0ea5e9;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(14, 165, 233, 0.15);
    }

    [data-theme="dark"], [data-bs-theme="dark"], body.dark-mode, .dark-mode {
        --pres-bg: #0f172a;
        --pres-subtle: #1e293b;
        --pres-border: rgba(255, 255, 255, 0.08);
        --pres-input-bg: #1e293b;
        --pres-title: #f8fafc;
        --pres-subtitle: #94a3b8;
        --pres-hover: rgba(255, 255, 255, 0.03);
        --pres-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.4);
        --pres-accent: #38bdf8;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(56, 189, 248, 0.2);
    }

    .text-muted-custom { color: var(--pres-subtitle); }
    .text-accent-custom { color: var(--pres-accent); }

    /* Alert Notifications */
    .alert-success-custom {
        background: rgba(34, 197, 94, 0.1);
        color: #22c55e;
        border: 1px solid rgba(34, 197, 94, 0.2);
        padding: 14px 20px;
        border-radius: 14px;
        font-weight: 600;
        font-size: 14px;
    }

    .alert-danger-custom {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
        padding: 14px 20px;
        border-radius: 14px;
        font-weight: 600;
        font-size: 14px;
    }

    /* Header */
    .page-header-custom {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        padding: 22px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--pres-shadow);
        gap: 20px;
    }

    .badge-header-tag {
        display: inline-flex;
        align-items: center;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .page-title {
        color: var(--pres-title);
        font-size: 22px;
        font-weight: 800;
        margin-bottom: 2px;
    }

    .page-subtitle {
        color: var(--pres-subtitle);
        font-size: 13px;
        margin-bottom: 0;
    }

    .page-header-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        background: var(--pres-subtle);
        border: 1px solid var(--pres-border);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }

    /* Card Wrapper */
    .custom-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--pres-shadow);
    }

    .card-title-custom {
        border-bottom: 1px solid var(--pres-border);
        background: var(--pres-bg);
    }

    .total-badge {
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
    }

    .section-icon {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    /* Custom Table Styling */
    .custom-table {
        color: var(--pres-title);
        white-space: nowrap;
        margin-bottom: 0;
    }

    .custom-table th {
        background: var(--pres-subtle);
        color: var(--pres-subtitle);
        font-weight: 700;
        font-size: 11.5px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid var(--pres-border);
        padding: 14px 16px;
    }

    .custom-table td {
        background: var(--pres-bg);
        border-bottom: 1px solid var(--pres-border);
        padding: 14px 16px;
        font-size: 13.5px;
    }

    .custom-table tbody tr:hover td {
        background: var(--pres-hover);
    }

    /* Table Elements */
    .user-avatar-initial {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background: rgba(14, 165, 233, 0.15);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 13px;
        border: 1px solid rgba(14, 165, 233, 0.3);
    }

    .username-tag {
        background: var(--pres-subtle);
        color: var(--pres-accent);
        padding: 4px 8px;
        border-radius: 6px;
        font-size: 12px;
        border: 1px solid var(--pres-border);
    }

    .badge-role {
        display: inline-flex;
        align-items: center;
        background: rgba(139, 92, 246, 0.1);
        color: #8b5cf6;
        border: 1px solid rgba(139, 92, 246, 0.2);
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11.5px;
        font-weight: 700;
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: 11.5px;
        font-weight: 700;
    }

    .status-badge.active {
        background: rgba(34, 197, 94, 0.1);
        color: #22c55e;
        border: 1px solid rgba(34, 197, 94, 0.2);
    }

    .status-badge.inactive {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
    }

    /* Action Buttons */
    .action-buttons {
        display: flex;
        gap: 6px;
    }

    .btn-action {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        transition: all 0.2s ease;
        text-decoration: none;
    }

    .btn-action.edit {
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
    }

    .btn-action.edit:hover {
        background: var(--pres-accent);
        color: #fff;
    }

    .btn-action.delete {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
    }

    .btn-action.delete:hover {
        background: #ef4444;
        color: #fff;
    }

    /* Empty state */
    .empty-data-container {
        padding: 30px;
        color: var(--pres-subtitle);
    }

    .empty-icon {
        color: var(--pres-subtitle);
        opacity: 0.5;
    }

    /* Buttons */
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, var(--pres-accent) 0%, var(--pres-accent-dark) 100%);
        color: #ffffff !important;
        border-radius: 12px;
        padding: 11px 22px;
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        border: none;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(14, 165, 233, 0.45);
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .page-header-custom {
            flex-direction: column;
            align-items: stretch;
            gap: 12px;
        }
        .btn-primary-custom {
            width: 100%;
            justify-content: center;
        }
    }
</style>

<?php $this->load->view('admin/template/footer'); ?>