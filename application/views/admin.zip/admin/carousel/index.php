<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success mb-4">
                <i class="fa-solid fa-circle-check me-2"></i>
                <?= html_escape($this->session->flashdata('success')); ?>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- Page Header -->
        <div class="page-header-custom mb-4">
            <div class="page-header-left">
                <div class="page-header-icon">
                    <i class="fa-solid fa-images"></i>
                </div>

                <div>
                    <span class="badge-header-tag">CAROUSEL</span>
                    <h2 class="page-title">Carousel Beranda</h2>
                    <p class="page-subtitle">
                        Kelola banner utama yang tampil pada halaman depan sekolah.
                    </p>
                </div>
            </div>

            <a href="<?= site_url('admin/carousel/tambah'); ?>" class="btn-add">
                <i class="fa-solid fa-plus me-2"></i>
                Tambah Carousel
            </a>
        </div>

        <!-- List Card -->
        <div class="custom-card">

            <div class="card-title-custom justify-content-between">
                <div class="card-title-left">
                    <div class="title-icon">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>

                    <div>
                        <h5>Daftar Carousel</h5>
                        <small>Banner halaman depan sekolah</small>
                    </div>
                </div>

                <span class="total-badge">
                    <?= count($carousel); ?> Data
                </span>
            </div>

            <div class="table-responsive">
                <table class="table custom-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th width="70">No</th>
                            <th width="180">Gambar</th>
                            <th>Konten</th>
                            <th width="90">Urutan</th>
                            <th width="120">Status</th>
                            <th width="110" class="text-end">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (!empty($carousel)): ?>

                        <?php $no = 1; ?>

                        <?php foreach ($carousel as $item): ?>

                            <tr>

                                <!-- No -->
                                <td>
                                    <?= $no++; ?>
                                </td>

                                <!-- Gambar -->
                                <td>
                                    <div class="carousel-list-image">
                                        <img
                                            src="<?= base_url('assets/img/' . $item->gambar); ?>"
                                            alt="<?= html_escape($item->judul); ?>"
                                        >
                                    </div>
                                </td>

                                <!-- Konten -->
                                <td>
                                    <div class="item-title">
                                        <?= html_escape($item->judul); ?>
                                    </div>

                                    <?php if (!empty($item->deskripsi)): ?>
                                        <small class="item-description">
                                            <?= html_escape($item->deskripsi); ?>
                                        </small>
                                    <?php else: ?>
                                        <small class="item-description">
                                            Tidak ada deskripsi
                                        </small>
                                    <?php endif; ?>

                                    <?php if (!empty($item->tombol)): ?>
                                        <div class="carousel-button-info">
                                            <i class="fa-solid fa-hand-pointer"></i>
                                            <?= html_escape($item->tombol); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>

                                <!-- Urutan -->
                                <td>
                                    <span class="order-badge">
                                        <?= (int) $item->urutan; ?>
                                    </span>
                                </td>

                                <!-- Status -->
                                <td>
                                    <span class="status-badge <?= $item->status === 'aktif' ? 'active' : 'inactive'; ?>">
                                        <i class="fa-solid <?= $item->status === 'aktif' ? 'fa-circle-check' : 'fa-circle-xmark'; ?>"></i>
                                        <?= ucfirst($item->status); ?>
                                    </span>
                                </td>

                                <!-- Aksi -->
                                <td>
                                    <div class="action-buttons justify-content-end">

                                        <a
                                            href="<?= site_url('admin/carousel/edit/' . $item->id); ?>"
                                            class="btn-action edit"
                                            title="Edit"
                                        >
                                            <i class="fa-solid fa-pen"></i>
                                        </a>

                                        <a
                                            href="<?= site_url('admin/carousel/hapus/' . $item->id); ?>"
                                            class="btn-action delete"
                                            title="Hapus"
                                            onclick="return confirm('Yakin ingin menghapus carousel ini?');"
                                        >
                                            <i class="fa-solid fa-trash"></i>
                                        </a>

                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="6" class="empty-data">

                                <div class="empty-icon">
                                    <i class="fa-solid fa-images"></i>
                                </div>

                                <strong>Belum ada carousel</strong>

                                <small>
                                    Tambahkan gambar pertama untuk halaman depan sekolah.
                                </small>

                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>
                </table>
            </div>

        </div>

    </div>
</div>

<style>
/* ================================
   CAROUSEL LIST - GURU MASTER
================================ */

:root {
    --carousel-card-bg: #ffffff;
    --carousel-card-subtle: #f8fafc;
    --carousel-title: #0f172a;
    --carousel-subtitle: #64748b;
    --carousel-border: rgba(226, 232, 240, .8);
    --carousel-hover: #f8fafc;
    --carousel-accent: #0ea5e9;
    --carousel-icon-muted: #94a3b8;
}

.page-header-custom {
    background: var(--carousel-card-bg);
    border: 1px solid var(--carousel-border);
    border-radius: 20px;
    padding: 24px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.page-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.page-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .18);
    color: var(--carousel-accent);
    font-size: 21px;
    flex-shrink: 0;
}

.badge-header-tag {
    display: inline-flex;
    padding: 4px 9px;
    margin-bottom: 5px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .1);
    color: var(--carousel-accent);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
}

.page-title {
    color: var(--carousel-title);
    font-size: 22px;
    font-weight: 800;
    margin: 0;
}

.page-subtitle {
    color: var(--carousel-subtitle);
    font-size: 13px;
    margin: 5px 0 0;
}

.btn-add {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 42px;
    padding: 0 17px;
    border-radius: 12px;
    background: linear-gradient(135deg, #0284c7, #0369a1);
    color: #fff;
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 5px 15px rgba(3, 105, 161, .2);
    transition: .2s ease;
}

.btn-add:hover {
    color: #fff;
    transform: translateY(-1px);
    box-shadow: 0 8px 18px rgba(3, 105, 161, .25);
}

.custom-card {
    background: var(--carousel-card-bg);
    border: 1px solid var(--carousel-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.card-title-custom {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 24px;
    background: var(--carousel-card-subtle);
    border-bottom: 1px solid var(--carousel-border);
}

.card-title-left {
    display: flex;
    align-items: center;
    gap: 14px;
}

.title-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .15);
    color: var(--carousel-accent);
}

.card-title-custom h5 {
    color: var(--carousel-title);
    font-size: 15px;
    font-weight: 800;
    margin: 0;
}

.card-title-custom small {
    display: block;
    color: var(--carousel-subtitle);
    font-size: 12px;
    margin-top: 3px;
}

.total-badge {
    display: inline-flex;
    align-items: center;
    padding: 6px 11px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .1);
    color: var(--carousel-accent);
    font-size: 11px;
    font-weight: 800;
}

.custom-table {
    color: var(--carousel-title);
    margin: 0;
}

.custom-table thead th {
    background: var(--carousel-card-subtle);
    color: var(--carousel-subtitle);
    border-bottom: 1px solid var(--carousel-border);
    padding: 13px 18px;
    font-size: 10.5px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .4px;
    white-space: nowrap;
}

.custom-table tbody td {
    padding: 14px 18px;
    border-bottom: 1px solid var(--carousel-border);
    color: var(--carousel-title);
    font-size: 13px;
    vertical-align: middle;
}

.custom-table tbody tr {
    transition: .15s ease;
}

.custom-table tbody tr:hover {
    background: var(--carousel-hover);
}

.custom-table tbody tr:last-child td {
    border-bottom: 0;
}

.carousel-list-image {
    width: 150px;
    height: 82px;
    overflow: hidden;
    border-radius: 11px;
    border: 1px solid var(--carousel-border);
    background: var(--carousel-card-subtle);
}

.carousel-list-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: .25s ease;
}

.custom-table tbody tr:hover .carousel-list-image img {
    transform: scale(1.03);
}

.item-title {
    color: var(--carousel-title);
    font-size: 13.5px;
    font-weight: 700;
    margin-bottom: 4px;
}

.item-description {
    display: block;
    max-width: 430px;
    color: var(--carousel-subtitle);
    font-size: 11.5px;
    line-height: 1.5;
}

.carousel-button-info {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    margin-top: 7px;
    padding: 4px 8px;
    border-radius: 7px;
    background: rgba(14, 165, 233, .08);
    color: var(--carousel-accent);
    font-size: 10.5px;
    font-weight: 700;
}

.order-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 30px;
    height: 28px;
    padding: 0 8px;
    border-radius: 8px;
    background: var(--carousel-card-subtle);
    border: 1px solid var(--carousel-border);
    color: var(--carousel-title);
    font-size: 12px;
    font-weight: 700;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 9px;
    border-radius: 999px;
    font-size: 10.5px;
    font-weight: 700;
}

.status-badge.active {
    color: #15803d;
    background: rgba(34, 197, 94, .1);
}

.status-badge.inactive {
    color: #dc2626;
    background: rgba(239, 68, 68, .1);
}

.action-buttons {
    display: flex;
    align-items: center;
    gap: 7px;
}

.btn-action {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: .2s ease;
}

.btn-action.edit {
    color: var(--carousel-accent);
    background: rgba(14, 165, 233, .1);
}

.btn-action.edit:hover {
    color: #fff;
    background: var(--carousel-accent);
    transform: translateY(-1px);
}

.btn-action.delete {
    color: #ef4444;
    background: rgba(239, 68, 68, .1);
}

.btn-action.delete:hover {
    color: #fff;
    background: #ef4444;
    transform: translateY(-1px);
}

.empty-data {
    padding: 60px 20px !important;
    text-align: center;
    color: var(--carousel-subtitle) !important;
}

.empty-icon {
    width: 64px;
    height: 64px;
    margin: 0 auto 14px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .08);
    color: var(--carousel-accent);
    font-size: 24px;
}

.empty-data strong {
    display: block;
    color: var(--carousel-title);
    font-size: 14px;
}

.empty-data small {
    display: block;
    margin-top: 4px;
    color: var(--carousel-subtitle);
    font-size: 12px;
}

@media (max-width: 768px) {
    .page-header-custom {
        align-items: stretch;
        flex-direction: column;
        padding: 20px;
    }

    .page-header-left {
        align-items: flex-start;
    }

    .btn-add {
        width: 100%;
    }

    .carousel-list-image {
        width: 120px;
        height: 68px;
    }

    .custom-table thead th,
    .custom-table tbody td {
        padding: 12px;
    }
}

/* Dark Mode */
[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --carousel-card-bg: #0f172a;
    --carousel-card-subtle: #1e293b;
    --carousel-title: #f8fafc;
    --carousel-subtitle: #94a3b8;
    --carousel-border: rgba(148, 163, 184, .16);
    --carousel-hover: #1e293b;
    --carousel-accent: #38bdf8;
    --carousel-icon-muted: #94a3b8;
}
</style>

<?php $this->load->view('admin/template/footer'); ?>