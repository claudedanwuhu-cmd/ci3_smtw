<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- Page Header -->
        <div class="page-header-custom mb-4">
            <div class="page-header-left">
                <div class="page-header-icon">
                    <i class="fa-solid fa-images"></i>
                </div>

                <div>
                    <span class="badge-header-tag">CAROUSEL</span>
                    <h2 class="page-title">Edit Carousel</h2>
                    <p class="page-subtitle">
                        Perbarui banner yang tampil pada halaman depan sekolah.
                    </p>
                </div>
            </div>

            <a href="<?= site_url('admin/carousel'); ?>" class="btn-back">
                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali
            </a>
        </div>

        <!-- Form Card -->
        <div class="custom-card">
            <div class="card-title-custom">
                <div class="title-icon">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>

                <div>
                    <h5>Edit Data Carousel</h5>
                    <small>Perbarui informasi banner halaman depan.</small>
                </div>
            </div>

            <form action="<?= site_url('admin/carousel/update/' . $carousel->id); ?>"
                  method="post"
                  enctype="multipart/form-data">

                <div class="card-body-custom">
                    <div class="row g-4">

                        <!-- Judul -->
                        <div class="col-md-8">
                            <label class="form-label">
                                Judul <span class="text-danger">*</span>
                            </label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-heading"></i>
                                <input
                                    type="text"
                                    name="judul"
                                    class="form-control custom-input with-icon"
                                    value="<?= html_escape($carousel->judul); ?>"
                                    placeholder="Masukkan judul carousel"
                                    required
                                >
                            </div>
                        </div>

                        <!-- Urutan -->
                        <div class="col-md-4">
                            <label class="form-label">Urutan</label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-arrow-down-1-9"></i>
                                <input
                                    type="number"
                                    name="urutan"
                                    class="form-control custom-input with-icon"
                                    value="<?= (int) $carousel->urutan; ?>"
                                    min="0"
                                    placeholder="0"
                                >
                            </div>
                        </div>

                        <!-- Deskripsi -->
                        <div class="col-12">
                            <label class="form-label">Deskripsi</label>

                            <textarea
                                name="deskripsi"
                                rows="5"
                                class="form-control custom-input custom-textarea"
                                placeholder="Masukkan deskripsi carousel..."
                            ><?= html_escape($carousel->deskripsi); ?></textarea>
                        </div>

                        <!-- Teks Tombol -->
                        <div class="col-md-6">
                            <label class="form-label">Teks Tombol</label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-hand-pointer"></i>
                                <input
                                    type="text"
                                    name="tombol"
                                    class="form-control custom-input with-icon"
                                    value="<?= html_escape($carousel->tombol); ?>"
                                    placeholder="Contoh: Jelajahi Sekolah"
                                >
                            </div>
                        </div>

                        <!-- Link Tombol -->
                        <div class="col-md-6">
                            <label class="form-label">Link Tombol</label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-link"></i>
                                <input
                                    type="text"
                                    name="link"
                                    class="form-control custom-input with-icon"
                                    value="<?= html_escape($carousel->link); ?>"
                                    placeholder="Contoh: #tentang"
                                >
                            </div>
                        </div>

                        <!-- Gambar -->
                        <div class="col-md-8">
                            <label class="form-label">Ganti Gambar</label>

                            <div class="carousel-upload-box" id="carousel-upload-box">
                                <input
                                    type="file"
                                    name="gambar"
                                    id="carousel-gambar-input"
                                    class="file-input-hidden"
                                    accept="image/png,image/jpeg,image/webp"
                                >

                                <div class="upload-content">
                                    <div class="upload-icon">
                                        <i class="fa-solid fa-cloud-arrow-up"></i>
                                    </div>

                                    <div>
                                        <strong id="carousel-upload-label">
                                            Klik untuk mengganti gambar
                                        </strong>
                                        <small>
                                            JPG, PNG, WEBP • Maksimal 4 MB
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Status -->
                        <div class="col-md-4">
                            <label class="form-label">Status</label>

                            <div class="status-selector">

                                <label class="status-option <?= $carousel->status === 'aktif' ? 'selected' : ''; ?>">
                                    <input
                                        type="radio"
                                        name="status"
                                        value="aktif"
                                        <?= $carousel->status === 'aktif' ? 'checked' : ''; ?>
                                    >

                                    <span class="status-option-icon">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </span>

                                    <span>
                                        <strong>Aktif</strong>
                                        <small>Ditampilkan</small>
                                    </span>
                                </label>

                                <label class="status-option <?= $carousel->status === 'nonaktif' ? 'selected' : ''; ?>">
                                    <input
                                        type="radio"
                                        name="status"
                                        value="nonaktif"
                                        <?= $carousel->status === 'nonaktif' ? 'checked' : ''; ?>
                                    >

                                    <span class="status-option-icon">
                                        <i class="fa-solid fa-circle-xmark"></i>
                                    </span>

                                    <span>
                                        <strong>Nonaktif</strong>
                                        <small>Tidak ditampilkan</small>
                                    </span>
                                </label>

                            </div>
                        </div>

                        <!-- Preview -->
                        <div class="col-12">
                            <label class="form-label">Preview Gambar</label>

                            <div class="carousel-preview-wrapper">
                                <img
                                    id="carousel-gambar-preview"
                                    src="<?= base_url('assets/img/' . $carousel->gambar); ?>"
                                    alt="<?= html_escape($carousel->judul); ?>"
                                    class="carousel-image-preview"
                                >
                            </div>
                        </div>

                    </div>
                </div>

                <!-- Footer -->
                <div class="form-footer">
                    <a href="<?= site_url('admin/carousel'); ?>" class="btn-cancel">
                        <i class="fa-solid fa-xmark me-2"></i>
                        Batal
                    </a>

                    <button type="submit" class="btn-save">
                        <i class="fa-solid fa-floppy-disk me-2"></i>
                        Simpan Perubahan
                    </button>
                </div>

            </form>
        </div>

    </div>
</div>

<style>
/* ================================
   CAROUSEL - GURU MASTER STYLE
================================ */

:root {
    --carousel-bg: #f8fafc;
    --carousel-card-bg: #ffffff;
    --carousel-card-subtle: #f8fafc;
    --carousel-input-bg: #f8fafc;
    --carousel-input-border: #cbd5e1;
    --carousel-input-color: #0f172a;
    --carousel-title: #0f172a;
    --carousel-subtitle: #64748b;
    --carousel-border: rgba(226, 232, 240, .8);
    --carousel-hover: #f8fafc;
    --carousel-accent: #0ea5e9;
    --carousel-icon-muted: #94a3b8;
}

.page-header-custom {
    background: var(--carousel-card-bg);
    border: 1px solid var(--carousel-border);
    border-radius: 20px;
    padding: 24px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.page-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.page-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .18);
    color: var(--carousel-accent);
    font-size: 21px;
    flex-shrink: 0;
}

.badge-header-tag {
    display: inline-flex;
    align-items: center;
    padding: 4px 9px;
    margin-bottom: 5px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .1);
    color: var(--carousel-accent);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
}

.page-title {
    color: var(--carousel-title);
    font-size: 22px;
    font-weight: 800;
    margin: 0;
}

.page-subtitle {
    color: var(--carousel-subtitle);
    font-size: 13px;
    margin: 5px 0 0;
}

.btn-back,
.btn-cancel {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 42px;
    padding: 0 16px;
    border-radius: 12px;
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
    color: var(--carousel-title);
    background: var(--carousel-card-bg);
    border: 1px solid var(--carousel-input-border);
    transition: .2s ease;
}

.btn-back:hover,
.btn-cancel:hover {
    color: var(--carousel-accent);
    border-color: var(--carousel-accent);
    transform: translateY(-1px);
}

.custom-card {
    background: var(--carousel-card-bg);
    border: 1px solid var(--carousel-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.card-title-custom {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 24px;
    background: var(--carousel-card-subtle);
    border-bottom: 1px solid var(--carousel-border);
}

.card-title-custom h5 {
    color: var(--carousel-title);
    font-size: 15px;
    font-weight: 800;
    margin: 0;
}

.card-title-custom small {
    display: block;
    color: var(--carousel-subtitle);
    font-size: 12px;
    margin-top: 3px;
}

.title-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .15);
    color: var(--carousel-accent);
}

.card-body-custom {
    padding: 26px 28px;
}

.form-label {
    display: block;
    color: var(--carousel-title);
    font-size: 12.5px;
    font-weight: 700;
    margin-bottom: 8px;
}

.custom-input {
    min-height: 44px;
    background: var(--carousel-input-bg);
    border: 1px solid var(--carousel-input-border);
    color: var(--carousel-input-color);
    border-radius: 12px;
    font-size: 13.5px;
    transition: .2s ease;
}

.custom-input:focus {
    background: #fff;
    color: var(--carousel-input-color);
    border-color: var(--carousel-accent);
    box-shadow: 0 0 0 3px rgba(14, 165, 233, .1);
}

.custom-input::placeholder {
    color: var(--carousel-icon-muted);
}

.input-icon-group {
    position: relative;
}

.input-icon-group > i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--carousel-icon-muted);
    font-size: 14px;
    z-index: 2;
    pointer-events: none;
}

.with-icon {
    padding-left: 40px;
}

.custom-textarea {
    min-height: 120px;
    resize: vertical;
    padding: 12px 14px;
}

.carousel-upload-box {
    min-height: 92px;
    border: 2px dashed var(--carousel-input-border);
    border-radius: 14px;
    background: var(--carousel-input-bg);
    display: flex;
    align-items: center;
    padding: 16px 18px;
    cursor: pointer;
    transition: .2s ease;
}

.carousel-upload-box:hover {
    border-color: var(--carousel-accent);
    background: rgba(14, 165, 233, .04);
}

.file-input-hidden {
    display: none;
}

.upload-content {
    display: flex;
    align-items: center;
    gap: 14px;
}

.upload-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    color: var(--carousel-accent);
    font-size: 17px;
    flex-shrink: 0;
}

.upload-content strong {
    display: block;
    color: var(--carousel-title);
    font-size: 13px;
    font-weight: 700;
}

.upload-content small {
    display: block;
    color: var(--carousel-subtitle);
    font-size: 11.5px;
    margin-top: 3px;
}

.status-selector {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
}

.status-option {
    min-height: 72px;
    padding: 11px;
    border: 1px solid var(--carousel-input-border);
    border-radius: 12px;
    background: var(--carousel-input-bg);
    display: flex;
    align-items: center;
    gap: 9px;
    cursor: pointer;
    transition: .2s ease;
}

.status-option input {
    display: none;
}

.status-option-icon {
    width: 32px;
    height: 32px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(100, 116, 139, .1);
    color: var(--carousel-icon-muted);
    flex-shrink: 0;
}

.status-option strong {
    display: block;
    color: var(--carousel-title);
    font-size: 12px;
}

.status-option small {
    display: block;
    color: var(--carousel-subtitle);
    font-size: 10.5px;
    margin-top: 2px;
}

.status-option.selected {
    border-color: rgba(14, 165, 233, .55);
    background: rgba(14, 165, 233, .06);
}

.status-option.selected .status-option-icon {
    background: rgba(14, 165, 233, .12);
    color: var(--carousel-accent);
}

.carousel-preview-wrapper {
    padding: 10px;
    border: 1px solid var(--carousel-border);
    border-radius: 14px;
    background: var(--carousel-card-subtle);
    display: inline-block;
    max-width: 100%;
}

.carousel-image-preview {
    display: block;
    width: min(560px, 100%);
    height: 210px;
    object-fit: cover;
    border-radius: 10px;
    border: 1px solid var(--carousel-border);
}

.form-footer {
    padding: 18px 24px;
    background: var(--carousel-card-subtle);
    border-top: 1px solid var(--carousel-border);
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.btn-save {
    min-height: 42px;
    padding: 0 18px;
    border: 0;
    border-radius: 12px;
    color: #fff;
    background: linear-gradient(135deg, #0284c7, #0369a1);
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 5px 15px rgba(3, 105, 161, .2);
    transition: .2s ease;
}

.btn-save:hover {
    color: #fff;
    transform: translateY(-1px);
    box-shadow: 0 8px 18px rgba(3, 105, 161, .25);
}

@media (max-width: 768px) {
    .page-header-custom {
        align-items: stretch;
        flex-direction: column;
        padding: 20px;
    }

    .page-header-left {
        align-items: flex-start;
    }

    .btn-back {
        width: 100%;
    }

    .card-body-custom {
        padding: 20px;
    }

    .status-selector {
        grid-template-columns: 1fr;
    }

    .form-footer {
        flex-direction: column-reverse;
        padding: 16px 20px;
    }

    .btn-save,
    .btn-cancel {
        width: 100%;
    }

    .carousel-image-preview {
        width: 100%;
        height: auto;
        min-height: 160px;
    }
}

/* Dark Mode */
[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --carousel-bg: #020617;
    --carousel-card-bg: #0f172a;
    --carousel-card-subtle: #1e293b;
    --carousel-input-bg: #1e293b;
    --carousel-input-border: rgba(148, 163, 184, .25);
    --carousel-input-color: #f1f5f9;
    --carousel-title: #f8fafc;
    --carousel-subtitle: #94a3b8;
    --carousel-border: rgba(148, 163, 184, .16);
    --carousel-hover: #1e293b;
    --carousel-accent: #38bdf8;
    --carousel-icon-muted: #94a3b8;
}

[data-bs-theme="dark"] .custom-input:focus,
[data-theme="dark"] .custom-input:focus,
body.dark-mode .custom-input:focus,
.dark-mode .custom-input:focus {
    background: #1e293b;
    color: #f1f5f9;
}
</style>

<script>
(function () {
    const uploadBox = document.getElementById('carousel-upload-box');
    const input = document.getElementById('carousel-gambar-input');
    const preview = document.getElementById('carousel-gambar-preview');
    const label = document.getElementById('carousel-upload-label');

    if (uploadBox && input) {
        uploadBox.addEventListener('click', function () {
            input.click();
        });

        input.addEventListener('change', function () {
            const file = this.files && this.files[0];

            if (!file) {
                return;
            }

            if (!file.type.startsWith('image/')) {
                return;
            }

            const reader = new FileReader();

            reader.onload = function (event) {
                if (preview) {
                    preview.src = event.target.result;
                }

                if (label) {
                    label.textContent = file.name;
                }
            };

            reader.readAsDataURL(file);
        });
    }

    document.querySelectorAll('.status-option input').forEach(function (radio) {
        radio.addEventListener('change', function () {
            document.querySelectorAll('.status-option').forEach(function (option) {
                option.classList.remove('selected');
            });

            const parent = this.closest('.status-option');

            if (parent) {
                parent.classList.add('selected');
            }
        });
    });
})();
</script>

<?php $this->load->view('admin/template/footer'); ?>