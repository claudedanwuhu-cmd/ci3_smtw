<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">

    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <?php if ($this->session->flashdata('error')): ?>

            <div class="alert-custom-danger mb-4">

                <div class="alert-icon-box">
                    <i class="fa-solid fa-circle-exclamation"></i>
                </div>

                <div>
                    <?= html_escape($this->session->flashdata('error')); ?>
                </div>

            </div>

        <?php endif; ?>

        <!-- PAGE HEADER -->
        <div class="page-header-custom">

            <div class="page-header-left">

                <div class="page-header-icon">
                    <i class="fa-solid fa-newspaper"></i>
                </div>

                <div>

                    <span class="badge-header-tag">
                        Form Input
                    </span>

                    <h2 class="page-title">
                        Tambah Berita
                    </h2>

                    <p class="page-subtitle">
                        Tambahkan publikasi berita baru untuk sekolah.
                    </p>

                </div>

            </div>

            <a
                href="<?= site_url('admin/berita'); ?>"
                class="btn-back"
            >
                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali
            </a>

        </div>

        <!-- FORM CARD -->
        <div class="custom-card">

            <form
                action="<?= site_url('admin/berita/simpan'); ?>"
                method="post"
                enctype="multipart/form-data"
            >

                <!-- CARD TITLE -->
                <div class="card-title-custom">

                    <div class="title-icon">
                        <i class="fa-solid fa-newspaper"></i>
                    </div>

                    <div>

                        <h5>Informasi Berita</h5>

                        <small>
                            Lengkapi informasi publikasi berita
                        </small>

                    </div>

                </div>

                <!-- FORM BODY -->
                <div class="card-body-custom">

                    <div class="row g-4">

                        <!-- JUDUL -->
                        <div class="col-md-8">

                            <label class="form-label">
                                Judul Berita <span class="required-mark">*</span>
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-heading input-icon"></i>

                                <input
                                    type="text"
                                    name="judul"
                                    class="form-control custom-input with-icon"
                                    placeholder="Masukkan judul berita"
                                    required
                                >

                            </div>

                        </div>

                        <!-- KATEGORI -->
                        <div class="col-md-4">

                            <label class="form-label">
                                Kategori
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-layer-group input-icon"></i>

                                <select
                                    name="kategori_id"
                                    class="form-select custom-input custom-select with-icon"
                                >

                                    <option value="">
                                        Umum
                                    </option>

                                    <?php foreach ($kategori as $item): ?>

                                        <option value="<?= $item->id; ?>">
                                            <?= html_escape($item->nama); ?>
                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>

                        </div>

                        <!-- THUMBNAIL -->
                        <div class="col-12">

                            <label class="form-label">
                                Thumbnail Berita
                            </label>

                            <div
                                class="image-upload-box"
                                id="berita-thumbnail-upload"
                            >

                                <input
                                    type="file"
                                    name="thumbnail"
                                    id="berita-thumbnail-input"
                                    class="file-input-hidden"
                                    accept="image/png,image/jpeg,image/webp"
                                >

                                <div
                                    id="berita-upload-placeholder"
                                    class="image-upload-content"
                                >

                                    <div class="upload-icon">
                                        <i class="fa-solid fa-cloud-arrow-up"></i>
                                    </div>

                                    <strong>
                                        Klik untuk memilih thumbnail
                                    </strong>

                                    <small>
                                        JPG, PNG atau WEBP • Maksimal 2 MB
                                    </small>

                                </div>

                                <div
                                    id="berita-preview-wrapper"
                                    class="image-upload-content d-none"
                                >

                                    <img
                                        id="berita-thumbnail-preview"
                                        src=""
                                        class="image-preview"
                                        alt="Preview thumbnail"
                                    >

                                    <div class="preview-info">

                                        <strong id="berita-thumbnail-label">
                                            Thumbnail terpilih
                                        </strong>

                                        <small>
                                            Klik untuk mengganti thumbnail
                                        </small>

                                    </div>

                                </div>

                            </div>

                        </div>

                        <!-- TANGGAL -->
                        <div class="col-md-4">

                            <label class="form-label">
                                Tanggal
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-calendar-days input-icon"></i>

                                <input
                                    type="date"
                                    name="tanggal"
                                    class="form-control custom-input with-icon"
                                    value="<?= date('Y-m-d'); ?>"
                                >

                            </div>

                        </div>

                        <!-- STATUS -->
                        <div class="col-md-8">

                            <label class="form-label">
                                Status Publikasi
                            </label>

                            <div class="gender-selector">

                                <label class="status-option selected">

                                    <input
                                        type="radio"
                                        name="status"
                                        value="publish"
                                        checked
                                    >

                                    <div class="status-option-icon publish-icon">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </div>

                                    <div>

                                        <strong>
                                            Publish
                                        </strong>

                                        <small>
                                            Berita langsung ditampilkan
                                        </small>

                                    </div>

                                </label>

                                <label class="status-option">

                                    <input
                                        type="radio"
                                        name="status"
                                        value="draft"
                                    >

                                    <div class="status-option-icon draft-icon">
                                        <i class="fa-solid fa-file-pen"></i>
                                    </div>

                                    <div>

                                        <strong>
                                            Draft
                                        </strong>

                                        <small>
                                            Berita disimpan sebagai draft
                                        </small>

                                    </div>

                                </label>

                            </div>

                        </div>

                        <!-- ISI -->
                        <div class="col-12">

                            <label class="form-label">
                                Isi Berita
                            </label>

                            <div class="input-icon-group textarea-group">

                                <i class="fa-solid fa-align-left input-icon textarea-icon"></i>

                                <textarea
                                    name="isi"
                                    rows="9"
                                    class="form-control custom-textarea with-icon"
                                    placeholder="Tuliskan isi berita di sini..."
                                ></textarea>

                            </div>

                        </div>

                    </div>

                </div>

                <!-- FOOTER -->
                <div class="form-footer">

                    <a
                        href="<?= site_url('admin/berita'); ?>"
                        class="btn-cancel"
                    >
                        <i class="fa-solid fa-xmark me-2"></i>
                        Batal
                    </a>

                    <button
                        type="submit"
                        class="btn-save"
                    >
                        <i class="fa-solid fa-floppy-disk me-2"></i>
                        Simpan Berita
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<style>
/* =========================================================
   BERITA TAMBAH - GURU MASTER STYLE
   ========================================================= */

.page-header-custom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 24px 28px;
    margin-bottom: 24px;
    border-radius: 20px;
    background: var(--guru-card-bg, #fff);
    border: 1px solid var(--guru-border, #e2e8f0);
    box-shadow: var(--guru-shadow, 0 10px 30px -5px rgba(15,23,42,.05));
}

.page-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.page-header-icon {
    width: 52px;
    height: 52px;
    min-width: 52px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14,165,233,.10);
    border: 1px solid rgba(14,165,233,.18);
    color: #0ea5e9;
    font-size: 20px;
}

.badge-header-tag {
    display: inline-flex;
    padding: 5px 10px;
    margin-bottom: 5px;
    border-radius: 999px;
    background: rgba(14,165,233,.10);
    color: #0284c7;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
    text-transform: uppercase;
}

.page-title {
    margin: 0;
    color: var(--guru-title, #0f172a);
    font-size: 22px;
    font-weight: 800;
}

.page-subtitle {
    margin: 4px 0 0;
    color: var(--guru-subtitle, #64748b);
    font-size: 13px;
}

.btn-back,
.btn-cancel {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 11px 20px;
    border-radius: 12px;
    border: 1px solid var(--guru-border, #e2e8f0);
    background: var(--guru-card-subtle, #f8fafc);
    color: var(--guru-title, #0f172a);
    font-size: 13px;
    font-weight: 700;
    text-decoration: none;
    transition: .2s ease;
}

.btn-back:hover {
    color: #0ea5e9;
    border-color: rgba(14,165,233,.4);
    transform: translateX(-2px);
}

.custom-card {
    overflow: hidden;
    border-radius: 20px;
    background: var(--guru-card-bg, #fff);
    border: 1px solid var(--guru-border, #e2e8f0);
    box-shadow: var(--guru-shadow, 0 10px 25px -5px rgba(15,23,42,.05));
}

.card-title-custom {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 24px;
    background: var(--guru-card-subtle, #f8fafc);
    border-bottom: 1px solid var(--guru-border, #e2e8f0);
}

.card-title-custom h5 {
    margin: 0;
    color: var(--guru-title, #0f172a);
    font-size: 15px;
    font-weight: 700;
}

.card-title-custom small {
    color: var(--guru-subtitle, #64748b);
    font-size: 12px;
}

.title-icon {
    width: 42px;
    height: 42px;
    min-width: 42px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #0ea5e9;
    background: rgba(14,165,233,.10);
    border: 1px solid rgba(14,165,233,.18);
}

.card-body-custom {
    padding: 28px 24px;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: var(--guru-title, #0f172a);
    font-size: 12.5px;
    font-weight: 700;
}

.required-mark {
    color: #ef4444;
}

.input-icon-group {
    position: relative;
}

.input-icon {
    position: absolute;
    top: 50%;
    left: 15px;
    z-index: 2;
    transform: translateY(-50%);
    color: var(--guru-icon-muted, #94a3b8);
    font-size: 14px;
    pointer-events: none;
}

.custom-input {
    min-height: 44px;
    padding: 10px 16px;
    border-radius: 12px;
    border: 1px solid var(--guru-input-border, #cbd5e1);
    background: var(--guru-input-bg, #f8fafc);
    color: var(--guru-input-color, #0f172a);
    font-size: 13.5px;
    box-shadow: none;
    transition: .2s ease;
}

.custom-input.with-icon {
    padding-left: 42px;
}

.custom-input:focus,
.custom-textarea:focus {
    border-color: #0ea5e9;
    background: var(--guru-input-focus-bg, #fff);
    box-shadow: 0 0 0 4px rgba(14,165,233,.12);
    color: var(--guru-input-color, #0f172a);
}

.custom-select {
    cursor: pointer;
}

.custom-textarea {
    width: 100%;
    min-height: 180px;
    padding: 14px 16px 14px 42px;
    resize: vertical;
    border-radius: 12px;
    border: 1px solid var(--guru-input-border, #cbd5e1);
    background: var(--guru-input-bg, #f8fafc);
    color: var(--guru-input-color, #0f172a);
    font-size: 13.5px;
    line-height: 1.6;
    transition: .2s ease;
}

.textarea-group {
    position: relative;
}

.textarea-icon {
    top: 18px;
    transform: none;
}

/* IMAGE UPLOAD */
.image-upload-box {
    min-height: 170px;
    padding: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px dashed var(--dropzone-border, #cbd5e1);
    border-radius: 16px;
    background: var(--dropzone-bg, #f1f5f9);
    color: var(--guru-subtitle, #64748b);
    cursor: pointer;
    transition: .2s ease;
}

.image-upload-box:hover {
    border-color: #0ea5e9;
    background: rgba(14,165,233,.05);
}

.file-input-hidden {
    display: none;
}

.image-upload-content {
    width: 100%;
    text-align: center;
}

.upload-icon {
    width: 48px;
    height: 48px;
    margin: 0 auto 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 14px;
    background: rgba(14,165,233,.10);
    color: #0ea5e9;
    font-size: 19px;
}

.image-upload-content strong {
    display: block;
    color: var(--guru-title, #0f172a);
    font-size: 13px;
}

.image-upload-content small {
    display: block;
    margin-top: 4px;
    color: var(--guru-subtitle, #64748b);
    font-size: 11px;
}

#berita-preview-wrapper {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
}

.image-preview {
    width: 180px;
    height: 110px;
    object-fit: cover;
    border-radius: 14px;
    border: 2px solid rgba(14,165,233,.25);
}

.preview-info {
    text-align: left;
}

.preview-info strong {
    margin-bottom: 5px;
}

.preview-info small {
    margin: 0;
}

/* STATUS */
.gender-selector {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
}

.status-option {
    min-height: 68px;
    padding: 12px 14px;
    display: flex;
    align-items: center;
    gap: 12px;
    border-radius: 12px;
    border: 1px solid var(--guru-input-border, #cbd5e1);
    background: var(--guru-input-bg, #f8fafc);
    cursor: pointer;
    transition: .2s ease;
}

.status-option input {
    display: none;
}

.status-option:hover,
.status-option.selected {
    border-color: #0ea5e9;
    background: rgba(14,165,233,.07);
}

.status-option-icon {
    width: 38px;
    height: 38px;
    min-width: 38px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    font-size: 15px;
}

.publish-icon {
    color: #10b981;
    background: rgba(16,185,129,.10);
}

.draft-icon {
    color: #f59e0b;
    background: rgba(245,158,11,.10);
}

.status-option strong {
    display: block;
    color: var(--guru-title, #0f172a);
    font-size: 13px;
}

.status-option small {
    display: block;
    margin-top: 2px;
    color: var(--guru-subtitle, #64748b);
    font-size: 11px;
}

/* FOOTER */
.form-footer {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 12px;
    padding: 18px 24px;
    background: var(--guru-card-subtle, #f8fafc);
    border-top: 1px solid var(--guru-border, #e2e8f0);
}

.btn-save {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 11px 26px;
    border: 0;
    border-radius: 12px;
    background: linear-gradient(135deg, #0284c7, #0369a1);
    color: #fff;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 8px 18px rgba(3,105,161,.20);
    transition: .2s ease;
}

.btn-save:hover {
    color: #fff;
    transform: translateY(-2px);
}

/* ALERT */
.alert-custom-danger {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 18px;
    border-radius: 16px;
    border: 1px solid rgba(239,68,68,.20);
    background: rgba(239,68,68,.08);
    color: #dc2626;
    font-size: 13px;
}

.alert-icon-box {
    width: 36px;
    height: 36px;
    min-width: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: rgba(239,68,68,.10);
}

/* DARK */
[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --guru-bg: #070d19;
    --guru-card-bg: #0f172a;
    --guru-card-subtle: #1e293b;
    --guru-input-bg: #1e293b;
    --guru-input-border: rgba(255,255,255,.10);
    --guru-input-color: #f1f5f9;
    --guru-input-focus-bg: #111827;
    --guru-border: rgba(255,255,255,.08);
    --guru-title: #f8fafc;
    --guru-subtitle: #94a3b8;
    --guru-hover: #1e293b;
    --guru-shadow: 0 12px 30px -5px rgba(0,0,0,.4);
    --guru-icon-muted: #64748b;
    --dropzone-bg: #111827;
    --dropzone-border: rgba(255,255,255,.12);
}

/* RESPONSIVE */
@media (max-width: 768px) {

    .page-header-custom {
        flex-direction: column;
        align-items: stretch;
        padding: 20px;
    }

    .page-header-left {
        align-items: flex-start;
    }

    .btn-back {
        width: 100%;
    }

    .card-body-custom {
        padding: 20px 18px;
    }

    .gender-selector {
        grid-template-columns: 1fr;
    }

    #berita-preview-wrapper {
        flex-direction: column;
    }

    .preview-info {
        text-align: center;
    }

    .form-footer {
        flex-direction: column-reverse;
        padding: 18px;
    }

    .btn-cancel,
    .btn-save {
        width: 100%;
    }

}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const uploadBox = document.getElementById('berita-thumbnail-upload');
    const input = document.getElementById('berita-thumbnail-input');
    const preview = document.getElementById('berita-thumbnail-preview');
    const previewWrapper = document.getElementById('berita-preview-wrapper');
    const placeholder = document.getElementById('berita-upload-placeholder');
    const label = document.getElementById('berita-thumbnail-label');

    if (uploadBox && input) {

        uploadBox.addEventListener('click', function () {
            input.click();
        });

        input.addEventListener('change', function () {

            const file = this.files[0];

            if (!file) {
                return;
            }

            const reader = new FileReader();

            reader.onload = function (event) {

                preview.src = event.target.result;

                previewWrapper.classList.remove('d-none');
                placeholder.classList.add('d-none');

                label.textContent = file.name;
            };

            reader.readAsDataURL(file);
        });

    }

    // Status selector
    const statusOptions = document.querySelectorAll('.status-option');

    statusOptions.forEach(function (option) {

        option.addEventListener('click', function () {

            statusOptions.forEach(function (item) {
                item.classList.remove('selected');
            });

            this.classList.add('selected');

            const radio = this.querySelector('input[type="radio"]');

            if (radio) {
                radio.checked = true;
            }

        });

    });

});
</script>

<?php $this->load->view('admin/template/footer'); ?>