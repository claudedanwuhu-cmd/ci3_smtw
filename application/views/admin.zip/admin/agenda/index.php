```php
<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">

    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <div class="page-header-custom">

            <div class="page-header-left">

                <div class="page-header-icon">
                    <i class="fa-solid fa-calendar-days"></i>
                </div>

                <div>

                    <span class="badge-header-tag">
                        Manajemen Kegiatan
                    </span>

                    <h2 class="page-title">
                        Agenda
                    </h2>

                    <p class="page-subtitle">
                        Kelola agenda dan kegiatan sekolah.
                    </p>

                </div>

            </div>

            <a
                href="<?= site_url('admin/agenda/tambah'); ?>"
                class="btn-add"
            >
                <i class="fa-solid fa-plus me-2"></i>
                Tambah Agenda
            </a>

        </div>

        <div class="custom-card">

            <div class="card-title-custom justify-content-between">

                <div class="d-flex align-items-center gap-3">

                    <div class="title-icon">
                        <i class="fa-solid fa-calendar-days"></i>
                    </div>

                    <div>
                        <h5>Daftar Agenda</h5>
                        <small>Daftar kegiatan sekolah</small>
                    </div>

                </div>

                <span class="total-badge">
                    <?= count($agenda); ?> Data
                </span>

            </div>

            <div class="table-responsive">

                <table class="table custom-table align-middle">

                    <thead>

                        <tr>
                            <th>No</th>
                            <th>Judul Agenda</th>
                            <th>Tanggal</th>
                            <th>Lokasi</th>
                            <th>Status</th>
                            <th class="text-end">Aksi</th>
                        </tr>

                    </thead>

                    <tbody>

                        <?php if (!empty($agenda)): ?>

                            <?php $no = 1; ?>

                            <?php foreach ($agenda as $item): ?>

                                <tr>

                                    <td>
                                        <span class="number-badge">
                                            <?= $no++; ?>
                                        </span>
                                    </td>

                                    <td>

                                        <div class="agenda-title-wrapper">

                                            <div class="agenda-icon">
                                                <i class="fa-solid fa-calendar-days"></i>
                                            </div>

                                            <div>
                                                <div class="item-title">
                                                    <?= html_escape($item->judul); ?>
                                                </div>

                                                <small class="item-meta">
                                                    Kegiatan sekolah
                                                </small>
                                            </div>

                                        </div>

                                    </td>

                                    <td>

                                        <div class="date-info">

                                            <i class="fa-regular fa-calendar"></i>

                                            <span>
                                                <?= !empty($item->tanggal)
                                                    ? date('d-m-Y', strtotime($item->tanggal))
                                                    : '-'; ?>
                                            </span>

                                        </div>

                                    </td>

                                    <td>

                                        <div class="location-info">

                                            <i class="fa-solid fa-location-dot"></i>

                                            <span>
                                                <?= !empty($item->lokasi)
                                                    ? html_escape($item->lokasi)
                                                    : '-'; ?>
                                            </span>

                                        </div>

                                    </td>

                                    <td>

                                        <span
                                            class="status-badge <?= $item->status === 'aktif' ? 'active' : 'inactive'; ?>"
                                        >

                                            <i class="fa-solid <?= $item->status === 'aktif'
                                                ? 'fa-circle-check'
                                                : 'fa-circle-xmark'; ?> me-1"></i>

                                            <?= ucfirst($item->status); ?>

                                        </span>

                                    </td>

                                    <td>

                                        <div class="action-buttons justify-content-end">

                                            <a
                                                href="<?= site_url('admin/agenda/edit/'.$item->id); ?>"
                                                class="btn-action edit"
                                                title="Edit Agenda"
                                            >
                                                <i class="fa-solid fa-pen"></i>
                                            </a>

                                            <a
                                                href="<?= site_url('admin/agenda/hapus/'.$item->id); ?>"
                                                class="btn-action delete"
                                                title="Hapus Agenda"
                                                onclick="return confirm('Yakin ingin menghapus agenda ini?');"
                                            >
                                                <i class="fa-solid fa-trash"></i>
                                            </a>

                                        </div>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>

                                <td colspan="6" class="empty-data">

                                    <div class="empty-icon">
                                        <i class="fa-solid fa-calendar-days"></i>
                                    </div>

                                    <strong>
                                        Belum ada agenda
                                    </strong>

                                    <small>
                                        Data agenda kegiatan sekolah belum tersedia.
                                    </small>

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<style>
.page-header-custom {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    padding:24px 28px;
    margin-bottom:24px;
    border-radius:20px;
    background:var(--guru-card-bg,#fff);
    border:1px solid var(--guru-border,#e2e8f0);
    box-shadow:var(--guru-shadow,0 10px 30px -5px rgba(15,23,42,.05));
}

.page-header-left {
    display:flex;
    align-items:center;
    gap:16px;
}

.page-header-icon {
    width:52px;
    height:52px;
    min-width:52px;
    border-radius:16px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:rgba(14,165,233,.10);
    border:1px solid rgba(14,165,233,.18);
    color:#0ea5e9;
    font-size:20px;
}

.badge-header-tag {
    display:inline-flex;
    padding:5px 10px;
    margin-bottom:5px;
    border-radius:999px;
    background:rgba(14,165,233,.10);
    color:#0284c7;
    font-size:10px;
    font-weight:800;
    letter-spacing:.7px;
    text-transform:uppercase;
}

.page-title {
    margin:0;
    color:var(--guru-title,#0f172a);
    font-size:22px;
    font-weight:800;
}

.page-subtitle {
    margin:4px 0 0;
    color:var(--guru-subtitle,#64748b);
    font-size:13px;
}

.btn-add {
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:11px 22px;
    border-radius:12px;
    background:linear-gradient(135deg,#0284c7,#0369a1);
    color:#fff;
    font-size:12px;
    font-weight:700;
    text-decoration:none;
    box-shadow:0 8px 18px rgba(3,105,161,.20);
    transition:.2s ease;
}

.btn-add:hover {
    color:#fff;
    transform:translateY(-2px);
}

.custom-card {
    overflow:hidden;
    border-radius:20px;
    background:var(--guru-card-bg,#fff);
    border:1px solid var(--guru-border,#e2e8f0);
    box-shadow:var(--guru-shadow,0 10px 30px -5px rgba(15,23,42,.05));
}

.card-title-custom {
    display:flex;
    align-items:center;
    gap:14px;
    padding:18px 24px;
    background:var(--guru-card-subtle,#f1f5f9);
    border-bottom:1px solid var(--guru-border,#e2e8f0);
}

.card-title-custom h5 {
    margin:0;
    color:var(--guru-title,#0f172a);
    font-size:15px;
    font-weight:700;
}

.card-title-custom small {
    color:var(--guru-subtitle,#64748b);
    font-size:12px;
}

.title-icon {
    width:42px;
    height:42px;
    min-width:42px;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#0ea5e9;
    background:rgba(14,165,233,.10);
    border:1px solid rgba(14,165,233,.18);
}

.total-badge {
    display:inline-flex;
    align-items:center;
    padding:7px 12px;
    border-radius:999px;
    background:rgba(14,165,233,.10);
    color:#0284c7;
    font-size:11px;
    font-weight:800;
}

.custom-table {
    margin:0;
    color:var(--guru-title,#0f172a);
}

.custom-table thead th {
    padding:15px 20px;
    border-bottom:1px solid var(--guru-border,#e2e8f0);
    background:var(--guru-card-subtle,#f8fafc);
    color:var(--guru-subtitle,#64748b);
    font-size:10.5px;
    font-weight:800;
    letter-spacing:.5px;
    text-transform:uppercase;
    white-space:nowrap;
}

.custom-table tbody td {
    padding:16px 20px;
    border-color:var(--guru-border,#e2e8f0);
    color:var(--guru-title,#0f172a);
    font-size:13px;
}

.custom-table tbody tr {
    transition:.15s ease;
}

.custom-table tbody tr:hover {
    background:var(--guru-hover,#f8fafc);
}

.number-badge {
    width:30px;
    height:30px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    border-radius:9px;
    background:var(--guru-card-subtle,#f1f5f9);
    color:var(--guru-subtitle,#64748b);
    font-size:11px;
    font-weight:700;
}

.agenda-title-wrapper {
    display:flex;
    align-items:center;
    gap:12px;
}

.agenda-icon {
    width:38px;
    height:38px;
    min-width:38px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:10px;
    background:rgba(14,165,233,.10);
    color:#0ea5e9;
}

.item-title {
    max-width:350px;
    color:var(--guru-title,#0f172a);
    font-size:13.5px;
    font-weight:700;
}

.item-meta {
    display:block;
    margin-top:3px;
    color:var(--guru-subtitle,#64748b);
    font-size:10.5px;
}

.date-info,
.location-info {
    display:flex;
    align-items:center;
    gap:8px;
    color:var(--guru-subtitle,#64748b);
}

.date-info i,
.location-info i {
    color:#0ea5e9;
}

.location-info {
    max-width:220px;
}

.status-badge {
    display:inline-flex;
    align-items:center;
    padding:6px 10px;
    border-radius:999px;
    font-size:10.5px;
    font-weight:700;
}

.status-badge.active {
    background:rgba(16,185,129,.10);
    color:#10b981;
}

.status-badge.inactive {
    background:rgba(239,68,68,.10);
    color:#ef4444;
}

.action-buttons {
    display:flex;
    align-items:center;
    gap:7px;
}

.btn-action {
    width:36px;
    height:36px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    border-radius:10px;
    text-decoration:none;
    transition:.2s ease;
}

.btn-action.edit {
    background:rgba(14,165,233,.10);
    color:#0284c7;
}

.btn-action.edit:hover {
    color:#fff;
    background:#0284c7;
    transform:translateY(-2px);
}

.btn-action.delete {
    background:rgba(239,68,68,.08);
    color:#ef4444;
}

.btn-action.delete:hover {
    color:#fff;
    background:#ef4444;
    transform:translateY(-2px);
}

.empty-data {
    padding:60px 20px!important;
    text-align:center;
    color:var(--guru-subtitle,#64748b)!important;
}

.empty-icon {
    width:64px;
    height:64px;
    margin:0 auto 14px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:18px;
    background:var(--guru-card-subtle,#f1f5f9);
    color:var(--guru-icon-muted,#94a3b8);
    font-size:24px;
}

.empty-data strong {
    display:block;
    color:var(--guru-title,#0f172a);
    font-size:13px;
}

.empty-data small {
    display:block;
    margin-top:4px;
    font-size:11px;
}

[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --guru-card-bg:#0f172a;
    --guru-card-subtle:#1e293b;
    --guru-border:rgba(255,255,255,.08);
    --guru-title:#f8fafc;
    --guru-subtitle:#94a3b8;
    --guru-hover:#1e293b;
    --guru-icon-muted:#64748b;
}

@media(max-width:768px) {

    .page-header-custom {
        flex-direction:column;
        align-items:stretch;
        padding:20px;
    }

    .btn-add {
        width:100%;
    }

    .card-title-custom {
        flex-wrap:wrap;
    }

    .total-badge {
        margin-left:56px;
    }

    .item-title {
        max-width:230px;
    }

}
</style>

<?php $this->load->view('admin/template/footer'); ?>
```
