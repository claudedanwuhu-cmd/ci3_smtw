```php
<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">

    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <div class="page-header-custom">

            <div class="page-header-left">

                <div class="page-header-icon">
                    <i class="fa-solid fa-calendar-plus"></i>
                </div>

                <div>

                    <span class="badge-header-tag">
                        Form Input
                    </span>

                    <h2 class="page-title">
                        Tambah Agenda
                    </h2>

                    <p class="page-subtitle">
                        Tambahkan kegiatan baru ke agenda sekolah.
                    </p>

                </div>

            </div>

            <a
                href="<?= site_url('admin/agenda'); ?>"
                class="btn-back"
            >
                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali
            </a>

        </div>

        <div class="custom-card">

            <form
                action="<?= site_url('admin/agenda/simpan'); ?>"
                method="post"
            >

                <div class="card-title-custom">

                    <div class="title-icon">
                        <i class="fa-solid fa-calendar-days"></i>
                    </div>

                    <div>
                        <h5>Informasi Agenda</h5>
                        <small>Lengkapi data kegiatan sekolah</small>
                    </div>

                </div>

                <div class="card-body-custom">

                    <div class="row g-4">

                        <div class="col-md-8">

                            <label class="form-label">
                                Judul Agenda <span class="required-mark">*</span>
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-heading input-icon"></i>

                                <input
                                    type="text"
                                    name="judul"
                                    class="form-control custom-input with-icon"
                                    placeholder="Masukkan judul agenda"
                                    required
                                >

                            </div>

                        </div>

                        <div class="col-md-4">

                            <label class="form-label">
                                Tanggal
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-calendar-days input-icon"></i>

                                <input
                                    type="date"
                                    name="tanggal"
                                    class="form-control custom-input with-icon"
                                >

                            </div>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Lokasi
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-location-dot input-icon"></i>

                                <input
                                    type="text"
                                    name="lokasi"
                                    class="form-control custom-input with-icon"
                                    placeholder="Masukkan lokasi kegiatan"
                                >

                            </div>

                        </div>

                        <div class="col-md-6">

                            <label class="form-label">
                                Status
                            </label>

                            <div class="status-selector">

                                <label class="status-option selected">

                                    <input
                                        type="radio"
                                        name="status"
                                        value="aktif"
                                        checked
                                    >

                                    <div class="status-option-icon active-icon">
                                        <i class="fa-solid fa-circle-check"></i>
                                    </div>

                                    <div>
                                        <strong>Aktif</strong>
                                        <small>Agenda sedang aktif</small>
                                    </div>

                                </label>

                                <label class="status-option">

                                    <input
                                        type="radio"
                                        name="status"
                                        value="nonaktif"
                                    >

                                    <div class="status-option-icon inactive-icon">
                                        <i class="fa-solid fa-circle-xmark"></i>
                                    </div>

                                    <div>
                                        <strong>Nonaktif</strong>
                                        <small>Agenda tidak aktif</small>
                                    </div>

                                </label>

                            </div>

                        </div>

                        <div class="col-12">

                            <label class="form-label">
                                Deskripsi
                            </label>

                            <div class="input-icon-group textarea-group">

                                <i class="fa-solid fa-align-left input-icon textarea-icon"></i>

                                <textarea
                                    name="deskripsi"
                                    rows="7"
                                    class="form-control custom-textarea"
                                    placeholder="Tuliskan deskripsi kegiatan..."
                                ></textarea>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="form-footer">

                    <a
                        href="<?= site_url('admin/agenda'); ?>"
                        class="btn-cancel"
                    >
                        <i class="fa-solid fa-xmark me-2"></i>
                        Batal
                    </a>

                    <button
                        type="submit"
                        class="btn-save"
                    >
                        <i class="fa-solid fa-floppy-disk me-2"></i>
                        Simpan Agenda
                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<style>
.page-header-custom {
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:20px;
    padding:24px 28px;
    margin-bottom:24px;
    border-radius:20px;
    background:var(--guru-card-bg,#fff);
    border:1px solid var(--guru-border,#e2e8f0);
    box-shadow:var(--guru-shadow,0 10px 30px -5px rgba(15,23,42,.05));
}

.page-header-left {
    display:flex;
    align-items:center;
    gap:16px;
}

.page-header-icon {
    width:52px;
    height:52px;
    min-width:52px;
    border-radius:16px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:rgba(14,165,233,.10);
    border:1px solid rgba(14,165,233,.18);
    color:#0ea5e9;
    font-size:20px;
}

.badge-header-tag {
    display:inline-flex;
    padding:5px 10px;
    margin-bottom:5px;
    border-radius:999px;
    background:rgba(14,165,233,.10);
    color:#0284c7;
    font-size:10px;
    font-weight:800;
    letter-spacing:.7px;
    text-transform:uppercase;
}

.page-title {
    margin:0;
    color:var(--guru-title,#0f172a);
    font-size:22px;
    font-weight:800;
}

.page-subtitle {
    margin:4px 0 0;
    color:var(--guru-subtitle,#64748b);
    font-size:13px;
}

.btn-back,
.btn-cancel {
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:11px 20px;
    border-radius:12px;
    border:1px solid var(--guru-border,#e2e8f0);
    background:var(--guru-card-subtle,#f8fafc);
    color:var(--guru-title,#0f172a);
    font-size:13px;
    font-weight:700;
    text-decoration:none;
    transition:.2s ease;
}

.btn-back:hover {
    color:#0ea5e9;
    border-color:rgba(14,165,233,.4);
    transform:translateX(-2px);
}

.custom-card {
    overflow:hidden;
    border-radius:20px;
    background:var(--guru-card-bg,#fff);
    border:1px solid var(--guru-border,#e2e8f0);
    box-shadow:var(--guru-shadow,0 10px 25px -5px rgba(15,23,42,.05));
}

.card-title-custom {
    display:flex;
    align-items:center;
    gap:14px;
    padding:18px 24px;
    background:var(--guru-card-subtle,#f8fafc);
    border-bottom:1px solid var(--guru-border,#e2e8f0);
}

.card-title-custom h5 {
    margin:0;
    color:var(--guru-title,#0f172a);
    font-size:15px;
    font-weight:700;
}

.card-title-custom small {
    color:var(--guru-subtitle,#64748b);
    font-size:12px;
}

.title-icon {
    width:42px;
    height:42px;
    min-width:42px;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#0ea5e9;
    background:rgba(14,165,233,.10);
    border:1px solid rgba(14,165,233,.18);
}

.card-body-custom {
    padding:28px 24px;
}

.form-label {
    display:block;
    margin-bottom:8px;
    color:var(--guru-title,#0f172a);
    font-size:12.5px;
    font-weight:700;
}

.required-mark {
    color:#ef4444;
}

.input-icon-group {
    position:relative;
}

.input-icon {
    position:absolute;
    top:50%;
    left:15px;
    z-index:2;
    transform:translateY(-50%);
    color:var(--guru-icon-muted,#94a3b8);
    font-size:14px;
    pointer-events:none;
}

.custom-input {
    min-height:44px;
    padding:10px 16px;
    border-radius:12px;
    border:1px solid var(--guru-input-border,#cbd5e1);
    background:var(--guru-input-bg,#f8fafc);
    color:var(--guru-input-color,#0f172a);
    font-size:13.5px;
    box-shadow:none;
    transition:.2s ease;
}

.custom-input.with-icon {
    padding-left:42px;
}

.custom-input:focus,
.custom-textarea:focus {
    border-color:#0ea5e9;
    background:var(--guru-input-focus-bg,#fff);
    box-shadow:0 0 0 4px rgba(14,165,233,.12);
}

.status-selector {
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:10px;
}

.status-option {
    min-height:68px;
    padding:12px;
    display:flex;
    align-items:center;
    gap:10px;
    border-radius:12px;
    border:1px solid var(--guru-input-border,#cbd5e1);
    background:var(--guru-input-bg,#f8fafc);
    cursor:pointer;
    transition:.2s ease;
}

.status-option input {
    display:none;
}

.status-option:hover,
.status-option.selected {
    border-color:#0ea5e9;
    background:rgba(14,165,233,.07);
}

.status-option-icon {
    width:38px;
    height:38px;
    min-width:38px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:10px;
}

.active-icon {
    color:#10b981;
    background:rgba(16,185,129,.10);
}

.inactive-icon {
    color:#ef4444;
    background:rgba(239,68,68,.10);
}

.status-option strong {
    display:block;
    color:var(--guru-title,#0f172a);
    font-size:13px;
}

.status-option small {
    display:block;
    margin-top:2px;
    color:var(--guru-subtitle,#64748b);
    font-size:11px;
}

.custom-textarea {
    width:100%;
    min-height:170px;
    padding:14px 16px 14px 42px;
    resize:vertical;
    border-radius:12px;
    border:1px solid var(--guru-input-border,#cbd5e1);
    background:var(--guru-input-bg,#f8fafc);
    color:var(--guru-input-color,#0f172a);
    font-size:13.5px;
    line-height:1.6;
}

.textarea-icon {
    top:18px;
    transform:none;
}

.form-footer {
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:12px;
    padding:18px 24px;
    background:var(--guru-card-subtle,#f8fafc);
    border-top:1px solid var(--guru-border,#e2e8f0);
}

.btn-save {
    display:inline-flex;
    align-items:center;
    justify-content:center;
    padding:11px 26px;
    border:0;
    border-radius:12px;
    background:linear-gradient(135deg,#0284c7,#0369a1);
    color:#fff;
    font-size:13px;
    font-weight:700;
    box-shadow:0 8px 18px rgba(3,105,161,.20);
    transition:.2s ease;
}

.btn-save:hover {
    color:#fff;
    transform:translateY(-2px);
}

[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --guru-card-bg:#0f172a;
    --guru-card-subtle:#1e293b;
    --guru-input-bg:#1e293b;
    --guru-input-border:rgba(255,255,255,.10);
    --guru-input-color:#f1f5f9;
    --guru-input-focus-bg:#111827;
    --guru-border:rgba(255,255,255,.08);
    --guru-title:#f8fafc;
    --guru-subtitle:#94a3b8;
    --guru-icon-muted:#64748b;
}

@media(max-width:768px) {

    .page-header-custom {
        flex-direction:column;
        align-items:stretch;
        padding:20px;
    }

    .btn-back {
        width:100%;
    }

    .card-body-custom {
        padding:20px 18px;
    }

    .status-selector {
        grid-template-columns:1fr;
    }

    .form-footer {
        flex-direction:column-reverse;
        padding:18px;
    }

    .btn-cancel,
    .btn-save {
        width:100%;
    }

}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {

    const statusOptions = document.querySelectorAll('.status-option');

    statusOptions.forEach(function (option) {

        option.addEventListener('click', function () {

            statusOptions.forEach(function (item) {
                item.classList.remove('selected');
            });

            this.classList.add('selected');

            const radio = this.querySelector('input[type="radio"]');

            if (radio) {
                radio.checked = true;
            }

        });

    });

});
</script>

<?php $this->load->view('admin/template/footer'); ?>
```
