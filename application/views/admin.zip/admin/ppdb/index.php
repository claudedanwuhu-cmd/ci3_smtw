<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('admin/template/header');
$this->load->view('admin/template/sidebar');
?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- NOTIFIKASI SUKSES -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success-custom mb-4">
                <i class="fa-solid fa-circle-check me-2"></i>
                <?= html_escape($this->session->flashdata('success')); ?>
            </div>
        <?php endif; ?>

        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-file-signature"></i>
                </div>
                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-layer-group me-1"></i> Modul PPDB
                    </span>
                    <h2 class="page-title">Penerimaan Peserta Didik Baru</h2>
                    <p class="page-subtitle">Kelola informasi gelombang, persyaratan, dan alur pendaftaran peserta didik.</p>
                </div>
            </div>
            <a href="<?= site_url('admin/ppdb/tambah'); ?>" class="btn-primary-custom">
                <i class="fa-solid fa-plus me-2"></i> Tambah PPDB
            </a>
        </div>

        <!-- CARD KONTUT UTAMA -->
        <div class="custom-card">
            <div class="card-title-custom d-flex justify-content-between align-items-center p-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="section-icon">
                        <i class="fa-solid fa-list-check"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold" style="color: var(--pres-title);">Daftar Informasi PPDB</h5>
                        <small class="text-muted-custom">Seluruh gelombang pendaftaran yang terdaftar</small>
                    </div>
                </div>
                <span class="total-badge"><?= !empty($ppdb) ? count($ppdb) : 0; ?> Data Aktif</span>
            </div>

            <div class="p-4">
                <?php if (!empty($ppdb)): ?>
                    <div class="d-flex flex-column gap-4">
                        <?php foreach ($ppdb as $item): ?>
                            <div class="ppdb-item-card">
                                
                                <!-- Card Header Item -->
                                <div class="ppdb-item-header d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="ppdb-avatar-icon">
                                            <i class="fa-solid fa-graduation-cap"></i>
                                        </div>
                                        <div>
                                            <h4 class="h5 fw-bold mb-1" style="color: var(--pres-title);"><?= html_escape($item->judul); ?></h4>
                                            <div class="d-flex align-items-center gap-2 text-muted-custom small">
                                                <i class="fa-regular fa-calendar-days text-accent-custom"></i>
                                                <?php if ($item->tanggal_mulai && $item->tanggal_selesai): ?>
                                                    <span><?= date('d M Y', strtotime($item->tanggal_mulai)); ?></span>
                                                    <span>—</span>
                                                    <span><?= date('d M Y', strtotime($item->tanggal_selesai)); ?></span>
                                                <?php else: ?>
                                                    <span class="text-warning fw-medium">Periode belum ditentukan</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <?php if ($item->status === 'aktif'): ?>
                                            <span class="status-badge-custom active">
                                                <i class="fa-solid fa-circle me-1" style="font-size: 6px;"></i> AKTIF
                                            </span>
                                        <?php else: ?>
                                            <span class="status-badge-custom inactive">
                                                <i class="fa-solid fa-circle me-1" style="font-size: 6px;"></i> TIDAK AKTIF
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Card Body Content (Grid 3 Kolom) -->
                                <div class="ppdb-item-body">
                                    <div class="row g-3">
                                        <div class="col-lg-4">
                                            <div class="ppdb-subbox h-100">
                                                <div class="d-flex align-items-center gap-2 fw-bold mb-2 small" style="color: var(--pres-title);">
                                                    <i class="fa-solid fa-circle-info text-accent-custom"></i> Informasi Utama
                                                </div>
                                                <div class="text-muted-custom small lh-base">
                                                    <?= !empty($item->isi) ? nl2br(html_escape($item->isi)) : '<span class="text-muted fst-italic">Belum ada informasi.</span>'; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="ppdb-subbox h-100">
                                                <div class="d-flex align-items-center gap-2 fw-bold mb-2 small" style="color: var(--pres-title);">
                                                    <i class="fa-solid fa-list-check text-accent-custom"></i> Persyaratan
                                                </div>
                                                <div class="text-muted-custom small lh-base">
                                                    <?= !empty($item->persyaratan) ? nl2br(html_escape($item->persyaratan)) : '<span class="text-muted fst-italic">Belum ada persyaratan.</span>'; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-4">
                                            <div class="ppdb-subbox h-100">
                                                <div class="d-flex align-items-center gap-2 fw-bold mb-2 small" style="color: var(--pres-title);">
                                                    <i class="fa-solid fa-route text-accent-custom"></i> Alur Pendaftaran
                                                </div>
                                                <div class="text-muted-custom small lh-base">
                                                    <?= !empty($item->alur) ? nl2br(html_escape($item->alur)) : '<span class="text-muted fst-italic">Belum ada alur.</span>'; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Card Footer Actions -->
                                <div class="ppdb-item-footer d-flex justify-content-between align-items-center">
                                    <span class="text-muted-custom small fw-medium">
                                        <i class="fa-solid fa-shield-halved text-accent-custom me-1"></i> Kontrol Data PPDB
                                    </span>
                                    <div class="action-buttons">
                                        <a href="<?= site_url('admin/ppdb/edit/'.$item->id); ?>" class="btn-action edit" title="Sunting PPDB">
                                            <i class="fa-solid fa-pen-to-square me-1"></i> Sunting
                                        </a>
                                        <a href="<?= site_url('admin/ppdb/hapus/'.$item->id); ?>" class="btn-action delete" title="Hapus PPDB" onclick="return confirm('Yakin ingin menghapus data ini?');">
                                            <i class="fa-solid fa-trash-can me-1"></i> Hapus
                                        </a>
                                    </div>
                                </div>

                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5 empty-data">
                        <div class="empty-icon mb-3">
                            <i class="fa-solid fa-folder-open"></i>
                        </div>
                        <div class="fw-bold mb-1" style="color: var(--pres-title);">Belum Ada Data PPDB</div>
                        <p class="text-muted-custom small mb-3">Silakan buat gelombang pendaftaran baru untuk mulai mengelola data.</p>
                        <a href="<?= site_url('admin/ppdb/tambah'); ?>" class="empty-link">
                            Tambah PPDB sekarang
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<!-- STYLES KUSTOM DINAMIS (DARK/LIGHT MODE ADAPTIVE SESUAI TAMPILAN GURU) -->
<style>
    :root {
        --pres-bg: #ffffff;
        --pres-subtle: #f8fafc;
        --pres-border: rgba(226, 232, 240, 0.8);
        --pres-input-bg: #ffffff;
        --pres-title: #0f172a;
        --pres-subtitle: #64748b;
        --pres-hover: #f1f5f9;
        --pres-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.05);
        --pres-accent: #0ea5e9;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(14, 165, 233, 0.15);
    }

    [data-theme="dark"], [data-bs-theme="dark"], body.dark-mode, .dark-mode {
        --pres-bg: #0f172a;
        --pres-subtle: #1e293b;
        --pres-border: rgba(255, 255, 255, 0.08);
        --pres-input-bg: #1e293b;
        --pres-title: #f8fafc;
        --pres-subtitle: #94a3b8;
        --pres-hover: rgba(255, 255, 255, 0.03);
        --pres-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.4);
        --pres-accent: #38bdf8;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(56, 189, 248, 0.2);
    }

    .text-muted-custom { color: var(--pres-subtitle); }
    .text-accent-custom { color: var(--pres-accent); }

    /* Alert Success */
    .alert-success-custom {
        background: rgba(16, 185, 129, 0.1);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.2);
        padding: 14px 20px;
        border-radius: 14px;
        font-weight: 600;
        font-size: 14px;
    }

    /* Header */
    .page-header-custom {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        padding: 22px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--pres-shadow);
        gap: 20px;
    }

    .badge-header-tag {
        display: inline-flex;
        align-items: center;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .page-title {
        color: var(--pres-title);
        font-size: 22px;
        font-weight: 800;
        margin-bottom: 2px;
    }

    .page-subtitle {
        color: var(--pres-subtitle);
        font-size: 13px;
        margin-bottom: 0;
    }

    .page-header-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        background: var(--pres-subtle);
        border: 1px solid var(--pres-border);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }

    /* Card Wrapper */
    .custom-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--pres-shadow);
    }

    .card-title-custom {
        border-bottom: 1px solid var(--pres-border);
    }

    .total-badge {
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
    }

    .section-icon {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    /* PPDB Item Card */
    .ppdb-item-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.25s ease;
        box-shadow: var(--pres-shadow);
    }

    .ppdb-item-card:hover {
        border-color: var(--pres-accent) !important;
        transform: translateY(-2px);
    }

    .ppdb-item-header {
        padding: 20px 24px;
        background: var(--pres-bg);
        border-bottom: 1px solid var(--pres-border);
    }

    .ppdb-avatar-icon {
        width: 44px;
        height: 44px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        flex-shrink: 0;
    }

    .ppdb-item-body {
        padding: 20px 24px;
        background: var(--pres-bg);
    }

    .ppdb-subbox {
        padding: 16px;
        border-radius: 12px;
        background: var(--pres-subtle);
        border: 1px solid var(--pres-border);
    }

    .ppdb-item-footer {
        padding: 14px 24px;
        background: var(--pres-subtle);
        border-top: 1px solid var(--pres-border);
    }

    /* Status Badges */
    .status-badge-custom {
        display: inline-flex;
        align-items: center;
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 11.5px;
        font-weight: 700;
    }

    .status-badge-custom.active {
        background: rgba(16, 185, 129, 0.1);
        color: #10b981;
        border: 1px solid rgba(16, 185, 129, 0.2);
    }

    .status-badge-custom.inactive {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
    }

    /* Action Buttons */
    .action-buttons {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .btn-action {
        height: 34px;
        border-radius: 10px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 12.5px;
        font-weight: 600;
        transition: all 0.2s ease;
        text-decoration: none;
        padding: 0 14px;
    }

    .btn-action.edit {
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
    }

    .btn-action.edit:hover {
        background: var(--pres-accent);
        color: #ffffff;
    }

    .btn-action.delete {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
    }

    .btn-action.delete:hover {
        background: #ef4444;
        color: #ffffff;
    }

    /* Primary Button */
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, var(--pres-accent) 0%, var(--pres-accent-dark) 100%);
        color: #ffffff !important;
        border-radius: 12px;
        padding: 11px 22px;
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        border: none;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(14, 165, 233, 0.45);
    }

    /* Empty State */
    .empty-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background: var(--pres-subtle);
        color: var(--pres-subtitle);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        border: 1px solid var(--pres-border);
    }

    .empty-link {
        color: var(--pres-accent);
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
    }

    .empty-link:hover {
        text-decoration: underline;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .page-header-custom {
            flex-direction: column;
            align-items: stretch;
        }
        .btn-primary-custom {
            width: 100%;
            justify-content: center;
        }
    }
</style>

<?php $this->load->view('admin/template/footer'); ?>