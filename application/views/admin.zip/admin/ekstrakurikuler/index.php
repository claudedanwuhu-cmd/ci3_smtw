<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('admin/template/header');
$this->load->view('admin/template/sidebar');
?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- NOTIFIKASI SUKSES -->
        <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success-custom alert-dismissible fade show mb-4" role="alert">
            <div class="d-flex align-items-center gap-3">
                <div class="success-icon-box">
                    <i class="fa-solid fa-circle-check"></i>
                </div>

                <div>
                    <h6 class="alert-heading mb-0">Berhasil</h6>
                    <span class="fs-7">
                        <?= html_escape($this->session->flashdata('success')); ?>
                    </span>
                </div>
            </div>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                    aria-label="Close"></button>
        </div>
        <?php endif; ?>


        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">

            <div class="d-flex align-items-center gap-3">

                <div class="page-header-icon">
                    <i class="fa-solid fa-people-group"></i>
                </div>

                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-layer-group me-1"></i>
                        Data Kegiatan
                    </span>

                    <h2 class="page-title">
                        Ekstrakurikuler
                    </h2>

                    <p class="page-subtitle">
                        Kelola daftar kegiatan pengembangan minat dan bakat siswa.
                    </p>
                </div>

            </div>

            <a href="<?= site_url('admin/ekstrakurikuler/tambah'); ?>"
               class="btn-primary-custom">

                <i class="fa-solid fa-plus me-2"></i>
                Tambah Ekstrakurikuler

            </a>

        </div>


        <!-- CARD DATA -->
        <div class="custom-card">

            <div class="card-title-custom">

                <div class="card-title-left">

                    <div class="title-icon">
                        <i class="fa-solid fa-list-check"></i>
                    </div>

                    <div>
                        <h5>
                            Daftar Ekstrakurikuler
                        </h5>

                        <small>
                            Kegiatan aktif dan nonaktif yang terdaftar
                        </small>
                    </div>

                </div>

                <span class="total-badge">
                    <?= count($ekstrakurikuler); ?> Data
                </span>

            </div>


            <div class="table-responsive">

                <table class="table custom-table align-middle mb-0">

                    <thead>
                        <tr>
                            <th width="60" class="text-center">
                                No
                            </th>

                            <th>
                                Ekstrakurikuler
                            </th>

                            <th>
                                Pembina
                            </th>

                            <th>
                                Jadwal
                            </th>

                            <th>
                                Tempat
                            </th>

                            <th>
                                Status
                            </th>

                            <th width="120" class="text-end">
                                Aksi
                            </th>
                        </tr>
                    </thead>


                    <tbody>

                        <?php if (!empty($ekstrakurikuler)): ?>

                            <?php $no = 1; ?>

                            <?php foreach ($ekstrakurikuler as $item): ?>

                            <tr>

                                <!-- NOMOR -->
                                <td class="text-center">

                                    <span class="number-cell">
                                        <?= $no++; ?>
                                    </span>

                                </td>


                                <!-- EKSTRAKURIKULER -->
                                <td>

                                    <div class="item-wrapper">

                                        <div class="item-avatar">

                                            <?php if (!empty($item->foto)): ?>

                                                <img
                                                    src="<?= base_url('uploads/ekstrakurikuler/'.$item->foto); ?>"
                                                    alt="Ekstrakurikuler">

                                            <?php else: ?>

                                                <i class="fa-solid fa-people-group"></i>

                                            <?php endif; ?>

                                        </div>


                                        <div class="item-content">

                                            <div class="item-title">
                                                <?= html_escape($item->nama); ?>
                                            </div>

                                            <span class="item-label">
                                                Kegiatan Siswa
                                            </span>

                                        </div>

                                    </div>

                                </td>


                                <!-- PEMBINA -->
                                <td>

                                    <div class="table-info">

                                        <div class="table-info-icon">
                                            <i class="fa-solid fa-user-tie"></i>
                                        </div>

                                        <span>
                                            <?=
                                            !empty($item->pembina)
                                                ? html_escape($item->pembina)
                                                : '<span class="text-muted-custom">-</span>';
                                            ?>
                                        </span>

                                    </div>

                                </td>


                                <!-- JADWAL -->
                                <td>

                                    <div class="table-info">

                                        <div class="table-info-icon">
                                            <i class="fa-solid fa-clock"></i>
                                        </div>

                                        <span>
                                            <?=
                                            !empty($item->jadwal)
                                                ? html_escape($item->jadwal)
                                                : '<span class="text-muted-custom">-</span>';
                                            ?>
                                        </span>

                                    </div>

                                </td>


                                <!-- TEMPAT -->
                                <td>

                                    <div class="table-info">

                                        <div class="table-info-icon">
                                            <i class="fa-solid fa-location-dot"></i>
                                        </div>

                                        <span>
                                            <?=
                                            !empty($item->tempat)
                                                ? html_escape($item->tempat)
                                                : '<span class="text-muted-custom">-</span>';
                                            ?>
                                        </span>

                                    </div>

                                </td>


                                <!-- STATUS -->
                                <td>

                                    <span class="status-badge
                                        <?= $item->status === 'aktif'
                                            ? 'active'
                                            : 'inactive'; ?>">

                                        <i class="fa-solid fa-circle"></i>

                                        <?= ucfirst($item->status); ?>

                                    </span>

                                </td>


                                <!-- AKSI -->
                                <td>

                                    <div class="action-buttons">

                                        <a href="<?= site_url('admin/ekstrakurikuler/edit/'.$item->id); ?>"
                                           class="btn-action edit"
                                           title="Edit">

                                            <i class="fa-solid fa-pen"></i>

                                        </a>


                                        <a href="<?= site_url('admin/ekstrakurikuler/hapus/'.$item->id); ?>"
                                           class="btn-action delete"
                                           title="Hapus"
                                           onclick="return confirm('Yakin ingin menghapus data ekstrakurikuler ini?');">

                                            <i class="fa-solid fa-trash"></i>

                                        </a>

                                    </div>

                                </td>

                            </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <!-- EMPTY STATE -->
                            <tr>

                                <td colspan="7" class="empty-data">

                                    <div class="empty-state">

                                        <div class="empty-icon">
                                            <i class="fa-solid fa-people-group"></i>
                                        </div>

                                        <div class="empty-title">
                                            Belum ada data ekstrakurikuler
                                        </div>

                                        <div class="empty-description">
                                            Belum terdapat kegiatan ekstrakurikuler yang terdaftar.
                                        </div>

                                        <a href="<?= site_url('admin/ekstrakurikuler/tambah'); ?>"
                                           class="empty-link">

                                            <i class="fa-solid fa-plus me-1"></i>
                                            Tambahkan kegiatan sekarang

                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>
</div>


<style>

/* =========================================================
   EKSTRAKURIKULER - LIST PAGE
   DESIGN SYSTEM
========================================================= */

:root {

    --ekstra-bg: #f8fafc;

    --ekstra-card-bg: #ffffff;
    --ekstra-card-subtle: #f8fafc;

    --ekstra-input-bg: #f8fafc;
    --ekstra-input-border: #cbd5e1;

    --ekstra-title: #0f172a;
    --ekstra-subtitle: #64748b;

    --ekstra-border: rgba(226, 232, 240, 0.8);

    --ekstra-hover: #f1f5f9;

    --ekstra-accent: #0ea5e9;
    --ekstra-accent-dark: #0284c7;

    --ekstra-accent-soft: rgba(14, 165, 233, 0.12);

    --ekstra-shadow:
        0 10px 25px -5px rgba(15, 23, 42, 0.05),
        0 8px 10px -6px rgba(15, 23, 42, 0.01);

}


/* DARK MODE */

[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {

    --ekstra-bg: #070d19;

    --ekstra-card-bg: #0f172a;
    --ekstra-card-subtle: #1e293b;

    --ekstra-input-bg: #1e293b;
    --ekstra-input-border: rgba(255, 255, 255, 0.12);

    --ekstra-title: #f8fafc;
    --ekstra-subtitle: #94a3b8;

    --ekstra-border: rgba(255, 255, 255, 0.08);

    --ekstra-hover: #1e293b;

    --ekstra-accent: #38bdf8;
    --ekstra-accent-dark: #0284c7;

    --ekstra-accent-soft: rgba(56, 189, 248, 0.12);

    --ekstra-shadow:
        0 12px 30px -5px rgba(0, 0, 0, 0.4);

}


/* =========================================================
   TEXT
========================================================= */

.fs-7 {
    font-size: 13px;
}


/* =========================================================
   SUCCESS ALERT
========================================================= */

.alert-success-custom {

    background: rgba(34, 197, 94, 0.10);

    border: 1px solid rgba(34, 197, 94, 0.22);

    color: #16a34a;

    border-radius: 16px;

    padding: 16px 20px;

    backdrop-filter: blur(8px);

}

.success-icon-box {

    width: 36px;
    height: 36px;

    border-radius: 10px;

    background: rgba(34, 197, 94, 0.15);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 18px;

    flex-shrink: 0;

}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-header-custom {

    background: var(--ekstra-card-bg);

    border: 1px solid var(--ekstra-border);

    border-radius: 20px;

    padding: 22px 28px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

    box-shadow: var(--ekstra-shadow);

}


.page-header-icon {

    width: 50px;
    height: 50px;

    border-radius: 14px;

    background: var(--ekstra-card-subtle);

    border: 1px solid var(--ekstra-border);

    color: var(--ekstra-accent);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 22px;

    flex-shrink: 0;

}


.badge-header-tag {

    display: inline-flex;

    align-items: center;

    background: var(--ekstra-accent-soft);

    color: var(--ekstra-accent);

    border: 1px solid rgba(14, 165, 233, 0.20);

    padding: 4px 12px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: .5px;

}


.page-title {

    color: var(--ekstra-title);

    font-size: 22px;

    font-weight: 800;

    margin: 0 0 2px;

    letter-spacing: -.3px;

}


.page-subtitle {

    color: var(--ekstra-subtitle);

    font-size: 13px;

    margin: 0;

}


/* =========================================================
   PRIMARY BUTTON
========================================================= */

.btn-primary-custom {

    display: inline-flex;

    align-items: center;
    justify-content: center;

    border: none;

    background: linear-gradient(
        135deg,
        #0284c7 0%,
        #0369a1 100%
    );

    color: #fff;

    text-decoration: none;

    border-radius: 12px;

    padding: 11px 20px;

    font-size: 13px;

    font-weight: 700;

    transition: all .3s ease;

    box-shadow:
        0 4px 15px rgba(2, 132, 199, .25);

}


.btn-primary-custom:hover {

    color: #fff;

    transform: translateY(-2px);

    box-shadow:
        0 8px 22px rgba(2, 132, 199, .40);

}


/* =========================================================
   CARD
========================================================= */

.custom-card {

    background: var(--ekstra-card-bg);

    border: 1px solid var(--ekstra-border);

    border-radius: 20px;

    overflow: hidden;

    box-shadow: var(--ekstra-shadow);

}


/* =========================================================
   CARD HEADER
========================================================= */

.card-title-custom {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

    padding: 18px 24px;

    background: var(--ekstra-card-subtle);

    border-bottom: 1px solid var(--ekstra-border);

}


.card-title-left {

    display: flex;

    align-items: center;

    gap: 14px;

}


.title-icon {

    width: 40px;
    height: 40px;

    border-radius: 12px;

    background: var(--ekstra-accent-soft);

    color: var(--ekstra-accent);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 16px;

    flex-shrink: 0;

}


.card-title-custom h5 {

    margin: 0 0 2px;

    color: var(--ekstra-title);

    font-size: 15px;

    font-weight: 700;

}


.card-title-custom small {

    color: var(--ekstra-subtitle);

    font-size: 12px;

}


.total-badge {

    display: inline-flex;

    align-items: center;

    padding: 6px 12px;

    border-radius: 20px;

    background: var(--ekstra-accent-soft);

    color: var(--ekstra-accent);

    border: 1px solid rgba(14,165,233,.18);

    font-size: 11px;

    font-weight: 700;

}


/* =========================================================
   TABLE
========================================================= */

.custom-table {

    color: var(--ekstra-title);

}


.custom-table thead th {

    background: var(--ekstra-card-subtle);

    color: var(--ekstra-subtitle);

    border-bottom: 1px solid var(--ekstra-border);

    border-top: none;

    padding: 13px 16px;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: .4px;

    white-space: nowrap;

}


.custom-table tbody td {

    padding: 15px 16px;

    border-bottom: 1px solid var(--ekstra-border);

    color: var(--ekstra-title);

    font-size: 13px;

    vertical-align: middle;

}


.custom-table tbody tr:last-child td {

    border-bottom: none;

}


.custom-table tbody tr {

    transition: background .2s ease;

}


.custom-table tbody tr:hover {

    background: var(--ekstra-hover);

}


/* =========================================================
   NUMBER
========================================================= */

.number-cell {

    color: var(--ekstra-subtitle);

    font-family: monospace;

    font-size: 12px;

    font-weight: 600;

}


/* =========================================================
   ITEM
========================================================= */

.item-wrapper {

    display: flex;

    align-items: center;

    gap: 12px;

}


.item-avatar {

    width: 42px;
    height: 42px;

    border-radius: 12px;

    background: var(--ekstra-accent-soft);

    border: 1px solid rgba(14,165,233,.16);

    color: var(--ekstra-accent);

    display: flex;

    align-items: center;
    justify-content: center;

    overflow: hidden;

    flex-shrink: 0;

}


.item-avatar img {

    width: 100%;
    height: 100%;

    object-fit: cover;

}


.item-title {

    color: var(--ekstra-title);

    font-size: 13px;

    font-weight: 700;

    margin-bottom: 2px;

}


.item-label {

    color: var(--ekstra-subtitle);

    font-size: 11px;

}


/* =========================================================
   TABLE INFO
========================================================= */

.table-info {

    display: inline-flex;

    align-items: center;

    gap: 8px;

}


.table-info-icon {

    color: var(--ekstra-subtitle);

    font-size: 12px;

    width: 18px;

    text-align: center;

}


.text-muted-custom {

    color: var(--ekstra-subtitle) !important;

}


/* =========================================================
   STATUS
========================================================= */

.status-badge {

    display: inline-flex;

    align-items: center;

    gap: 4px;

    padding: 6px 10px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 700;

}


.status-badge i {

    font-size: 6px;

}


.status-badge.active {

    background: rgba(34,197,94,.11);

    color: #16a34a;

    border: 1px solid rgba(34,197,94,.18);

}


.status-badge.inactive {

    background: rgba(239,68,68,.10);

    color: #dc2626;

    border: 1px solid rgba(239,68,68,.18);

}


/* =========================================================
   ACTION
========================================================= */

.action-buttons {

    display: flex;

    align-items: center;

    justify-content: flex-end;

    gap: 7px;

}


.btn-action {

    width: 34px;
    height: 34px;

    display: inline-flex;

    align-items: center;
    justify-content: center;

    border-radius: 10px;

    text-decoration: none;

    font-size: 12px;

    transition: all .2s ease;

}


.btn-action.edit {

    background: rgba(14,165,233,.10);

    color: var(--ekstra-accent);

    border: 1px solid rgba(14,165,233,.15);

}


.btn-action.edit:hover {

    background: var(--ekstra-accent);

    color: #fff;

    transform: translateY(-2px);

}


.btn-action.delete {

    background: rgba(239,68,68,.08);

    color: #ef4444;

    border: 1px solid rgba(239,68,68,.14);

}


.btn-action.delete:hover {

    background: #ef4444;

    color: #fff;

    transform: translateY(-2px);

}


/* =========================================================
   EMPTY STATE
========================================================= */

.empty-data {

    padding: 65px 20px !important;

}


.empty-state {

    display: flex;

    flex-direction: column;

    align-items: center;

    justify-content: center;

}


.empty-icon {

    width: 64px;
    height: 64px;

    border-radius: 18px;

    background: var(--ekstra-accent-soft);

    color: var(--ekstra-accent);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 25px;

    margin-bottom: 15px;

}


.empty-title {

    color: var(--ekstra-title);

    font-size: 14px;

    font-weight: 700;

    margin-bottom: 5px;

}


.empty-description {

    color: var(--ekstra-subtitle);

    font-size: 12px;

    margin-bottom: 12px;

}


.empty-link {

    color: var(--ekstra-accent);

    font-size: 12px;

    font-weight: 700;

    text-decoration: none;

}


.empty-link:hover {

    color: var(--ekstra-accent-dark);

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .custom-table {

        min-width: 900px;

    }

}


@media (max-width: 768px) {

    .page-header-custom {

        flex-direction: column;

        align-items: stretch;

    }

    .btn-primary-custom {

        width: 100%;

    }

    .card-title-custom {

        padding: 18px;

    }

    .card-title-left {

        gap: 10px;

    }

    .total-badge {

        display: none;

    }

}

</style>


<?php $this->load->view('admin/template/footer'); ?>