<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$this->load->view('admin/template/header');
$this->load->view('admin/template/sidebar');
?>

<div class="main-content">

    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">


        <!-- FLASH ERROR -->
        <?php if ($this->session->flashdata('error')): ?>

        <div class="alert alert-custom-danger alert-dismissible fade show mb-4"
             role="alert">

            <div class="d-flex align-items-center gap-3">

                <div class="alert-icon-box">
                    <i class="fa-solid fa-circle-exclamation"></i>
                </div>

                <div>

                    <h6 class="alert-heading mb-0">
                        Gagal Memproses Data
                    </h6>

                    <span class="fs-7">
                        <?= html_escape($this->session->flashdata('error')); ?>
                    </span>

                </div>

            </div>

            <button type="button"
                    class="btn-close btn-close-white"
                    data-bs-dismiss="alert">
            </button>

        </div>

        <?php endif; ?>


        <!-- PAGE HEADER -->
        <div class="page-header-custom mb-4">

            <div class="d-flex align-items-center gap-3">

                <div class="page-header-icon">
                    <i class="fa-solid fa-people-group"></i>
                </div>

                <div>

                    <span class="badge-header-tag mb-1">

                        <i class="fa-solid fa-pen-to-square me-1"></i>
                        Edit Data

                    </span>

                    <h2 class="page-title">
                        Edit Ekstrakurikuler
                    </h2>

                    <p class="page-subtitle">
                        Perbarui informasi dan dokumentasi kegiatan ekstrakurikuler.
                    </p>

                </div>

            </div>


            <a href="<?= site_url('admin/ekstrakurikuler'); ?>"
               class="btn-back">

                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali

            </a>

        </div>


        <!-- FORM -->
        <form
            action="<?= site_url('admin/ekstrakurikuler/update/'.$ekstrakurikuler->id); ?>"
            method="POST"
            enctype="multipart/form-data">

            <!-- CSRF -->
            <input
                type="hidden"
                name="<?= $this->security->get_csrf_token_name(); ?>"
                value="<?= $this->security->get_csrf_hash(); ?>">


            <div class="custom-card mb-4">


                <!-- CARD HEADER -->
                <div class="card-title-custom">

                    <div class="d-flex align-items-center gap-3">

                        <div class="title-icon">

                            <i class="fa-solid fa-address-card"></i>

                        </div>

                        <div>

                            <h5>
                                Informasi Kegiatan
                            </h5>

                            <small>
                                Perbarui informasi utama ekstrakurikuler
                            </small>

                        </div>

                    </div>

                </div>


                <!-- BODY -->
                <div class="card-body-custom">

                    <div class="row g-4">


                        <!-- NAMA -->
                        <div class="col-md-8">

                            <label class="form-label required">
                                Nama Ekstrakurikuler
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-people-group input-icon"></i>

                                <input
                                    type="text"
                                    name="nama"
                                    class="form-control with-icon"
                                    value="<?= html_escape($ekstrakurikuler->nama); ?>"
                                    placeholder="Contoh: Pramuka / Basket"
                                    required>

                            </div>

                        </div>


                        <!-- PEMBINA -->
                        <div class="col-md-4">

                            <label class="form-label">
                                Pembina Ekstrakurikuler
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-user-tie input-icon"></i>

                                <input
                                    type="text"
                                    name="pembina"
                                    class="form-control with-icon"
                                    value="<?= html_escape($ekstrakurikuler->pembina); ?>"
                                    placeholder="Nama pembina / pelatih">

                            </div>

                        </div>


                        <!-- JADWAL -->
                        <div class="col-md-6">

                            <label class="form-label">
                                Jadwal Kegiatan
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-calendar-days input-icon"></i>

                                <input
                                    type="text"
                                    name="jadwal"
                                    class="form-control with-icon"
                                    value="<?= html_escape($ekstrakurikuler->jadwal); ?>"
                                    placeholder="Contoh: Setiap Jumat, 15:00 WIB">

                            </div>

                        </div>


                        <!-- TEMPAT -->
                        <div class="col-md-6">

                            <label class="form-label">
                                Lokasi / Tempat
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-location-dot input-icon"></i>

                                <input
                                    type="text"
                                    name="tempat"
                                    class="form-control with-icon"
                                    value="<?= html_escape($ekstrakurikuler->tempat); ?>"
                                    placeholder="Contoh: Lapangan Utama">

                            </div>

                        </div>


                        <!-- STATUS -->
                        <div class="col-md-4">

                            <label class="form-label">
                                Status Kegiatan
                            </label>

                            <div class="input-icon-group">

                                <i class="fa-solid fa-toggle-on input-icon"></i>

                                <select
                                    name="status"
                                    class="form-select with-icon">

                                    <option
                                        value="aktif"
                                        <?= $ekstrakurikuler->status === 'aktif'
                                            ? 'selected'
                                            : ''; ?>>

                                        🟢 Aktif

                                    </option>

                                    <option
                                        value="nonaktif"
                                        <?= $ekstrakurikuler->status === 'nonaktif'
                                            ? 'selected'
                                            : ''; ?>>

                                        🔴 Nonaktif

                                    </option>

                                </select>

                            </div>

                        </div>


                    </div>

                </div>


                <!-- FOTO -->
                <div class="section-divider">

                    <div class="section-heading">

                        <div class="title-icon">

                            <i class="fa-solid fa-image"></i>

                        </div>

                        <div>

                            <h5>
                                Dokumentasi / Foto Sampul
                            </h5>

                            <small>
                                Pilih foto baru jika ingin mengganti foto saat ini
                            </small>

                        </div>

                    </div>


                    <div class="photo-section-body">

                        <label class="form-label">
                            Upload Foto Baru
                            <span class="optional-label">
                                (Opsional)
                            </span>
                        </label>


                        <div
                            class="upload-dropzone"
                            id="dropzone-area">


                            <input
                                type="file"
                                name="foto"
                                id="file-input"
                                class="d-none"
                                accept="image/png,image/jpeg,image/jpg,image/webp">


                            <!-- PROMPT -->
                            <div
                                class="dropzone-content
                                <?= !empty($ekstrakurikuler->foto)
                                    ? 'd-none'
                                    : ''; ?>"
                                id="dropzone-prompt">

                                <div class="upload-icon-circle">

                                    <i class="fa-solid fa-cloud-arrow-up"></i>

                                </div>

                                <p class="upload-text mb-1">

                                    <strong>
                                        Klik atau seret file ke sini untuk mengunggah
                                    </strong>

                                </p>

                                <span class="upload-subtext">

                                    PNG, JPG, JPEG, atau WEBP
                                    (Maksimal 2MB)

                                </span>

                            </div>


                            <!-- PREVIEW -->
                            <div
                                class="preview-wrapper
                                <?= !empty($ekstrakurikuler->foto)
                                    ? ''
                                    : 'd-none'; ?>"
                                id="dropzone-preview">


                                <img
                                    src="<?= !empty($ekstrakurikuler->foto)
                                        ? base_url(
                                            'uploads/ekstrakurikuler/'
                                            .$ekstrakurikuler->foto
                                        )
                                        : ''; ?>"
                                    id="image-preview"
                                    alt="Preview Foto"
                                    class="preview-image">


                                <div class="preview-info">

                                    <span
                                        id="file-name"
                                        class="preview-filename">

                                        <?= !empty($ekstrakurikuler->foto)
                                            ? html_escape($ekstrakurikuler->foto)
                                            : 'nama_file.jpg'; ?>

                                    </span>


                                    <span
                                        id="file-size"
                                        class="preview-current">

                                        Foto Saat Ini

                                    </span>


                                    <button
                                        type="button"
                                        class="btn-change-image"
                                        id="btn-remove-file">

                                        <i class="fa-solid fa-rotate me-1"></i>

                                        Ganti Foto

                                    </button>

                                </div>

                            </div>


                        </div>

                    </div>

                </div>


                <!-- DESKRIPSI -->
                <div class="description-section">

                    <div class="section-heading">

                        <div class="title-icon">

                            <i class="fa-solid fa-align-left"></i>

                        </div>

                        <div>

                            <h5>
                                Deskripsi Kegiatan
                            </h5>

                            <small>
                                Penjelasan mengenai aktivitas dan profil ekstrakurikuler
                            </small>

                        </div>

                    </div>


                    <div>

                        <label class="form-label">
                            Deskripsi Lengkap
                        </label>

                        <textarea
                            name="deskripsi"
                            class="form-control custom-textarea"
                            rows="4"
                            placeholder="Tuliskan deskripsi kegiatan ekstrakurikuler..."><?= html_escape($ekstrakurikuler->deskripsi); ?></textarea>

                    </div>

                </div>


                <!-- FOOTER -->
                <div class="form-footer">

                    <a
                        href="<?= site_url('admin/ekstrakurikuler'); ?>"
                        class="btn-cancel">

                        <i class="fa-solid fa-xmark me-2"></i>
                        Batal

                    </a>


                    <button
                        type="submit"
                        class="btn-save">

                        <i class="fa-solid fa-floppy-disk me-2"></i>
                        Simpan Perubahan

                    </button>

                </div>


            </div>

        </form>

    </div>

</div>


<style>

/* =========================================================
   EKSTRAKURIKULER EDIT
   CONSISTENT WITH GURU ADD / EDIT
========================================================= */

:root {

    --ekstra-card-bg: #ffffff;
    --ekstra-card-subtle: #f8fafc;

    --ekstra-input-bg: #f8fafc;
    --ekstra-input-border: #cbd5e1;

    --ekstra-input-color: #0f172a;
    --ekstra-input-focus-bg: #ffffff;

    --ekstra-border: rgba(226,232,240,.8);

    --ekstra-title: #0f172a;
    --ekstra-subtitle: #64748b;

    --ekstra-hover: #f1f5f9;

    --ekstra-accent: #0ea5e9;
    --ekstra-accent-glow: rgba(14,165,233,.25);

    --ekstra-icon-muted: #94a3b8;

    --dropzone-bg: #f1f5f9;
    --dropzone-border: #cbd5e1;

    --ekstra-shadow:
        0 10px 25px -5px rgba(15,23,42,.05),
        0 8px 10px -6px rgba(15,23,42,.01);

}


[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {

    --ekstra-card-bg: #0f172a;
    --ekstra-card-subtle: #1e293b;

    --ekstra-input-bg: #1e293b;
    --ekstra-input-border: rgba(255,255,255,.12);

    --ekstra-input-color: #f1f5f9;
    --ekstra-input-focus-bg: #111827;

    --ekstra-border: rgba(255,255,255,.08);

    --ekstra-title: #f8fafc;
    --ekstra-subtitle: #94a3b8;

    --ekstra-hover: #1e293b;

    --ekstra-accent: #38bdf8;
    --ekstra-accent-glow: rgba(56,189,248,.25);

    --ekstra-icon-muted: #64748b;

    --dropzone-bg: #111827;
    --dropzone-border: rgba(255,255,255,.15);

    --ekstra-shadow:
        0 12px 30px -5px rgba(0,0,0,.4);

}


/* =========================================================
   GLOBAL
========================================================= */

.fs-7 {
    font-size: 13px;
}


/* =========================================================
   ALERT
========================================================= */

.alert-custom-danger {

    background: rgba(239,68,68,.12);

    border: 1px solid rgba(239,68,68,.25);

    color: #ef4444;

    border-radius: 16px;

    padding: 16px 20px;

    backdrop-filter: blur(8px);

}


.alert-icon-box {

    width: 36px;
    height: 36px;

    border-radius: 10px;

    background: rgba(239,68,68,.20);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 18px;

    flex-shrink: 0;

}


/* =========================================================
   HEADER
========================================================= */

.page-header-custom {

    background: var(--ekstra-card-bg);

    border: 1px solid var(--ekstra-border);

    border-radius: 20px;

    padding: 22px 28px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 20px;

    box-shadow: var(--ekstra-shadow);

}


.page-header-icon {

    width: 50px;
    height: 50px;

    border-radius: 14px;

    background: var(--ekstra-card-subtle);

    border: 1px solid var(--ekstra-border);

    color: var(--ekstra-accent);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 22px;

    flex-shrink: 0;

}


.badge-header-tag {

    display: inline-flex;

    align-items: center;

    background: rgba(14,165,233,.10);

    color: var(--ekstra-accent);

    border: 1px solid rgba(14,165,233,.20);

    padding: 4px 12px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: 700;

    text-transform: uppercase;

    letter-spacing: .5px;

}


.page-title {

    color: var(--ekstra-title);

    font-size: 22px;

    font-weight: 800;

    margin: 0 0 2px;

    letter-spacing: -.3px;

}


.page-subtitle {

    color: var(--ekstra-subtitle);

    font-size: 13px;

    margin: 0;

}


/* =========================================================
   BACK
========================================================= */

.btn-back {

    display: inline-flex;

    align-items: center;
    justify-content: center;

    background: var(--ekstra-card-subtle);

    color: var(--ekstra-title);

    border: 1px solid var(--ekstra-border);

    text-decoration: none;

    padding: 10px 20px;

    border-radius: 12px;

    font-size: 13px;

    font-weight: 600;

    transition: all .25s ease;

}


.btn-back:hover {

    background: var(--ekstra-hover);

    color: var(--ekstra-accent);

    transform: translateX(-3px);

}


/* =========================================================
   CARD
========================================================= */

.custom-card {

    background: var(--ekstra-card-bg);

    border: 1px solid var(--ekstra-border);

    border-radius: 20px;

    overflow: hidden;

    box-shadow: var(--ekstra-shadow);

}


/* =========================================================
   CARD TITLE
========================================================= */

.card-title-custom {

    display: flex;

    align-items: center;

    gap: 14px;

    padding: 18px 24px;

    background: var(--ekstra-card-subtle);

    border-bottom: 1px solid var(--ekstra-border);

}


.title-icon {

    width: 40px;
    height: 40px;

    background: rgba(14,165,233,.12);

    border-radius: 12px;

    color: var(--ekstra-accent);

    display: flex;

    align-items: center;
    justify-content: center;

    font-size: 16px;

    flex-shrink: 0;

}


.card-title-custom h5,
.section-heading h5 {

    margin: 0 0 2px;

    color: var(--ekstra-title);

    font-size: 15px;

    font-weight: 700;

}


.card-title-custom small,
.section-heading small {

    color: var(--ekstra-subtitle);

    font-size: 12px;

}


/* =========================================================
   BODY
========================================================= */

.card-body-custom {

    padding: 24px;

}


/* =========================================================
   FORM
========================================================= */

.form-label {

    color: var(--ekstra-title);

    font-size: 12.5px;

    font-weight: 700;

    margin-bottom: 8px;

}


.form-label.required::after {

    content: " *";

    color: #ef4444;

}


.optional-label {

    color: var(--ekstra-subtitle);

    font-weight: 500;

}


.input-icon-group {

    position: relative;

    display: flex;

    align-items: center;

}


.input-icon {

    position: absolute;

    left: 14px;

    color: var(--ekstra-icon-muted);

    font-size: 14px;

    z-index: 2;

    pointer-events: none;

    transition: color .25s ease;

}


.form-control,
.form-select {

    background-color: var(--ekstra-input-bg);

    border: 1px solid var(--ekstra-input-border);

    border-radius: 12px;

    font-size: 13.5px;

    color: var(--ekstra-input-color);

    padding: 10px 16px;

    min-height: 43px;

    transition: all .25s ease;

}


.with-icon {

    padding-left: 42px !important;

}


.form-control:focus,
.form-select:focus {

    background-color: var(--ekstra-input-focus-bg);

    border-color: var(--ekstra-accent);

    color: var(--ekstra-input-color);

    box-shadow:
        0 0 0 4px var(--ekstra-accent-glow);

    outline: none;

}


.input-icon-group:focus-within .input-icon {

    color: var(--ekstra-accent);

}


.form-control::placeholder {

    color: var(--ekstra-subtitle);

    opacity: .6;

}


.custom-textarea {

    resize: vertical;

    min-height: 110px;

    line-height: 1.6;

}


/* =========================================================
   SECTION DIVIDER
========================================================= */

.section-divider {

    border-top: 1px solid var(--ekstra-border);

    padding: 24px;

}


.section-heading {

    display: flex;

    align-items: center;

    gap: 14px;

    margin-bottom: 20px;

}


/* =========================================================
   PHOTO
========================================================= */

.photo-section-body {

    width: 100%;

}


.upload-dropzone {

    border: 2px dashed var(--dropzone-border);

    background: var(--dropzone-bg);

    border-radius: 16px;

    padding: 26px;

    cursor: pointer;

    transition: all .25s ease;

}


.upload-dropzone:hover {

    border-color: var(--ekstra-accent);

    background: var(--ekstra-card-subtle);

}


.upload-icon-circle {

    width: 44px;
    height: 44px;

    border-radius: 50%;

    background: rgba(14,165,233,.12);

    color: var(--ekstra-accent);

    display: inline-flex;

    align-items: center;
    justify-content: center;

    font-size: 18px;

    margin-bottom: 10px;

}


.upload-text {

    color: var(--ekstra-title);

    font-size: 13.5px;

}


.upload-subtext {

    color: var(--ekstra-subtitle);

    font-size: 11.5px;

}


/* =========================================================
   PREVIEW
========================================================= */

.preview-wrapper {

    display: flex;

    align-items: center;

    justify-content: center;

    gap: 18px;

}


.preview-image {

    width: 90px;
    height: 90px;

    object-fit: cover;

    border-radius: 16px;

    border: 2px solid var(--ekstra-accent);

    box-shadow:
        0 4px 12px rgba(0,0,0,.12);

}


.preview-info {

    display: flex;

    flex-direction: column;

    align-items: flex-start;

    min-width: 0;

}


.preview-filename {

    color: var(--ekstra-title);

    font-size: 13px;

    font-weight: 700;

    max-width: 300px;

    overflow: hidden;

    text-overflow: ellipsis;

    white-space: nowrap;

}


.preview-current {

    color: var(--ekstra-subtitle);

    font-size: 11.5px;

    margin-top: 3px;

}


.btn-change-image {

    border: 1px solid rgba(14,165,233,.20);

    background: var(--ekstra-accent-soft);

    color: var(--ekstra-accent);

    border-radius: 10px;

    padding: 7px 12px;

    font-size: 11px;

    font-weight: 700;

    cursor: pointer;

    transition: all .2s ease;

}


.btn-change-image:hover {

    background: var(--ekstra-accent);

    color: #fff;

}


/* =========================================================
   DESCRIPTION
========================================================= */

.description-section {

    border-top: 1px solid var(--ekstra-border);

    padding: 24px;

}


/* =========================================================
   FOOTER
========================================================= */

.form-footer {

    padding: 18px 24px;

    background: var(--ekstra-card-subtle);

    border-top: 1px solid var(--ekstra-border);

    display: flex;

    align-items: center;

    justify-content: flex-end;

    gap: 12px;

}


.btn-cancel {

    background: var(--ekstra-card-bg);

    border: 1px solid var(--ekstra-border);

    color: var(--ekstra-title);

    text-decoration: none;

    border-radius: 12px;

    padding: 11px 22px;

    font-size: 13px;

    font-weight: 600;

    transition: all .2s ease;

}


.btn-cancel:hover {

    background: var(--ekstra-hover);

    color: #ef4444;

}


.btn-save {

    border: none;

    background: linear-gradient(
        135deg,
        #0284c7 0%,
        #0369a1 100%
    );

    color: #fff;

    border-radius: 12px;

    padding: 11px 26px;

    font-size: 13px;

    font-weight: 700;

    transition: all .3s ease;

    box-shadow:
        0 4px 15px rgba(2,132,199,.30);

    cursor: pointer;

}


.btn-save:hover {

    transform: translateY(-2px);

    box-shadow:
        0 8px 22px rgba(2,132,199,.45);

    color: #fff;

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 768px) {

    .page-header-custom {

        flex-direction: column;

        align-items: stretch;

    }


    .btn-back {

        width: 100%;

    }


    .card-body-custom,
    .section-divider,
    .description-section,
    .card-title-custom,
    .form-footer {

        padding: 20px 18px;

    }


    .form-footer {

        flex-direction: column-reverse;

        align-items: stretch;

    }


    .btn-cancel,
    .btn-save {

        width: 100%;

        text-align: center;

    }


    .preview-wrapper {

        flex-direction: column;

        text-align: center;

    }


    .preview-info {

        align-items: center;

    }

}

</style>


<script>

document.addEventListener('DOMContentLoaded', function () {

    const fileInput =
        document.getElementById('file-input');

    const dropzone =
        document.getElementById('dropzone-area');

    const prompt =
        document.getElementById('dropzone-prompt');

    const preview =
        document.getElementById('dropzone-preview');

    const imagePreview =
        document.getElementById('image-preview');

    const fileName =
        document.getElementById('file-name');

    const fileSize =
        document.getElementById('file-size');

    const changeButton =
        document.getElementById('btn-remove-file');


    if (!fileInput) return;


    /*
     * Klik area upload membuka file picker.
     */
    dropzone.addEventListener('click', function (event) {

        if (event.target.closest('#btn-remove-file')) {
            return;
        }

        fileInput.click();

    });


    /*
     * Ketika file dipilih.
     */
    fileInput.addEventListener('change', function () {

        const file = this.files[0];

        if (!file) return;


        const reader = new FileReader();


        reader.onload = function (event) {

            imagePreview.src =
                event.target.result;

            fileName.textContent =
                file.name;

            fileSize.textContent =
                formatFileSize(file.size);

            prompt.classList.add('d-none');

            preview.classList.remove('d-none');

        };


        reader.readAsDataURL(file);

    });


    /*
     * Tombol ganti foto.
     */
    if (changeButton) {

        changeButton.addEventListener('click', function (event) {

            event.stopPropagation();

            fileInput.click();

        });

    }


    /*
     * Drag & Drop.
     */
    dropzone.addEventListener('dragover', function (event) {

        event.preventDefault();

        dropzone.classList.add('dragging');

    });


    dropzone.addEventListener('dragleave', function () {

        dropzone.classList.remove('dragging');

    });


    dropzone.addEventListener('drop', function (event) {

        event.preventDefault();

        dropzone.classList.remove('dragging');

        const files = event.dataTransfer.files;

        if (!files.length) return;

        fileInput.files = files;

        fileInput.dispatchEvent(
            new Event('change', { bubbles: true })
        );

    });


    function formatFileSize(bytes) {

        if (bytes === 0) {
            return '0 Bytes';
        }

        const sizes = [
            'Bytes',
            'KB',
            'MB',
            'GB'
        ];

        const i =
            Math.floor(
                Math.log(bytes) /
                Math.log(1024)
            );

        return (
            parseFloat(
                (bytes / Math.pow(1024, i))
                    .toFixed(2)
            )
            + ' '
            + sizes[i]
        );

    }

});

</script>


<?php $this->load->view('admin/template/footer'); ?>