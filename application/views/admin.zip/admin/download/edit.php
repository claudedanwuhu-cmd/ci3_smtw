<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- Page Header -->
        <div class="page-header-custom mb-4">
            <div class="page-header-left">
                <div class="page-header-icon">
                    <i class="fa-solid fa-file-arrow-down"></i>
                </div>

                <div>
                    <span class="badge-header-tag">DOWNLOAD</span>
                    <h2 class="page-title">Edit File Download</h2>
                    <p class="page-subtitle">
                        Perbarui informasi dokumen yang dapat diunduh pengunjung.
                    </p>
                </div>
            </div>

            <a href="<?= site_url('admin/download'); ?>" class="btn-back">
                <i class="fa-solid fa-arrow-left me-2"></i>
                Kembali
            </a>
        </div>

        <!-- Form Card -->
        <div class="custom-card">

            <div class="card-title-custom">
                <div class="title-icon">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>

                <div>
                    <h5>Edit Data File</h5>
                    <small>Perbarui informasi dokumen download.</small>
                </div>
            </div>

            <form
                action="<?= site_url('admin/download/update/' . $download->id); ?>"
                method="post"
                enctype="multipart/form-data"
            >

                <div class="card-body-custom">

                    <div class="row g-4">

                        <!-- Judul -->
                        <div class="col-md-8">
                            <label class="form-label">
                                Judul <span class="text-danger">*</span>
                            </label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-heading"></i>

                                <input
                                    type="text"
                                    name="judul"
                                    class="form-control custom-input with-icon"
                                    value="<?= html_escape($download->judul); ?>"
                                    placeholder="Masukkan judul file"
                                    required
                                >
                            </div>
                        </div>

                        <!-- Kategori -->
                        <div class="col-md-4">
                            <label class="form-label">Kategori</label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-folder"></i>

                                <input
                                    type="text"
                                    name="kategori"
                                    class="form-control custom-input with-icon"
                                    value="<?= html_escape($download->kategori); ?>"
                                    placeholder="Contoh: Akademik"
                                >
                            </div>
                        </div>

                        <!-- File -->
                        <div class="col-md-8">
                            <label class="form-label">Ganti File</label>

                            <div class="download-upload-box" id="download-upload-box">

                                <input
                                    type="file"
                                    name="file"
                                    id="download-file-input"
                                    class="file-input-hidden"
                                    accept=".pdf,.doc,.docx,.xls,.xlsx,.zip"
                                >

                                <div class="upload-content">
                                    <div class="upload-icon">
                                        <i class="fa-solid fa-cloud-arrow-up"></i>
                                    </div>

                                    <div>
                                        <strong id="download-upload-label">
                                            Klik untuk mengganti file
                                        </strong>

                                        <small>
                                            PDF, DOC, DOCX, XLS, XLSX, ZIP • Maksimal 10 MB
                                        </small>
                                    </div>
                                </div>

                            </div>

                            <div class="current-file mt-3">
                                <div class="current-file-icon">
                                    <i class="fa-solid fa-file-lines"></i>
                                </div>

                                <div>
                                    <small>File saat ini</small>
                                    <strong id="current-file-name">
                                        <?= html_escape($download->file); ?>
                                    </strong>
                                </div>
                            </div>
                        </div>

                        <!-- Tanggal -->
                        <div class="col-md-4">
                            <label class="form-label">Tanggal</label>

                            <div class="input-icon-group">
                                <i class="fa-solid fa-calendar-days"></i>

                                <input
                                    type="date"
                                    name="tanggal"
                                    class="form-control custom-input with-icon"
                                    value="<?= html_escape($download->tanggal); ?>"
                                >
                            </div>
                        </div>

                        <!-- Keterangan -->
                        <div class="col-12">
                            <label class="form-label">Keterangan</label>

                            <textarea
                                name="keterangan"
                                rows="6"
                                class="form-control custom-input custom-textarea"
                                placeholder="Masukkan keterangan file..."
                            ><?= html_escape($download->keterangan); ?></textarea>
                        </div>

                    </div>

                </div>

                <!-- Footer -->
                <div class="form-footer">

                    <a
                        href="<?= site_url('admin/download'); ?>"
                        class="btn-cancel"
                    >
                        <i class="fa-solid fa-xmark me-2"></i>
                        Batal
                    </a>

                    <button type="submit" class="btn-save">
                        <i class="fa-solid fa-floppy-disk me-2"></i>
                        Simpan Perubahan
                    </button>

                </div>

            </form>
        </div>

    </div>
</div>

<style>
/* ================================
   DOWNLOAD EDIT - GURU MASTER
================================ */

:root {
    --download-card-bg: #ffffff;
    --download-card-subtle: #f8fafc;
    --download-input-bg: #f8fafc;
    --download-input-border: #cbd5e1;
    --download-input-color: #0f172a;
    --download-title: #0f172a;
    --download-subtitle: #64748b;
    --download-border: rgba(226, 232, 240, .8);
    --download-accent: #0ea5e9;
    --download-icon-muted: #94a3b8;
}

.page-header-custom {
    background: var(--download-card-bg);
    border: 1px solid var(--download-border);
    border-radius: 20px;
    padding: 24px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.page-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.page-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .18);
    color: var(--download-accent);
    font-size: 21px;
    flex-shrink: 0;
}

.badge-header-tag {
    display: inline-flex;
    padding: 4px 9px;
    margin-bottom: 5px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .1);
    color: var(--download-accent);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
}

.page-title {
    color: var(--download-title);
    font-size: 22px;
    font-weight: 800;
    margin: 0;
}

.page-subtitle {
    color: var(--download-subtitle);
    font-size: 13px;
    margin: 5px 0 0;
}

.btn-back,
.btn-cancel {
    min-height: 42px;
    padding: 0 16px;
    border-radius: 12px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: var(--download-title);
    background: var(--download-card-bg);
    border: 1px solid var(--download-input-border);
    font-size: 13px;
    font-weight: 700;
    transition: .2s ease;
}

.btn-back:hover,
.btn-cancel:hover {
    color: var(--download-accent);
    border-color: var(--download-accent);
    transform: translateY(-1px);
}

.custom-card {
    background: var(--download-card-bg);
    border: 1px solid var(--download-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.card-title-custom {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 24px;
    background: var(--download-card-subtle);
    border-bottom: 1px solid var(--download-border);
}

.title-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .15);
    color: var(--download-accent);
}

.card-title-custom h5 {
    color: var(--download-title);
    font-size: 15px;
    font-weight: 800;
    margin: 0;
}

.card-title-custom small {
    display: block;
    color: var(--download-subtitle);
    font-size: 12px;
    margin-top: 3px;
}

.card-body-custom {
    padding: 26px 28px;
}

.form-label {
    display: block;
    color: var(--download-title);
    font-size: 12.5px;
    font-weight: 700;
    margin-bottom: 8px;
}

.custom-input {
    min-height: 44px;
    background: var(--download-input-bg);
    border: 1px solid var(--download-input-border);
    color: var(--download-input-color);
    border-radius: 12px;
    font-size: 13.5px;
    transition: .2s ease;
}

.custom-input:focus {
    background: #fff;
    color: var(--download-input-color);
    border-color: var(--download-accent);
    box-shadow: 0 0 0 3px rgba(14, 165, 233, .1);
}

.custom-input::placeholder {
    color: var(--download-icon-muted);
}

.input-icon-group {
    position: relative;
}

.input-icon-group > i {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: var(--download-icon-muted);
    font-size: 14px;
    z-index: 2;
    pointer-events: none;
}

.with-icon {
    padding-left: 40px;
}

.custom-textarea {
    min-height: 130px;
    padding: 12px 14px;
    resize: vertical;
}

.download-upload-box {
    min-height: 92px;
    border: 2px dashed var(--download-input-border);
    border-radius: 14px;
    background: var(--download-input-bg);
    display: flex;
    align-items: center;
    padding: 16px 18px;
    cursor: pointer;
    transition: .2s ease;
}

.download-upload-box:hover {
    border-color: var(--download-accent);
    background: rgba(14, 165, 233, .04);
}

.file-input-hidden {
    display: none;
}

.upload-content {
    display: flex;
    align-items: center;
    gap: 14px;
}

.upload-icon {
    width: 44px;
    height: 44px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    color: var(--download-accent);
    font-size: 17px;
    flex-shrink: 0;
}

.upload-content strong {
    display: block;
    color: var(--download-title);
    font-size: 13px;
    font-weight: 700;
}

.upload-content small {
    display: block;
    color: var(--download-subtitle);
    font-size: 11.5px;
    margin-top: 3px;
}

.current-file {
    display: flex;
    align-items: center;
    gap: 11px;
    padding: 11px 13px;
    border: 1px solid var(--download-border);
    border-radius: 12px;
    background: var(--download-card-subtle);
}

.current-file-icon {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    color: var(--download-accent);
}

.current-file small {
    display: block;
    color: var(--download-subtitle);
    font-size: 10.5px;
}

.current-file strong {
    display: block;
    color: var(--download-title);
    font-size: 12px;
    margin-top: 2px;
    word-break: break-all;
}

.form-footer {
    padding: 18px 24px;
    background: var(--download-card-subtle);
    border-top: 1px solid var(--download-border);
    display: flex;
    justify-content: flex-end;
    gap: 10px;
}

.btn-save {
    min-height: 42px;
    padding: 0 18px;
    border: 0;
    border-radius: 12px;
    color: #fff;
    background: linear-gradient(135deg, #0284c7, #0369a1);
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 5px 15px rgba(3, 105, 161, .2);
    transition: .2s ease;
}

.btn-save:hover {
    color: #fff;
    transform: translateY(-1px);
}

@media (max-width: 768px) {
    .page-header-custom {
        align-items: stretch;
        flex-direction: column;
        padding: 20px;
    }

    .btn-back {
        width: 100%;
    }

    .card-body-custom {
        padding: 20px;
    }

    .form-footer {
        flex-direction: column-reverse;
        padding: 16px 20px;
    }

    .btn-save,
    .btn-cancel {
        width: 100%;
    }
}

/* Dark Mode */
[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --download-card-bg: #0f172a;
    --download-card-subtle: #1e293b;
    --download-input-bg: #1e293b;
    --download-input-border: rgba(148, 163, 184, .25);
    --download-input-color: #f1f5f9;
    --download-title: #f8fafc;
    --download-subtitle: #94a3b8;
    --download-border: rgba(148, 163, 184, .16);
    --download-accent: #38bdf8;
    --download-icon-muted: #94a3b8;
}

[data-bs-theme="dark"] .custom-input:focus,
[data-theme="dark"] .custom-input:focus,
body.dark-mode .custom-input:focus,
.dark-mode .custom-input:focus {
    background: #1e293b;
    color: #f1f5f9;
}
</style>

<script>
(function () {
    const uploadBox = document.getElementById('download-upload-box');
    const input = document.getElementById('download-file-input');
    const label = document.getElementById('download-upload-label');
    const currentFile = document.getElementById('current-file-name');

    if (!uploadBox || !input) {
        return;
    }

    uploadBox.addEventListener('click', function () {
        input.click();
    });

    input.addEventListener('change', function () {
        const file = this.files && this.files[0];

        if (!file) {
            return;
        }

        if (label) {
            label.textContent = file.name;
        }

        if (currentFile) {
            currentFile.textContent = file.name;
        }
    });
})();
</script>

<?php $this->load->view('admin/template/footer'); ?>