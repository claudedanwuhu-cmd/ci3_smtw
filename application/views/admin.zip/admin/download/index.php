<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success mb-4">
                <i class="fa-solid fa-circle-check me-2"></i>
                <?= html_escape($this->session->flashdata('success')); ?>
            </div>
        <?php endif; ?>

        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- Page Header -->
        <div class="page-header-custom mb-4">

            <div class="page-header-left">

                <div class="page-header-icon">
                    <i class="fa-solid fa-download"></i>
                </div>

                <div>
                    <span class="badge-header-tag">DOWNLOAD</span>
                    <h2 class="page-title">Download</h2>
                    <p class="page-subtitle">
                        Kelola dokumen yang dapat diunduh oleh pengunjung.
                    </p>
                </div>

            </div>

            <a
                href="<?= site_url('admin/download/tambah'); ?>"
                class="btn-add"
            >
                <i class="fa-solid fa-plus me-2"></i>
                Tambah File
            </a>

        </div>

        <!-- List Card -->
        <div class="custom-card">

            <div class="card-title-custom justify-content-between">

                <div class="card-title-left">

                    <div class="title-icon">
                        <i class="fa-solid fa-file-arrow-down"></i>
                    </div>

                    <div>
                        <h5>Daftar File</h5>
                        <small>Dokumen publikasi sekolah</small>
                    </div>

                </div>

                <span class="total-badge">
                    <?= count($download); ?> Data
                </span>

            </div>

            <div class="table-responsive">

                <table class="table custom-table align-middle mb-0">

                    <thead>
                        <tr>
                            <th width="70">No</th>
                            <th>Judul</th>
                            <th width="150">Kategori</th>
                            <th width="280">File</th>
                            <th width="130">Tanggal</th>
                            <th width="110" class="text-end">Aksi</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php if (!empty($download)): ?>

                        <?php $no = 1; ?>

                        <?php foreach ($download as $item): ?>

                            <tr>

                                <!-- No -->
                                <td>
                                    <?= $no++; ?>
                                </td>

                                <!-- Judul -->
                                <td>

                                    <div class="item-title">
                                        <?= html_escape($item->judul); ?>
                                    </div>

                                    <?php if (!empty($item->keterangan)): ?>

                                        <small class="item-description">
                                            <?= html_escape($item->keterangan); ?>
                                        </small>

                                    <?php endif; ?>

                                </td>

                                <!-- Kategori -->
                                <td>

                                    <span class="badge-category">
                                        <?= !empty($item->kategori)
                                            ? html_escape($item->kategori)
                                            : 'Umum'; ?>
                                    </span>

                                </td>

                                <!-- File -->
                                <td>

                                    <div class="file-info">

                                        <div class="file-icon">
                                            <i class="fa-solid fa-file-lines"></i>
                                        </div>

                                        <div>
                                            <span class="file-name">
                                                <?= html_escape($item->file); ?>
                                            </span>

                                            <small>
                                                File download
                                            </small>
                                        </div>

                                    </div>

                                </td>

                                <!-- Tanggal -->
                                <td>

                                    <?php if (!empty($item->tanggal)): ?>

                                        <div class="date-info">
                                            <i class="fa-regular fa-calendar"></i>
                                            <?= date('d-m-Y', strtotime($item->tanggal)); ?>
                                        </div>

                                    <?php else: ?>

                                        <span class="text-muted">-</span>

                                    <?php endif; ?>

                                </td>

                                <!-- Aksi -->
                                <td>

                                    <div class="action-buttons justify-content-end">

                                        <a
                                            href="<?= site_url('admin/download/edit/' . $item->id); ?>"
                                            class="btn-action edit"
                                            title="Edit"
                                        >
                                            <i class="fa-solid fa-pen"></i>
                                        </a>

                                        <a
                                            href="<?= site_url('admin/download/hapus/' . $item->id); ?>"
                                            class="btn-action delete"
                                            title="Hapus"
                                            onclick="return confirm('Yakin ingin menghapus file ini?');"
                                        >
                                            <i class="fa-solid fa-trash"></i>
                                        </a>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="6" class="empty-data">

                                <div class="empty-icon">
                                    <i class="fa-solid fa-download"></i>
                                </div>

                                <strong>Belum ada file</strong>

                                <small>
                                    Tambahkan dokumen pertama yang dapat diunduh pengunjung.
                                </small>

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>
</div>

<style>
/* ================================
   DOWNLOAD LIST - GURU MASTER
================================ */

:root {
    --download-card-bg: #ffffff;
    --download-card-subtle: #f8fafc;
    --download-title: #0f172a;
    --download-subtitle: #64748b;
    --download-border: rgba(226, 232, 240, .8);
    --download-hover: #f8fafc;
    --download-accent: #0ea5e9;
    --download-icon-muted: #94a3b8;
}

.page-header-custom {
    background: var(--download-card-bg);
    border: 1px solid var(--download-border);
    border-radius: 20px;
    padding: 24px 28px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.page-header-left {
    display: flex;
    align-items: center;
    gap: 16px;
}

.page-header-icon {
    width: 52px;
    height: 52px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .18);
    color: var(--download-accent);
    font-size: 21px;
    flex-shrink: 0;
}

.badge-header-tag {
    display: inline-flex;
    padding: 4px 9px;
    margin-bottom: 5px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .1);
    color: var(--download-accent);
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .7px;
}

.page-title {
    color: var(--download-title);
    font-size: 22px;
    font-weight: 800;
    margin: 0;
}

.page-subtitle {
    color: var(--download-subtitle);
    font-size: 13px;
    margin: 5px 0 0;
}

.btn-add {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 42px;
    padding: 0 17px;
    border-radius: 12px;
    background: linear-gradient(135deg, #0284c7, #0369a1);
    color: #fff;
    text-decoration: none;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 5px 15px rgba(3, 105, 161, .2);
    transition: .2s ease;
}

.btn-add:hover {
    color: #fff;
    transform: translateY(-1px);
}

.custom-card {
    background: var(--download-card-bg);
    border: 1px solid var(--download-border);
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(15, 23, 42, .04);
}

.card-title-custom {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 24px;
    background: var(--download-card-subtle);
    border-bottom: 1px solid var(--download-border);
}

.card-title-left {
    display: flex;
    align-items: center;
    gap: 14px;
}

.title-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    border: 1px solid rgba(14, 165, 233, .15);
    color: var(--download-accent);
}

.card-title-custom h5 {
    color: var(--download-title);
    font-size: 15px;
    font-weight: 800;
    margin: 0;
}

.card-title-custom small {
    display: block;
    color: var(--download-subtitle);
    font-size: 12px;
    margin-top: 3px;
}

.total-badge {
    display: inline-flex;
    align-items: center;
    padding: 6px 11px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .1);
    color: var(--download-accent);
    font-size: 11px;
    font-weight: 800;
}

.custom-table {
    color: var(--download-title);
}

.custom-table thead th {
    background: var(--download-card-subtle);
    color: var(--download-subtitle);
    border-bottom: 1px solid var(--download-border);
    padding: 13px 18px;
    font-size: 10.5px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .4px;
    white-space: nowrap;
}

.custom-table tbody td {
    padding: 14px 18px;
    border-bottom: 1px solid var(--download-border);
    color: var(--download-title);
    font-size: 13px;
}

.custom-table tbody tr {
    transition: .15s ease;
}

.custom-table tbody tr:hover {
    background: var(--download-hover);
}

.custom-table tbody tr:last-child td {
    border-bottom: 0;
}

.item-title {
    color: var(--download-title);
    font-size: 13.5px;
    font-weight: 700;
    margin-bottom: 3px;
}

.item-description {
    display: block;
    max-width: 360px;
    color: var(--download-subtitle);
    font-size: 11.5px;
    line-height: 1.5;
}

.badge-category {
    display: inline-flex;
    align-items: center;
    padding: 6px 9px;
    border-radius: 999px;
    background: rgba(14, 165, 233, .08);
    color: var(--download-accent);
    font-size: 10.5px;
    font-weight: 700;
}

.file-info {
    display: flex;
    align-items: center;
    gap: 10px;
}

.file-icon {
    width: 38px;
    height: 38px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .1);
    color: var(--download-accent);
    flex-shrink: 0;
}

.file-name {
    display: block;
    max-width: 210px;
    color: var(--download-title);
    font-size: 12.5px;
    font-weight: 700;
    word-break: break-word;
}

.file-info small {
    display: block;
    color: var(--download-subtitle);
    font-size: 10.5px;
    margin-top: 2px;
}

.date-info {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    color: var(--download-subtitle);
    font-size: 12px;
    white-space: nowrap;
}

.date-info i {
    color: var(--download-accent);
}

.action-buttons {
    display: flex;
    align-items: center;
    gap: 7px;
}

.btn-action {
    width: 36px;
    height: 36px;
    border-radius: 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    transition: .2s ease;
}

.btn-action.edit {
    color: var(--download-accent);
    background: rgba(14, 165, 233, .1);
}

.btn-action.edit:hover {
    color: #fff;
    background: var(--download-accent);
    transform: translateY(-1px);
}

.btn-action.delete {
    color: #ef4444;
    background: rgba(239, 68, 68, .1);
}

.btn-action.delete:hover {
    color: #fff;
    background: #ef4444;
    transform: translateY(-1px);
}

.empty-data {
    padding: 60px 20px !important;
    text-align: center;
    color: var(--download-subtitle) !important;
}

.empty-icon {
    width: 64px;
    height: 64px;
    margin: 0 auto 14px;
    border-radius: 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(14, 165, 233, .08);
    color: var(--download-accent);
    font-size: 24px;
}

.empty-data strong {
    display: block;
    color: var(--download-title);
    font-size: 14px;
}

.empty-data small {
    display: block;
    margin-top: 4px;
    color: var(--download-subtitle);
    font-size: 12px;
}

@media (max-width: 768px) {

    .page-header-custom {
        align-items: stretch;
        flex-direction: column;
        padding: 20px;
    }

    .btn-add {
        width: 100%;
    }

    .custom-table thead th,
    .custom-table tbody td {
        padding: 12px;
    }

    .file-name {
        max-width: 150px;
    }
}

/* Dark Mode */
[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --download-card-bg: #0f172a;
    --download-card-subtle: #1e293b;
    --download-title: #f8fafc;
    --download-subtitle: #94a3b8;
    --download-border: rgba(148, 163, 184, .16);
    --download-hover: #1e293b;
    --download-accent: #38bdf8;
    --download-icon-muted: #94a3b8;
}
</style>

<?php $this->load->view('admin/template/footer'); ?>