<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-custom-success mb-4">
                <div class="alert-icon-box">
                    <i class="fa-solid fa-circle-check"></i>
                </div>

                <div>
                    <?= html_escape($this->session->flashdata('success')); ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="page-header-custom mb-4">

            <div class="d-flex align-items-center gap-3">

                <div class="page-header-icon">
                    <i class="fa-solid fa-images"></i>
                </div>

                <div>
                    <span class="badge-header-tag">ALBUM GALERI</span>

                    <h2 class="page-title mb-1">
                        <?= html_escape($album->nama_album); ?>
                    </h2>

                    <p class="page-subtitle mb-0">
                        Kelola foto dalam album ini.
                    </p>
                </div>

            </div>

            <div class="d-flex gap-2 flex-wrap">

                <a
                    href="<?= site_url('admin/galeri/foto_tambah/' . $album->id); ?>"
                    class="btn-add"
                >
                    <i class="fa-solid fa-plus me-2"></i>
                    Tambah Foto
                </a>

                <a
                    href="<?= site_url('admin/galeri'); ?>"
                    class="btn-back"
                >
                    <i class="fa-solid fa-arrow-left me-2"></i>
                    Kembali
                </a>

            </div>

        </div>

        <div class="custom-card">

            <div class="card-title-custom justify-content-between">

                <div class="d-flex align-items-center gap-3">

                    <div class="title-icon">
                        <i class="fa-solid fa-images"></i>
                    </div>

                    <div>
                        <h5>Daftar Foto</h5>
                        <small>
                            Foto dalam album
                            <?= html_escape($album->nama_album); ?>
                        </small>
                    </div>

                </div>

                <span class="total-badge">
                    <?= !empty($foto) ? count($foto) : 0; ?> Foto
                </span>

            </div>

            <div class="card-body-custom">

                <div class="row g-4">

                    <?php if (!empty($foto)): ?>

                        <?php foreach ($foto as $item): ?>

                            <div class="col-xl-3 col-lg-4 col-md-6">

                                <div class="gallery-card">

                                    <?php if (!empty($item->foto)): ?>

                                        <div class="gallery-image-wrapper">

                                            <img
                                                src="<?= base_url('assets/img/galeri/' . $item->foto); ?>"
                                                class="gallery-image"
                                                alt="<?= html_escape($item->judul); ?>"
                                            >

                                        </div>

                                    <?php else: ?>

                                        <div class="gallery-placeholder">
                                            <i class="fa-solid fa-image"></i>
                                        </div>

                                    <?php endif; ?>

                                    <div class="gallery-card-body">

                                        <h5>
                                            <?= !empty($item->judul)
                                                ? html_escape($item->judul)
                                                : 'Tanpa Judul'; ?>
                                        </h5>

                                        <?php if (!empty($item->deskripsi)): ?>

                                            <p>
                                                <?= html_escape($item->deskripsi); ?>
                                            </p>

                                        <?php else: ?>

                                            <p class="empty-description">
                                                Tidak ada deskripsi.
                                            </p>

                                        <?php endif; ?>

                                        <div class="gallery-card-footer">

                                            <a
                                                href="<?= site_url('admin/galeri/foto_hapus/' . $item->id . '/' . $album->id); ?>"
                                                class="btn-action delete"
                                                title="Hapus Foto"
                                                onclick="return confirm('Yakin ingin menghapus foto ini?');"
                                            >
                                                <i class="fa-solid fa-trash"></i>
                                            </a>

                                        </div>

                                    </div>

                                </div>

                            </div>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <div class="col-12">

                            <div class="empty-data">

                                <div class="empty-icon">
                                    <i class="fa-solid fa-image"></i>
                                </div>

                                Album ini belum memiliki foto.

                            </div>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>
</div>

<style>
:root {
    --admin-bg: #f8fafc;
    --admin-card: #ffffff;
    --admin-subtle: #f1f5f9;
    --admin-input: #f8fafc;
    --admin-border: #cbd5e1;
    --admin-line: rgba(226,232,240,.8);
    --admin-title: #0f172a;
    --admin-muted: #64748b;
    --admin-icon: #94a3b8;
    --admin-accent: #0ea5e9;
    --admin-accent-dark: #0284c7;
    --admin-glow: rgba(14,165,233,.25);
    --admin-shadow: 0 10px 30px -5px rgba(15,23,42,.05);
}

[data-bs-theme="dark"],
[data-theme="dark"],
body.dark-mode,
.dark-mode {
    --admin-bg: #070d19;
    --admin-card: #0f172a;
    --admin-subtle: #1e293b;
    --admin-input: #1e293b;
    --admin-border: rgba(255,255,255,.10);
    --admin-line: rgba(255,255,255,.10);
    --admin-title: #f8fafc;
    --admin-muted: #94a3b8;
    --admin-icon: #94a3b8;
    --admin-accent: #38bdf8;
    --admin-accent-dark: #0284c7;
    --admin-glow: rgba(56,189,248,.25);
    --admin-shadow: 0 10px 30px -5px rgba(0,0,0,.18);
}

/* Header & card */
.page-header-custom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.custom-card {
    overflow: hidden;
    border: 1px solid var(--admin-line);
    border-radius: 16px;
    background: var(--admin-card);
    box-shadow: var(--admin-shadow);
}

.card-title-custom {
    min-height: 76px;
    padding: 16px 24px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid var(--admin-line);
}

.card-title-custom h5 {
    margin: 0 0 3px;
    color: var(--admin-title);
    font-size: 14px;
    font-weight: 700;
}

.card-title-custom small {
    color: var(--admin-muted);
    font-size: 11.5px;
}

.title-icon,
.page-header-icon {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.title-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    background: rgba(14,165,233,.10);
    border: 1px solid rgba(14,165,233,.16);
    color: var(--admin-accent);
}

.page-header-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    background: rgba(14,165,233,.10);
    color: var(--admin-accent);
    font-size: 18px;
}

.page-title {
    color: var(--admin-title);
    font-weight: 800;
}

.page-subtitle {
    color: var(--admin-muted);
    font-size: 12.5px;
}

.badge-header-tag,
.total-badge {
    display: inline-flex;
    align-items: center;
    width: fit-content;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 800;
}

.badge-header-tag {
    margin-bottom: 4px;
    padding: 4px 8px;
    background: rgba(14,165,233,.10);
    color: var(--admin-accent);
    letter-spacing: .5px;
}

.total-badge {
    padding: 6px 10px;
    background: rgba(14,165,233,.10);
    color: var(--admin-accent);
}

/* Form */
.card-body-custom {
    padding: 24px;
}

.form-label {
    margin-bottom: 8px;
    color: var(--admin-title);
    font-size: 12.5px;
    font-weight: 700;
}

.input-icon-group {
    position: relative;
}

.input-icon-group > i {
    position: absolute;
    left: 15px;
    top: 50%;
    z-index: 2;
    transform: translateY(-50%);
    color: var(--admin-icon);
    font-size: 14px;
    pointer-events: none;
}

.input-icon-group .with-icon {
    padding-left: 42px;
}

.custom-input,
.custom-textarea {
    background: var(--admin-input);
    border: 1px solid var(--admin-border);
    border-radius: 12px;
    color: var(--admin-title);
    font-size: 13px;
    padding: 11px 13px;
    transition: .2s ease;
}

.custom-input:focus,
.custom-textarea:focus {
    background: var(--admin-card);
    border-color: var(--admin-accent);
    color: var(--admin-title);
    box-shadow: 0 0 0 3px var(--admin-glow);
}

.custom-textarea {
    min-height: 120px;
    resize: vertical;
}

.form-footer {
    padding: 18px 24px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 12px;
    background: var(--admin-subtle);
    border-top: 1px solid var(--admin-line);
}

.btn-cancel,
.btn-save,
.btn-add,
.btn-back,
.btn-primary-custom,
.btn-action {
    transition: .2s ease;
}

.btn-cancel,
.btn-save,
.btn-add,
.btn-back,
.btn-primary-custom {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    border-radius: 10px;
    text-decoration: none;
    font-size: 12.5px;
    font-weight: 700;
}

.btn-cancel {
    padding: 0 17px;
    background: var(--admin-subtle);
    border: 1px solid var(--admin-line);
    color: var(--admin-muted);
}

.btn-cancel:hover {
    background: var(--admin-card);
    color: var(--admin-title);
}

.btn-save,
.btn-add,
.btn-primary-custom {
    padding: 0 18px;
    border: 0;
    background: linear-gradient(135deg, #0ea5e9, #0284c7);
    color: #fff;
    box-shadow: 0 5px 15px rgba(14,165,233,.18);
}

.btn-save:hover,
.btn-add:hover,
.btn-primary-custom:hover {
    color: #fff;
    transform: translateY(-1px);
    box-shadow: 0 8px 20px rgba(14,165,233,.25);
}

.btn-back {
    padding: 0 16px;
    background: var(--admin-subtle);
    border: 1px solid var(--admin-line);
    color: var(--admin-muted);
}

.btn-back:hover {
    background: var(--admin-card);
    color: var(--admin-title);
    transform: translateY(-1px);
}

.btn-action {
    width: 40px;
    height: 40px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    text-decoration: none;
    font-size: 13px;
}

.btn-action.delete {
    background: rgba(239,68,68,.10);
    color: #ef4444;
}

.btn-action.delete:hover {
    background: rgba(239,68,68,.16);
    transform: translateY(-1px);
}

/* Gallery upload */
.upload-dropzone {
    position: relative;
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 24px;
    border: 2px dashed var(--admin-border);
    border-radius: 16px;
    background: var(--admin-subtle);
    cursor: pointer;
    transition: .25s ease;
}

.upload-dropzone:hover {
    border-color: var(--admin-accent);
    background: rgba(14,165,233,.04);
}

.upload-icon-circle {
    width: 44px;
    height: 44px;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: rgba(14,165,233,.10);
    color: var(--admin-accent);
    font-size: 17px;
}

.upload-text {
    display: flex;
    flex-direction: column;
    gap: 3px;
}

.upload-text strong {
    color: var(--admin-title);
    font-size: 13.5px;
}

.upload-text span,
.upload-subtext {
    color: var(--admin-muted);
    font-size: 11.5px;
}

.upload-subtext {
    margin-left: auto;
}

/* Gallery / album cards */
.gallery-card,
.album-card {
    height: 100%;
    overflow: hidden;
    border: 1px solid var(--admin-line);
    border-radius: 16px;
    background: var(--admin-card);
    box-shadow: var(--admin-shadow);
    transition: .2s ease;
}

.gallery-card:hover,
.album-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 28px rgba(15,23,42,.08);
}

.gallery-image-wrapper,
.gallery-placeholder {
    width: 100%;
    height: 190px;
    overflow: hidden;
    background: var(--admin-subtle);
}

.gallery-image {
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
    transition: transform .25s ease;
}

.gallery-card:hover .gallery-image {
    transform: scale(1.025);
}

.gallery-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--admin-icon);
    font-size: 36px;
}

.gallery-card-body,
.album-card-body {
    padding: 16px;
}

.gallery-card-body h5,
.album-card-body h5 {
    margin: 0 0 7px;
    color: var(--admin-title);
    font-size: 14px;
    font-weight: 700;
}

.album-card-body h5 {
    font-size: 15px;
}

.gallery-card-body p,
.album-card-body p {
    margin: 0;
    min-height: 40px;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 3;
    color: var(--admin-muted);
    font-size: 12.5px;
    line-height: 1.6;
}

.empty-description {
    font-style: italic;
}

.gallery-card-footer,
.album-card-footer {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 14px;
    padding-top: 12px;
    border-top: 1px solid var(--admin-line);
}

.gallery-card-footer {
    justify-content: flex-end;
}

.album-card-footer {
    justify-content: space-between;
    margin-top: 16px;
    padding-top: 14px;
}

.album-cover {
    height: 155px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--admin-subtle);
    border-bottom: 1px solid var(--admin-line);
}

.album-cover-icon {
    width: 64px;
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 16px;
    background: rgba(14,165,233,.10);
    border: 1px solid rgba(14,165,233,.18);
    color: var(--admin-accent);
    font-size: 28px;
}

.album-date {
    display: flex;
    align-items: center;
    gap: 7px;
    margin-top: 12px;
    color: var(--admin-muted);
    font-size: 12px;
}

.album-date i {
    color: var(--admin-accent);
}

.empty-data {
    padding: 50px 20px;
    text-align: center;
    color: var(--admin-muted);
    font-size: 13px;
}

.empty-icon {
    width: 58px;
    height: 58px;
    margin: 0 auto 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 16px;
    background: rgba(14,165,233,.10);
    color: var(--admin-accent);
    font-size: 22px;
}

/* Dark mode */
[data-bs-theme="dark"] .custom-input,
[data-bs-theme="dark"] .custom-textarea,
[data-theme="dark"] .custom-input,
[data-theme="dark"] .custom-textarea,
body.dark-mode .custom-input,
body.dark-mode .custom-textarea,
.dark-mode .custom-input,
.dark-mode .custom-textarea {
    color: var(--admin-title);
}

[data-bs-theme="dark"] .gallery-card,
[data-bs-theme="dark"] .album-card,
[data-theme="dark"] .gallery-card,
[data-theme="dark"] .album-card,
body.dark-mode .gallery-card,
body.dark-mode .album-card,
.dark-mode .gallery-card,
.dark-mode .album-card {
    background: var(--admin-card);
}

@media (max-width: 768px) {
    .page-header-custom {
        align-items: flex-start;
        flex-wrap: wrap;
    }

    .upload-dropzone {
        flex-wrap: wrap;
    }

    .upload-subtext {
        width: 100%;
        margin-left: 60px;
    }

    .gallery-image-wrapper,
    .gallery-placeholder {
        height: 210px;
    }

    .album-cover {
        height: 170px;
    }

    .album-card-footer {
        flex-wrap: wrap;
    }
}

@media (max-width: 576px) {
    .card-title-custom,
    .card-body-custom {
        padding-left: 18px;
        padding-right: 18px;
    }

    .form-footer {
        flex-direction: column-reverse;
        align-items: stretch;
    }

    .btn-cancel,
    .btn-save,
    .btn-add,
    .btn-back {
        width: 100%;
    }

    .page-header-custom > .btn-back,
    .page-header-custom > .btn-add {
        width: 100%;
    }

    .upload-subtext {
        margin-left: 0;
    }
}
</style>

<?php $this->load->view('admin/template/footer'); ?>
