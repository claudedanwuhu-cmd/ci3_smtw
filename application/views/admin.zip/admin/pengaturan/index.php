<?php $this->load->view('admin/template/header'); ?>
<?php $this->load->view('admin/template/sidebar'); ?>

<div class="main-content">
    <?php $this->load->view('admin/template/navbar'); ?>

    <div class="content-wrapper">

        <!-- NOTIFIKASI SUKSES -->
        <?php if ($this->session->flashdata('success')): ?>
            <div class="alert alert-success-custom mb-4">
                <i class="fa-solid fa-circle-check me-2"></i>
                <?= html_escape($this->session->flashdata('success')); ?>
            </div>
        <?php endif; ?>

        <!-- NOTIFIKASI ERROR -->
        <?php if ($this->session->flashdata('error')): ?>
            <div class="alert alert-danger-custom mb-4">
                <i class="fa-solid fa-circle-exclamation me-2"></i>
                <?= html_escape($this->session->flashdata('error')); ?>
            </div>
        <?php endif; ?>

        <!-- HEADER HALAMAN -->
        <div class="page-header-custom mb-4">
            <div class="d-flex align-items-center gap-3">
                <div class="page-header-icon">
                    <i class="fa-solid fa-gear"></i>
                </div>
                <div>
                    <span class="badge-header-tag mb-1">
                        <i class="fa-solid fa-sliders me-1"></i> Konfigurasi Sistem
                    </span>
                    <h2 class="page-title">Pengaturan Website</h2>
                    <p class="page-subtitle">Atur identitas sekolah, kontak, sosial media, dan informasi footer website.</p>
                </div>
            </div>
        </div>

        <!-- CARD KONTEN UTAMA -->
        <div class="custom-card">
            <div class="card-title-custom d-flex justify-content-between align-items-center p-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="section-icon">
                        <i class="fa-solid fa-globe"></i>
                    </div>
                    <div>
                        <h5 class="mb-0 fw-bold" style="color: var(--pres-title);">Formulir Pengaturan Sistem</h5>
                        <small class="text-muted-custom">Sesuaikan informasi global website sekolah di bawah ini</small>
                    </div>
                </div>
                <span class="total-badge">Pengaturan Global</span>
            </div>

            <!-- FORM -->
            <form action="<?= site_url('admin/pengaturan/update'); ?>" method="post">
                <div class="p-4">

                    <!-- BAGIAN 1: IDENTITAS WEBSITE -->
                    <div class="form-section mb-4">
                        <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom" style="border-color: var(--pres-border) !important;">
                            <div class="section-icon-sm">
                                <i class="fa-solid fa-school text-accent-custom"></i>
                            </div>
                            <h6 class="fw-bold mb-0" style="color: var(--pres-title);">Identitas Website</h6>
                        </div>
                        <div class="row g-4">
                            <div class="col-md-8">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Nama Sekolah <span class="text-danger">*</span>
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-school"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="nama_sekolah" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->nama_sekolah); ?>" 
                                        placeholder="Masukkan nama sekolah"
                                        required
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Tagline
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-quote-left"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="tagline" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->tagline); ?>" 
                                        placeholder="Slogan atau tagline"
                                    >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Logo Website
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-image"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="logo" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->logo); ?>" 
                                        placeholder="Nama file logo"
                                    >
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Favicon Website
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-bookmark"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="favicon" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->favicon); ?>" 
                                        placeholder="Nama file favicon"
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- BAGIAN 2: KONTAK SEKOLAH -->
                    <div class="form-section mb-4 pt-3">
                        <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom" style="border-color: var(--pres-border) !important;">
                            <div class="section-icon-sm">
                                <i class="fa-solid fa-address-card text-accent-custom"></i>
                            </div>
                            <h6 class="fw-bold mb-0" style="color: var(--pres-title);">Kontak Sekolah</h6>
                        </div>
                        <div class="row g-4">
                            <div class="col-12">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Alamat Lengkap
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon align-self-start mt-3">
                                        <i class="fa-solid fa-map-location-dot"></i>
                                    </span>
                                    <textarea 
                                        name="alamat" 
                                        rows="3" 
                                        class="form-control-custom" 
                                        style="padding-top: 12px;"
                                        placeholder="Masukkan alamat lengkap sekolah"
                                    ><?= html_escape($pengaturan->alamat); ?></textarea>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Telepon
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-phone"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="telepon" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->telepon); ?>" 
                                        placeholder="Nomor telepon"
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Email Resmi
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-solid fa-envelope"></i>
                                    </span>
                                    <input 
                                        type="email" 
                                        name="email" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->email); ?>" 
                                        placeholder="Alamat email aktif"
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    WhatsApp
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-brands fa-whatsapp"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="whatsapp" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->whatsapp); ?>" 
                                        placeholder="Nomor WhatsApp"
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- BAGIAN 3: SOSIAL MEDIA -->
                    <div class="form-section mb-4 pt-3">
                        <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom" style="border-color: var(--pres-border) !important;">
                            <div class="section-icon-sm">
                                <i class="fa-solid fa-share-nodes text-accent-custom"></i>
                            </div>
                            <h6 class="fw-bold mb-0" style="color: var(--pres-title);">Sosial Media</h6>
                        </div>
                        <div class="row g-4">
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Facebook
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-brands fa-facebook"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="facebook" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->facebook); ?>" 
                                        placeholder="URL atau akun Facebook"
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Instagram
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-brands fa-instagram"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="instagram" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->instagram); ?>" 
                                        placeholder="URL atau akun Instagram"
                                    >
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    YouTube
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon">
                                        <i class="fa-brands fa-youtube"></i>
                                    </span>
                                    <input 
                                        type="text" 
                                        name="youtube" 
                                        class="form-control-custom" 
                                        value="<?= html_escape($pengaturan->youtube); ?>" 
                                        placeholder="URL atau channel YouTube"
                                    >
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- BAGIAN 4: LOKASI DAN FOOTER -->
                    <div class="form-section pt-3">
                        <div class="d-flex align-items-center gap-2 mb-3 pb-2 border-bottom" style="border-color: var(--pres-border) !important;">
                            <div class="section-icon-sm">
                                <i class="fa-solid fa-location-dot text-accent-custom"></i>
                            </div>
                            <h6 class="fw-bold mb-0" style="color: var(--pres-title);">Lokasi dan Footer</h6>
                        </div>
                        <div class="row g-4">
                            <div class="col-12">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Google Maps (Embed HTML / Iframe)
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon align-self-start mt-3">
                                        <i class="fa-solid fa-map"></i>
                                    </span>
                                    <textarea 
                                        name="maps" 
                                        rows="3" 
                                        class="form-control-custom" 
                                        style="padding-top: 12px;"
                                        placeholder="Kode embed Google Maps"
                                    ><?= html_escape($pengaturan->maps); ?></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold small mb-2" style="color: var(--pres-title);">
                                    Teks Footer
                                </label>
                                <div class="input-group-custom">
                                    <span class="input-group-icon align-self-start mt-3">
                                        <i class="fa-solid fa-copyright"></i>
                                    </span>
                                    <textarea 
                                        name="footer" 
                                        rows="3" 
                                        class="form-control-custom" 
                                        style="padding-top: 12px;"
                                        placeholder="Teks hak cipta atau catatan footer website"
                                    ><?= html_escape($pengaturan->footer); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- FORM FOOTER ACTIONS -->
                <div class="card-footer-custom d-flex justify-content-end align-items-center p-4">
                    <button type="submit" class="btn-primary-custom">
                        <i class="fa-solid fa-floppy-disk me-2"></i> Simpan Pengaturan
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>

<!-- STYLES KUSTOM DINAMIS (DARK/LIGHT MODE ADAPTIVE SESUAI TAMPILAN GURU) -->
<style>
    :root {
        --pres-bg: #ffffff;
        --pres-subtle: #f8fafc;
        --pres-border: rgba(226, 232, 240, 0.8);
        --pres-input-bg: #ffffff;
        --pres-title: #0f172a;
        --pres-subtitle: #64748b;
        --pres-hover: #f1f5f9;
        --pres-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.05);
        --pres-accent: #0ea5e9;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(14, 165, 233, 0.15);
    }

    [data-theme="dark"], [data-bs-theme="dark"], body.dark-mode, .dark-mode {
        --pres-bg: #0f172a;
        --pres-subtle: #1e293b;
        --pres-border: rgba(255, 255, 255, 0.08);
        --pres-input-bg: #1e293b;
        --pres-title: #f8fafc;
        --pres-subtitle: #94a3b8;
        --pres-hover: rgba(255, 255, 255, 0.03);
        --pres-shadow: 0 12px 30px -5px rgba(0, 0, 0, 0.4);
        --pres-accent: #38bdf8;
        --pres-accent-dark: #0284c7;
        --pres-accent-glow: rgba(56, 189, 248, 0.2);
    }

    .text-muted-custom { color: var(--pres-subtitle); }
    .text-accent-custom { color: var(--pres-accent); }

    /* Alert Success & Danger */
    .alert-success-custom {
        background: rgba(34, 197, 94, 0.1);
        color: #22c55e;
        border: 1px solid rgba(34, 197, 94, 0.2);
        padding: 14px 20px;
        border-radius: 14px;
        font-weight: 600;
        font-size: 14px;
    }

    .alert-danger-custom {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
        padding: 14px 20px;
        border-radius: 14px;
        font-weight: 600;
        font-size: 14px;
    }

    /* Header */
    .page-header-custom {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        padding: 22px 28px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        box-shadow: var(--pres-shadow);
        gap: 20px;
    }

    .badge-header-tag {
        display: inline-flex;
        align-items: center;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
    }

    .page-title {
        color: var(--pres-title);
        font-size: 22px;
        font-weight: 800;
        margin-bottom: 2px;
    }

    .page-subtitle {
        color: var(--pres-subtitle);
        font-size: 13px;
        margin-bottom: 0;
    }

    .page-header-icon {
        width: 50px;
        height: 50px;
        border-radius: 14px;
        background: var(--pres-subtle);
        border: 1px solid var(--pres-border);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }

    /* Card Wrapper */
    .custom-card {
        background: var(--pres-bg);
        border: 1px solid var(--pres-border);
        border-radius: 20px;
        overflow: hidden;
        box-shadow: var(--pres-shadow);
    }

    .card-title-custom {
        border-bottom: 1px solid var(--pres-border);
        background: var(--pres-bg);
    }

    .card-footer-custom {
        border-top: 1px solid var(--pres-border);
        background: var(--pres-subtle);
    }

    .total-badge {
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        border: 1px solid rgba(14, 165, 233, 0.2);
        padding: 6px 14px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: 700;
    }

    .section-icon {
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background: rgba(14, 165, 233, 0.1);
        color: var(--pres-accent);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
    }

    .section-icon-sm {
        width: 28px;
        height: 28px;
        border-radius: 8px;
        background: rgba(14, 165, 233, 0.1);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
    }

    /* Form Controls & Inputs Styling */
    .input-group-custom {
        position: relative;
        display: flex;
        align-items: center;
    }

    .input-group-icon {
        position: absolute;
        left: 16px;
        color: var(--pres-subtitle);
        font-size: 14px;
        z-index: 5;
        pointer-events: none;
    }

    .form-control-custom {
        width: 100%;
        background: var(--pres-input-bg);
        border: 1px solid var(--pres-border);
        color: var(--pres-title);
        border-radius: 12px;
        padding: 12px 16px 12px 46px;
        font-size: 13.5px;
        transition: all 0.25s ease;
    }

    .form-control-custom:focus {
        background: var(--pres-input-bg);
        border-color: var(--pres-accent);
        box-shadow: 0 0 0 4px var(--pres-accent-glow);
        color: var(--pres-title);
        outline: none;
    }

    .form-control-custom::placeholder {
        color: var(--pres-subtitle);
        opacity: 0.6;
    }

    /* Buttons */
    .btn-primary-custom {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, var(--pres-accent) 0%, var(--pres-accent-dark) 100%);
        color: #ffffff !important;
        border-radius: 12px;
        padding: 11px 22px;
        font-size: 13.5px;
        font-weight: 700;
        text-decoration: none;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 4px 15px rgba(14, 165, 233, 0.3);
        border: none;
    }

    .btn-primary-custom:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 25px rgba(14, 165, 233, 0.45);
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .page-header-custom {
            flex-direction: column;
            align-items: stretch;
            gap: 12px;
        }
        .btn-primary-custom {
            width: 100%;
            justify-content: center;
        }
    }
</style>

<?php $this->load->view('admin/template/footer'); ?>